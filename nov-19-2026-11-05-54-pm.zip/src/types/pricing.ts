export type SaleTerm = 'نقدی' | 'چکی';

export type BasisPriceSource = 'موجودی قابل فروش' | 'موجودی انبار' | 'قیمت ناموجود';

export type NavSection =
  | 'dashboard'
  | 'upload'
  | 'pricing'
  | 'sales-list'
  | 'visitors-list'
  | 'settings'
  | 'history'
  | 'backup';

export interface CityFare {
  id: string;
  city: string;
  fare: number; // Toman
  trips: number;
}

export interface ShippingMetrics {
  totalTrips: number;
  weightedSum: number;
  weightedAvgFare: number; // AB21
  fluctuationFactor: number; // AB22 (e.g. 0.15)
  baseFareWithCoverage: number; // AB23
  truckCapacityKg: number; // AB24 (e.g. 2500)
  costPerKg: number; // AB25
}

export interface AppSettings {
  companyName: string;
  customListDate: string; // Empty means auto today Jalali
  defaultVatRate: number;
  // Sales list OR thresholds
  salesMinAvailable: number; // Default 0
  salesMinWarehouse: number; // Default 50
  // Visitors list OR thresholds
  visitorsMinAvailable: number; // Default 10
  visitorsMinWarehouse: number; // Default 0
  // Shipping (Saipa)
  fluctuationPercent: number; // Default 15 (means 15% => 0.15)
  truckCapacityKg: number; // Default 2500
  cityFares: CityFare[];
  // Group display order
  groupOrder: string[];
}

export interface TermManualInput {
  weight: number | null; // Column E
  vatRate: number | null; // Column I (percent, e.g. 0 or 10)
  inboundShipping: number | null; // Column J (Toman)
  exWarehousePrice: number | null; // Column Q (Toman)
}

export interface ProductManualData {
  code: string;
  cash: TermManualInput;
  check: TermManualInput;
  // Shared product-level manual fields (Columns AH..AK)
  checkDays: number | null; // AH
  consumptionPrice: number | null; // AI
  consumerPrice: number | null; // AJ
  notes: string; // AK
  lastTaxFlag: number; // AF helper
  updatedAt?: string;
}

export interface ProductReportData {
  code: string;
  name: string;
  buyGroup: string;
  salesGroup: string;
  avgCost: number | null; // Column F (Toman, from warehouse report / 10)
  lastPurchasePrice: number | null; // Column G (Toman, from sellable report / 10)
  basisPrice: number | null; // Column H (priority: G > F > null)
  basisSource: BasisPriceSource; // Column N
  availableStock: number; // Column K
  warehouseStock: number; // Column L
  stockStatus: string; // Column M
  taxFlag: number; // Column AF
  orderIndex: number; // Preserves appearance order within groups
}

export interface ComputedTermPricing {
  term: SaleTerm;
  manual: TermManualInput;
  landedCost: number | null; // O = H * (1 + I/100) + J (includes purchase VAT)
  grossMargin: number | null; // R = (Q - O) / Q
  customerShipping: number | null; // S = ROUND(E * AB25, -2)
  deliveredExVat: number | null; // T = Q + S
  salesExWarehouse: number | null; // Output ex-warehouse sale price (= Q when > 0)
  salesDelivered: number | null; // Output delivered sale price (= T = Q + S when Q > 0)
  afterShippingCheck: number | null; // U = T - S
  netProfit: number | null; // V = Q - O
  profitPercent: number | null; // W = V / O
  vatAmount: number | null; // X = ROUND(Q * I/100, 0)
  finalExWarehouse: number | null; // AD = Q + X (auxiliary Excel column)
  finalDelivered: number | null; // AE = ROUND(T * (1 + I/100), -2) (auxiliary Excel column)
}

export interface ComputedProduct {
  report: ProductReportData;
  manual: ProductManualData;
  cash: ComputedTermPricing;
  check: ComputedTermPricing;
  isSalesVisible: boolean;
  isVisitorsVisible: boolean;
}

export interface DuplicateCodeEntry {
  code: string;
  occurrences: Array<{
    rowNumber: number;
    name: string;
    stock: number;
    priceRaw: number | null;
  }>;
}

export interface SellableReportRow {
  code: string;
  name: string;
  buyGroup: string;
  salesGroup: string;
  availableStock: number;
  lastPurchasePriceRial: number | null;
  taxRaw: number | null;
  rowNumber: number;
}

export interface WarehouseReportRow {
  code: string;
  name: string;
  buyGroup: string;
  salesGroup: string;
  warehouseStock: number;
  avgCostRial: number | null;
  taxRaw: number | null;
  rowNumber: number;
}

export interface ParsedFileReport<T> {
  fileName: string;
  totalRows: number;
  validRows: T[];
  uniqueCount: number;
  duplicates: DuplicateCodeEntry[];
  errors: string[];
  warnings: string[];
  parsedAt: string;
}

export interface MergeSummary {
  newProducts: Array<{ code: string; name: string }>;
  removedFromActive: Array<{ code: string; name: string }>;
  updatedCount: number;
  preservedManualCount: number;
  restoredManualCount: number;
  totalActiveCount: number;
  basisChangedCount: number;
}

export interface UploadLogEntry {
  id: string;
  timestamp: string;
  jalaliDateTime: string;
  sellableFileName: string;
  warehouseFileName: string;
  newCount: number;
  removedCount: number;
  updatedCount: number;
  totalActiveCount: number;
  preservedManualCount: number;
  restoredManualCount: number;
  duplicateWarningsCount: number;
}

export interface PriceChangeLogEntry {
  id: string;
  timestamp: string;
  jalaliDate: string;
  jalaliTime: string;
  code: string;
  productName: string;
  term: SaleTerm | 'مشترک';
  fieldLabel: string;
  oldValue: string;
  newValue: string;
}

export interface PersistedAppState {
  version: number;
  products: ProductReportData[];
  manualData: Record<string, ProductManualData>;
  settings: AppSettings;
  uploadLogs: UploadLogEntry[];
  priceChangeLogs: PriceChangeLogEntry[];
  lastUpdatedAt: string | null;
  lastUpdatedJalali: string | null;
}
