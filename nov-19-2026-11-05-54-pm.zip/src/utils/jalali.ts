/**
 * Pure Gregorian-to-Jalali (Shamsi) conversion and Persian number formatting utilities.
 * Zero external dependencies so dates work reliably offline in any browser.
 */

export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy: number;
  let gy2 = gy;
  if (gy2 > 1600) {
    jy = 979;
    gy2 -= 1600;
  } else {
    jy = 0;
    gy2 -= 621;
  }
  const gy3 = gm > 2 ? gy2 + 1 : gy2;
  let days =
    365 * gy2 +
    Math.floor((gy3 + 3) / 4) -
    Math.floor((gy3 + 99) / 100) +
    Math.floor((gy3 + 399) / 400) -
    80 +
    gd +
    g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function getTodayJalali(date: Date = new Date()): string {
  const [jy, jm, jd] = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return `${jy}/${pad2(jm)}/${pad2(jd)}`;
}

export function getJalaliTime(date: Date = new Date()): string {
  return `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}

export function formatJalaliDateTime(date: Date = new Date()): string {
  return `${getTodayJalali(date)} - ${getJalaliTime(date)}`;
}

const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => PERSIAN_DIGITS[Number(d)] ?? d);
}

export function toLatinDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660));
}

/**
 * Format integer Toman currency with thousands separators.
 * Returns "—" for null, undefined, NaN, or <= 0 when dashOnZero is true.
 */
export function formatToman(
  value: number | null | undefined,
  options: { dashOnZero?: boolean; decimals?: number } = {}
): string {
  const { dashOnZero = false, decimals = 0 } = options;
  if (value === null || value === undefined || !Number.isFinite(value)) {
    return '—';
  }
  if (dashOnZero && value <= 0) {
    return '—';
  }
  const rounded = decimals === 0 ? Math.round(value) : Number(value.toFixed(decimals));
  return rounded.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatStock(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) {
    return '0';
  }
  if (Number.isInteger(value)) {
    return value.toLocaleString('en-US');
  }
  return Number(value.toFixed(2)).toLocaleString('en-US', {
    maximumFractionDigits: 2,
  });
}

export function formatPercent(ratio: number | null | undefined): string {
  if (ratio === null || ratio === undefined || !Number.isFinite(ratio)) {
    return '—';
  }
  const pct = ratio * 100;
  return `${pct.toFixed(1)}%`;
}
