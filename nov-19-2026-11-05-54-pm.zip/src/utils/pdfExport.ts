import { jsPDF } from 'jspdf';
import { AppSettings, ComputedProduct } from '../types/pricing';
import { formatStock, formatToman, toPersianDigits } from './jalali';

/**
 * High-precision Persian RTL A4 Landscape PDF Generator.
 *
 * Uses the browser's native Canvas 2D HarfBuzz/ICU shaping (`ctx.direction = 'rtl'`)
 * with loaded Vazirmatn font at 2.5x print DPI, then embeds paginated pages into jsPDF.
 * This guarantees 100% connected Persian glyphs, proper BiDi ordering for mixed
 * Persian/English/Numbers, repeating headers on every page, and zero column clipping.
 */

interface PdfColumn {
  key: string;
  label: string;
  subLabel?: string;
  widthMm: number;
  align: 'right' | 'center';
}

// Total usable width on A4 Landscape (297mm) with 5mm margins on left & right = 287mm
const SALES_COLUMNS: PdfColumn[] = [
  { key: 'group', label: 'گروه کالا', widthMm: 20, align: 'center' },
  { key: 'name', label: 'نام محصول', widthMm: 69, align: 'right' },
  { key: 'cashEx', label: 'فروش نقدی', subLabel: 'درب انبار شرکت', widthMm: 21, align: 'center' },
  { key: 'cashDel', label: 'فروش نقدی', subLabel: 'تحویلی مشتری', widthMm: 21, align: 'center' },
  { key: 'checkEx', label: 'فروش چکی', subLabel: 'درب انبار شرکت', widthMm: 21, align: 'center' },
  { key: 'checkDel', label: 'فروش چکی', subLabel: 'تحویلی مشتری', widthMm: 21, align: 'center' },
  { key: 'checkDays', label: 'مدت چک', subLabel: '(روز)', widthMm: 13, align: 'center' },
  { key: 'consumption', label: 'قیمت مصرف', subLabel: '(تومان)', widthMm: 18, align: 'center' },
  { key: 'consumer', label: 'مصرف‌کننده', subLabel: '(تومان)', widthMm: 18, align: 'center' },
  { key: 'availStock', label: 'موجودی', subLabel: 'قابل فروش', widthMm: 15, align: 'center' },
  { key: 'whStock', label: 'موجودی', subLabel: 'انبار', widthMm: 14, align: 'center' },
  { key: 'notes', label: 'توضیحات', widthMm: 36, align: 'right' },
];

// Visitors PDF omits the 2 ex-warehouse columns (10 columns totaling 287mm)
const VISITORS_COLUMNS: PdfColumn[] = [
  { key: 'group', label: 'گروه کالا', widthMm: 22, align: 'center' },
  { key: 'name', label: 'نام محصول', widthMm: 83, align: 'right' },
  { key: 'cashDel', label: 'فروش نقدی', subLabel: 'تحویلی مشتری', widthMm: 26, align: 'center' },
  { key: 'checkDel', label: 'فروش چکی', subLabel: 'تحویلی مشتری', widthMm: 26, align: 'center' },
  { key: 'checkDays', label: 'مدت چک', subLabel: '(روز)', widthMm: 15, align: 'center' },
  { key: 'consumption', label: 'قیمت مصرف', subLabel: '(تومان)', widthMm: 20, align: 'center' },
  { key: 'consumer', label: 'مصرف‌کننده', subLabel: '(تومان)', widthMm: 20, align: 'center' },
  { key: 'availStock', label: 'موجودی', subLabel: 'قابل فروش', widthMm: 16, align: 'center' },
  { key: 'whStock', label: 'موجودی', subLabel: 'انبار', widthMm: 15, align: 'center' },
  { key: 'notes', label: 'توضیحات', widthMm: 44, align: 'right' },
];

const PAGE_W_MM = 297;
const PAGE_H_MM = 210;
const MARGIN_X_MM = 5;
const MARGIN_Y_MM = 5;
const USABLE_W_MM = PAGE_W_MM - MARGIN_X_MM * 2; // 287mm
const FIRST_HEADER_H_MM = 11;
const CONT_HEADER_H_MM = 7.5;
const TABLE_HEADER_H_MM = 8.5;
const FOOTER_H_MM = 5.2;
const ROW_H_MM = 4.9;

const PX_PER_MM = 9.0; // ~230 DPI crisp print & WhatsApp clarity at compact row height

interface RenderRow {
  groupName: string;
  product: ComputedProduct;
  isGroupStart: boolean;
  rowStripe: number;
}

function buildRenderPages(items: ComputedProduct[]): RenderRow[][] {
  const firstPageMaxRows = Math.max(
    1,
    Math.floor(
      (PAGE_H_MM - MARGIN_Y_MM * 2 - FIRST_HEADER_H_MM - TABLE_HEADER_H_MM - FOOTER_H_MM) /
        ROW_H_MM
    )
  );
  const nextPageMaxRows = Math.max(
    1,
    Math.floor(
      (PAGE_H_MM - MARGIN_Y_MM * 2 - CONT_HEADER_H_MM - TABLE_HEADER_H_MM - FOOTER_H_MM) /
        ROW_H_MM
    )
  );

  const flat: RenderRow[] = [];
  let prevGroup = '';
  let stripe = 0;

  for (const item of items) {
    const g = item.report.salesGroup || 'سایر';
    const isGroupStart = g !== prevGroup;
    if (isGroupStart) {
      prevGroup = g;
      stripe = 0;
    }
    flat.push({ groupName: g, product: item, isGroupStart, rowStripe: stripe++ });
  }

  const pages: RenderRow[][] = [];
  let idx = 0;
  let pageNum = 0;

  while (idx < flat.length) {
    const cap = pageNum === 0 ? firstPageMaxRows : nextPageMaxRows;
    const slice = flat.slice(idx, idx + cap).map((entry, rowIdx) => ({
      ...entry,
      // Always display group name cleanly on the first row of each page
      isGroupStart: rowIdx === 0 ? true : entry.isGroupStart,
    }));
    pages.push(slice);
    idx += cap;
    pageNum++;
  }

  if (pages.length === 0) {
    pages.push([]);
  }

  return pages;
}

function fitText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidthPx: number
): string {
  if (!text) return '';
  if (ctx.measureText(text).width <= maxWidthPx) return text;
  let trimmed = text;
  while (trimmed.length > 1 && ctx.measureText(trimmed + '…').width > maxWidthPx) {
    trimmed = trimmed.slice(0, -1);
  }
  return trimmed + '…';
}

function drawPageCanvas(params: {
  mode: 'sales' | 'visitors';
  pageItems: RenderRow[];
  pageNumber: number;
  totalPages: number;
  title: string;
  companyName: string;
  jalaliDate: string;
  totalItemsCount: number;
}): HTMLCanvasElement {
  const {
    mode,
    pageItems,
    pageNumber,
    totalPages,
    title,
    companyName,
    jalaliDate,
    totalItemsCount,
  } = params;

  const columns = mode === 'sales' ? SALES_COLUMNS : VISITORS_COLUMNS;
  const headerHMm = pageNumber === 1 ? FIRST_HEADER_H_MM : CONT_HEADER_H_MM;

  const canvas = document.createElement('canvas');
  canvas.width = Math.round(PAGE_W_MM * PX_PER_MM);
  canvas.height = Math.round(PAGE_H_MM * PX_PER_MM);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('عدم دسترسی به موتور ترسیم PDF در مرورگر.');

  const mm = (val: number) => val * PX_PER_MM;

  // White background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.direction = 'rtl';
  ctx.textBaseline = 'middle';

  // --- Compact Header Band ---
  const topY = mm(MARGIN_Y_MM);
  const leftX = mm(MARGIN_X_MM);
  const rightX = mm(PAGE_W_MM - MARGIN_X_MM);
  const usableW = mm(USABLE_W_MM);
  const headerBandH = mm(headerHMm - 1);

  ctx.fillStyle = '#0F766E';
  ctx.fillRect(leftX, topY, usableW, headerBandH);

  if (pageNumber === 1) {
    // Company & Title (Right-aligned in RTL)
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `700 ${Math.round(mm(3.5))}px Vazirmatn, Tahoma, sans-serif`;
    ctx.textAlign = 'right';
    ctx.fillText(`${companyName}  —  ${title}`, rightX - mm(3.5), topY + headerBandH * 0.36);

    ctx.fillStyle = '#CCFBF1';
    ctx.font = `400 ${Math.round(mm(2.25))}px Vazirmatn, Tahoma, sans-serif`;
    ctx.fillText('کلیه قیمت‌ها به تومان می‌باشد', rightX - mm(3.5), topY + headerBandH * 0.74);

    // Date & Total Count (Left-aligned in RTL)
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'left';
    ctx.font = `700 ${Math.round(mm(2.9))}px Vazirmatn, Tahoma, sans-serif`;
    ctx.fillText(
      `تاریخ لیست: ${toPersianDigits(jalaliDate)}`,
      leftX + mm(3.5),
      topY + headerBandH * 0.36
    );

    ctx.fillStyle = '#CCFBF1';
    ctx.font = `400 ${Math.round(mm(2.25))}px Vazirmatn, Tahoma, sans-serif`;
    ctx.fillText(
      `تعداد اقلام: ${toPersianDigits(totalItemsCount)} کالا`,
      leftX + mm(3.5),
      topY + headerBandH * 0.74
    );
  } else {
    // Slim continuation header on pages 2+
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `700 ${Math.round(mm(2.85))}px Vazirmatn, Tahoma, sans-serif`;
    ctx.textAlign = 'right';
    ctx.fillText(
      `${companyName} — ${title} (ادامه)`,
      rightX - mm(3.5),
      topY + headerBandH / 2
    );

    ctx.fillStyle = '#CCFBF1';
    ctx.font = `600 ${Math.round(mm(2.5))}px Vazirmatn, Tahoma, sans-serif`;
    ctx.textAlign = 'left';
    ctx.fillText(
      `تاریخ: ${toPersianDigits(jalaliDate)}  |  کلیه قیمت‌ها به تومان`,
      leftX + mm(3.5),
      topY + headerBandH / 2
    );
  }

  // --- Table Header (RTL: columns flow right-to-left) ---
  let curY = topY + mm(headerHMm);
  const thH = mm(TABLE_HEADER_H_MM);

  ctx.fillStyle = '#1E293B';
  ctx.fillRect(leftX, curY, usableW, thH);

  // Precompute column right & left edges (RTL order: col 0 is rightmost)
  const colRects: Array<{ x: number; w: number; col: PdfColumn }> = [];
  let cursorRight = rightX;
  for (const col of columns) {
    const wPx = mm(col.widthMm);
    const xPx = cursorRight - wPx;
    colRects.push({ x: xPx, w: wPx, col });
    cursorRight = xPx;
  }

  ctx.strokeStyle = '#475569';
  ctx.lineWidth = 1;
  for (const rect of colRects) {
    ctx.strokeRect(rect.x, curY, rect.w, thH);
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    if (rect.col.subLabel) {
      ctx.font = `700 ${Math.round(mm(2.35))}px Vazirmatn, Tahoma, sans-serif`;
      ctx.fillText(rect.col.label, rect.x + rect.w / 2, curY + thH * 0.34);
      ctx.fillStyle = '#CBD5E1';
      ctx.font = `500 ${Math.round(mm(2.0))}px Vazirmatn, Tahoma, sans-serif`;
      ctx.fillText(rect.col.subLabel, rect.x + rect.w / 2, curY + thH * 0.73);
    } else {
      ctx.font = `700 ${Math.round(mm(2.45))}px Vazirmatn, Tahoma, sans-serif`;
      ctx.fillText(rect.col.label, rect.x + rect.w / 2, curY + thH / 2);
    }
  }

  curY += thH;

  // --- Compact High-Density Rows (no redundant full-width group banner rows) ---
  const rh = mm(ROW_H_MM);
  for (let i = 0; i < pageItems.length; i++) {
    const entry = pageItems[i];
    const item = entry.product;
    const isEven = entry.rowStripe % 2 === 0;

    ctx.fillStyle = isEven ? '#FFFFFF' : '#F8FAFC';
    ctx.fillRect(leftX, curY, usableW, rh);

    const values: Record<string, string> = {
      group: entry.isGroupStart ? entry.groupName : '',
      name: item.report.name,
      cashEx: formatToman(item.cash.salesExWarehouse, { dashOnZero: true }),
      cashDel: formatToman(item.cash.salesDelivered, { dashOnZero: true }),
      checkEx: formatToman(item.check.salesExWarehouse, { dashOnZero: true }),
      checkDel: formatToman(item.check.salesDelivered, { dashOnZero: true }),
      checkDays:
        item.manual.checkDays !== null && item.manual.checkDays > 0
          ? toPersianDigits(item.manual.checkDays)
          : '—',
      consumption: formatToman(item.manual.consumptionPrice, { dashOnZero: true }),
      consumer: formatToman(item.manual.consumerPrice, { dashOnZero: true }),
      availStock: formatStock(item.report.availableStock),
      whStock: formatStock(item.report.warehouseStock),
      notes: item.manual.notes || '',
    };

    for (const rect of colRects) {
      // Soft teal highlight on group cell when a new group begins
      if (rect.col.key === 'group' && entry.isGroupStart) {
        ctx.fillStyle = '#E6F6F4';
        ctx.fillRect(rect.x, curY, rect.w, rh);
      }

      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 0.8;
      ctx.strokeRect(rect.x, curY, rect.w, rh);

      const val = values[rect.col.key] ?? '';
      const isPriceCol = ['cashEx', 'cashDel', 'checkEx', 'checkDel'].includes(rect.col.key);

      ctx.fillStyle =
        rect.col.key === 'group'
          ? '#0F766E'
          : isPriceCol && val !== '—'
          ? '#0F172A'
          : val === '—'
          ? '#94A3B8'
          : '#1E293B';

      const weight =
        rect.col.key === 'group'
          ? '700'
          : isPriceCol && val !== '—'
          ? '700'
          : rect.col.key === 'name'
          ? '500'
          : '400';

      ctx.font = `${weight} ${Math.round(
        mm(rect.col.key === 'name' ? 2.25 : 2.2)
      )}px Vazirmatn, Tahoma, sans-serif`;

      const padding = mm(1.3);
      const clipped = fitText(ctx, val, rect.w - padding * 2);

      if (rect.col.align === 'right') {
        ctx.textAlign = 'right';
        ctx.fillText(clipped, rect.x + rect.w - padding, curY + rh / 2 + mm(0.1));
      } else {
        ctx.textAlign = 'center';
        ctx.fillText(clipped, rect.x + rect.w / 2, curY + rh / 2 + mm(0.1));
      }
    }

    // Crisp horizontal divider between product groups
    if (entry.isGroupStart && i > 0) {
      ctx.strokeStyle = '#64748B';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(leftX, curY);
      ctx.lineTo(rightX, curY);
      ctx.stroke();
    }

    curY += rh;
  }

  // Outer crisp border around table body
  ctx.strokeStyle = '#94A3B8';
  ctx.lineWidth = 1.2;
  ctx.strokeRect(leftX, topY + mm(headerHMm), usableW, thH + pageItems.length * rh);

  // --- Compact Footer ---
  const footerY = mm(PAGE_H_MM - MARGIN_Y_MM - 1.8);
  ctx.strokeStyle = '#CBD5E1';
  ctx.lineWidth = 0.9;
  ctx.beginPath();
  ctx.moveTo(leftX, footerY - mm(2.3));
  ctx.lineTo(rightX, footerY - mm(2.3));
  ctx.stroke();

  ctx.fillStyle = '#475569';
  ctx.font = `500 ${Math.round(mm(2.15))}px Vazirmatn, Tahoma, sans-serif`;
  ctx.textAlign = 'right';
  ctx.fillText(`${companyName} — ${title}`, rightX, footerY);

  ctx.textAlign = 'left';
  ctx.fillText(
    `صفحه ${toPersianDigits(pageNumber)} از ${toPersianDigits(totalPages)}`,
    leftX,
    footerY
  );

  return canvas;
}

export async function renderPriceListPdfPages(params: {
  mode: 'sales' | 'visitors';
  items: ComputedProduct[];
  settings: AppSettings;
  jalaliDate: string;
}): Promise<string[]> {
  // Ensure Vazirmatn webfont is ready before rendering Persian text onto canvas
  if (typeof document !== 'undefined' && document.fonts && document.fonts.ready) {
    await document.fonts.ready;
  }

  const title = params.mode === 'sales' ? 'لیست قیمت بخش فروش' : 'لیست قیمت ویزیتورها';
  const pages = buildRenderPages(params.items);

  return pages.map((pageItems, idx) => {
    const canvas = drawPageCanvas({
      mode: params.mode,
      pageItems,
      pageNumber: idx + 1,
      totalPages: pages.length,
      title,
      companyName: params.settings.companyName,
      jalaliDate: params.jalaliDate,
      totalItemsCount: params.items.length,
    });
    return canvas.toDataURL('image/jpeg', 0.94);
  });
}

export async function exportPriceListPdf(params: {
  mode: 'sales' | 'visitors';
  items: ComputedProduct[];
  settings: AppSettings;
  jalaliDate: string;
}): Promise<number> {
  const pageDataUrls = await renderPriceListPdfPages(params);
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  pageDataUrls.forEach((dataUrl, idx) => {
    if (idx > 0) doc.addPage('a4', 'landscape');
    doc.addImage(dataUrl, 'JPEG', 0, 0, PAGE_W_MM, PAGE_H_MM, undefined, 'FAST');
  });

  const safeDate = params.jalaliDate.replace(/\//g, '-');
  const fileName =
    params.mode === 'sales'
      ? `لیست-قیمت-بخش-فروش-${safeDate}.pdf`
      : `لیست-قیمت-ویزیتورها-${safeDate}.pdf`;
  doc.save(fileName);
  return pageDataUrls.length;
}
