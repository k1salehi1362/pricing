import ExcelJS from 'exceljs';
import {
  AppSettings,
  ComputedProduct,
  PriceChangeLogEntry,
  UploadLogEntry,
} from '../types/pricing';
import { calculateShippingMetrics } from './pricingEngine';

function triggerBlobDownload(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const FONT_NAME = 'Tahoma';

function applyPriceListSheet(
  ws: ExcelJS.Worksheet,
  mode: 'sales' | 'visitors',
  items: ComputedProduct[],
  title: string,
  companyName: string,
  jalaliDate: string,
  minAvail: number,
  minWarehouse: number
): void {
  const isSales = mode === 'sales';
  const lastColLetter = isSales ? 'L' : 'J';
  const totalCols = isSales ? 12 : 10;

  ws.views = [
    {
      rightToLeft: true,
      state: 'frozen',
      ySplit: 4,
    },
  ];

  // Title Row 1
  ws.mergeCells(`A1:${lastColLetter}1`);
  const titleCell = ws.getCell('A1');
  titleCell.value = `${companyName} — ${title}`;
  titleCell.font = { name: FONT_NAME, size: 14, bold: true, color: { argb: 'FFFFFFFF' } };
  titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F766E' } };
  titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(1).height = 30;

  // Subtitle / Date Row 2
  ws.mergeCells(`A2:${lastColLetter}2`);
  const metaCell = ws.getCell('A2');
  metaCell.value = `تاریخ لیست: ${jalaliDate}   |   کلیه قیمت‌ها به تومان می‌باشد   |   تعداد اقلام: ${items.length}   |   شرط نمایش: قابل فروش > ${minAvail} یا انبار > ${minWarehouse}`;
  metaCell.font = { name: FONT_NAME, size: 10, bold: false, color: { argb: 'FF0F172A' } };
  metaCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF1F5F9' } };
  metaCell.alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(2).height = 22;

  // Spacer Row 3
  ws.getRow(3).height = 8;

  // Header Row 4 (12 columns for Sales, 10 columns without درب انبار for Visitors)
  const headers = isSales
    ? [
        'گروه کالا',
        'نام محصول',
        'فروش نقدی - درب انبار شرکت (تومان)',
        'فروش نقدی - تحویلی انبار مشتری (تومان)',
        'فروش چکی - درب انبار شرکت (تومان)',
        'فروش چکی - تحویلی انبار مشتری (تومان)',
        'مدت چک (روز)',
        'قیمت مصرف (تومان)',
        'قیمت مصرف‌کننده (تومان)',
        'موجودی قابل فروش',
        'موجودی انبار',
        'توضیحات',
      ]
    : [
        'گروه کالا',
        'نام محصول',
        'فروش نقدی - تحویلی انبار مشتری (تومان)',
        'فروش چکی - تحویلی انبار مشتری (تومان)',
        'مدت چک (روز)',
        'قیمت مصرف (تومان)',
        'قیمت مصرف‌کننده (تومان)',
        'موجودی قابل فروش',
        'موجودی انبار',
        'توضیحات',
      ];

  const headerRow = ws.getRow(4);
  headerRow.values = headers;
  headerRow.height = 32;
  headerRow.eachCell((cell) => {
    cell.font = { name: FONT_NAME, size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = {
      top: { style: 'thin', color: { argb: 'FF334155' } },
      bottom: { style: 'medium', color: { argb: 'FF0F766E' } },
      left: { style: 'thin', color: { argb: 'FF475569' } },
      right: { style: 'thin', color: { argb: 'FF475569' } },
    };
  });

  // Set Column Widths
  const widths = isSales
    ? [16, 40, 20, 22, 20, 22, 13, 16, 18, 15, 14, 24]
    : [16, 44, 24, 24, 14, 17, 19, 16, 15, 28];
  widths.forEach((w, idx) => {
    ws.getColumn(idx + 1).width = w;
  });

  // AutoFilter on Row 4
  ws.autoFilter = {
    from: { row: 4, column: 1 },
    to: { row: 4 + Math.max(items.length, 1), column: totalCols },
  };

  const priceColSet = isSales ? new Set([3, 4, 5, 6, 8, 9]) : new Set([3, 4, 6, 7]);
  const stockColSet = isSales ? new Set([10, 11]) : new Set([8, 9]);
  const notesCol = totalCols;

  let prevGroup = '';
  let rowIndex = 5;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const groupName = item.report.salesGroup || 'سایر';
    const isNewGroup = groupName !== prevGroup;
    prevGroup = groupName;

    const cashEx =
      item.cash.salesExWarehouse !== null && item.cash.salesExWarehouse > 0
        ? Math.round(item.cash.salesExWarehouse)
        : '—';
    const cashDel =
      item.cash.salesDelivered !== null && item.cash.salesDelivered > 0
        ? Math.round(item.cash.salesDelivered)
        : '—';
    const checkEx =
      item.check.salesExWarehouse !== null && item.check.salesExWarehouse > 0
        ? Math.round(item.check.salesExWarehouse)
        : '—';
    const checkDel =
      item.check.salesDelivered !== null && item.check.salesDelivered > 0
        ? Math.round(item.check.salesDelivered)
        : '—';

    const consumptionVal =
      item.manual.consumptionPrice !== null && item.manual.consumptionPrice > 0
        ? Math.round(item.manual.consumptionPrice)
        : '—';
    const consumerVal =
      item.manual.consumerPrice !== null && item.manual.consumerPrice > 0
        ? Math.round(item.manual.consumerPrice)
        : '—';

    const row = ws.getRow(rowIndex);
    row.values = isSales
      ? [
          groupName,
          item.report.name,
          cashEx,
          cashDel,
          checkEx,
          checkDel,
          item.manual.checkDays ?? '—',
          consumptionVal,
          consumerVal,
          item.report.availableStock,
          item.report.warehouseStock,
          item.manual.notes || '',
        ]
      : [
          groupName,
          item.report.name,
          cashDel,
          checkDel,
          item.manual.checkDays ?? '—',
          consumptionVal,
          consumerVal,
          item.report.availableStock,
          item.report.warehouseStock,
          item.manual.notes || '',
        ];
    row.height = 22;

    const bgHex = i % 2 === 0 ? 'FFFFFFFF' : 'FFF8FAFC';

    row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      cell.font = {
        name: FONT_NAME,
        size: 10,
        bold: colNumber === 1 && isNewGroup ? true : false,
        color: { argb: colNumber === 1 ? 'FF0F766E' : 'FF0F172A' },
      };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: {
          argb: colNumber === 1 && isNewGroup ? 'FFCCFBF1' : bgHex,
        },
      };
      cell.border = {
        top: {
          style: isNewGroup && i > 0 ? 'medium' : 'thin',
          color: { argb: isNewGroup && i > 0 ? 'FF94A3B8' : 'FFE2E8F0' },
        },
        bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        right: { style: 'thin', color: { argb: 'FFE2E8F0' } },
      };

      if (colNumber === 2 || colNumber === notesCol) {
        cell.alignment = { horizontal: 'right', vertical: 'middle', wrapText: true };
      } else {
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
      }

      if (priceColSet.has(colNumber)) {
        if (typeof cell.value === 'number') {
          cell.numFmt = '#,##0';
        }
      } else if (stockColSet.has(colNumber)) {
        if (typeof cell.value === 'number') {
          cell.numFmt = Number.isInteger(cell.value) ? '#,##0' : '#,##0.##';
        }
      }
    });

    rowIndex++;
  }

  ws.pageSetup = {
    paperSize: 9, // A4
    orientation: 'landscape',
    fitToPage: true,
    fitToWidth: 1,
    fitToHeight: 0,
  };
}

export async function exportPriceListExcel(params: {
  mode: 'sales' | 'visitors';
  items: ComputedProduct[];
  settings: AppSettings;
  jalaliDate: string;
}): Promise<void> {
  const { mode, items, settings, jalaliDate } = params;
  const wb = new ExcelJS.Workbook();
  wb.creator = settings.companyName;
  wb.created = new Date();

  const sheetTitle = mode === 'sales' ? 'ارایه به بخش فروش' : 'ارایه به ویزیتورها';
  const docTitle = mode === 'sales' ? 'لیست قیمت بخش فروش' : 'لیست قیمت ویزیتورها';
  const minA = settings.salesMinAvailable;
  const minW = settings.salesMinWarehouse;

  const ws = wb.addWorksheet(sheetTitle);
  applyPriceListSheet(ws, mode, items, docTitle, settings.companyName, jalaliDate, minA, minW);

  const buffer = await wb.xlsx.writeBuffer();
  const safeDate = jalaliDate.replace(/\//g, '-');
  const fileName =
    mode === 'sales'
      ? `لیست-قیمت-بخش-فروش-${safeDate}.xlsx`
      : `لیست-قیمت-ویزیتورها-${safeDate}.xlsx`;
  triggerBlobDownload(
    new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    }),
    fileName
  );
}

export async function exportComprehensivePricingExcel(params: {
  allProducts: ComputedProduct[];
  salesItems: ComputedProduct[];
  visitorItems: ComputedProduct[];
  settings: AppSettings;
  jalaliDate: string;
  uploadLogs: UploadLogEntry[];
  priceChangeLogs: PriceChangeLogEntry[];
}): Promise<void> {
  const {
    allProducts,
    salesItems,
    visitorItems,
    settings,
    jalaliDate,
    uploadLogs,
    priceChangeLogs,
  } = params;
  const wb = new ExcelJS.Workbook();
  wb.creator = settings.companyName;
  wb.created = new Date();

  // Sheet 1: قیمت گذاری (Full 2-row per product sheet)
  const wsPrice = wb.addWorksheet('قیمت گذاری');
  wsPrice.views = [{ rightToLeft: true, state: 'frozen', ySplit: 3 }];

  wsPrice.mergeCells('A1:X1');
  const pTitle = wsPrice.getCell('A1');
  pTitle.value = `${settings.companyName} — فایل جامع قیمت‌گذاری (تاریخ: ${jalaliDate})`;
  pTitle.font = { name: FONT_NAME, size: 13, bold: true, color: { argb: 'FFFFFFFF' } };
  pTitle.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F766E' } };
  pTitle.alignment = { horizontal: 'center', vertical: 'middle' };
  wsPrice.getRow(1).height = 28;

  const priceHeaders = [
    'کد کالا',
    'نام کالا',
    'گروه خرید',
    'گروه فروش',
    'شرایط فروش',
    'وزن واحد (دستی)',
    'فی متوسط انبار',
    'آخرین قیمت خرید',
    'قیمت خرید مبنا',
    'منبع قیمت مبنا',
    'ارزش افزوده % (دستی)',
    'حمل تا انبار (دستی)',
    'هزینه تمام‌شده',
    'قیمت فروش درب انبار (دستی)',
    'حاشیه سود',
    'حمل به مشتری',
    'قیمت تحویلی مشتری (لیست فروش)',
    'سود نهایی',
    'درصد سود واقعی',
    'مبلغ ارزش افزوده (ستون X)',
    'ستون کمکی AD (Q+X)',
    'ستون کمکی AE (T×مالیات)',
    'موجودی قابل فروش',
    'موجودی انبار',
  ];

  const hRow = wsPrice.getRow(3);
  hRow.values = priceHeaders;
  hRow.height = 30;
  hRow.eachCell((cell) => {
    cell.font = { name: FONT_NAME, size: 9, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  });

  const pWidths = [11, 36, 15, 15, 10, 11, 15, 15, 15, 17, 12, 14, 15, 17, 11, 13, 16, 15, 12, 14, 17, 17, 13, 12];
  pWidths.forEach((w, idx) => {
    wsPrice.getColumn(idx + 1).width = w;
  });

  const manualCols = new Set([6, 11, 12, 14]);
  let rIdx = 4;
  for (const item of allProducts) {
    for (const termRow of [item.cash, item.check]) {
      const row = wsPrice.getRow(rIdx);
      row.values = [
        item.report.code,
        item.report.name,
        item.report.buyGroup,
        item.report.salesGroup,
        termRow.term,
        termRow.manual.weight ?? '',
        item.report.avgCost !== null ? Math.round(item.report.avgCost) : '',
        item.report.lastPurchasePrice !== null ? Math.round(item.report.lastPurchasePrice) : '',
        item.report.basisPrice !== null ? Math.round(item.report.basisPrice) : '',
        item.report.basisSource,
        termRow.manual.vatRate ?? 0,
        termRow.manual.inboundShipping ?? 0,
        termRow.landedCost !== null ? Math.round(termRow.landedCost) : '',
        termRow.manual.exWarehousePrice !== null && termRow.manual.exWarehousePrice > 0
          ? Math.round(termRow.manual.exWarehousePrice)
          : '',
        termRow.grossMargin !== null ? termRow.grossMargin : '',
        termRow.customerShipping !== null ? Math.round(termRow.customerShipping) : '',
        termRow.deliveredExVat !== null ? Math.round(termRow.deliveredExVat) : '',
        termRow.netProfit !== null ? Math.round(termRow.netProfit) : '',
        termRow.profitPercent !== null ? termRow.profitPercent : '',
        termRow.vatAmount !== null ? Math.round(termRow.vatAmount) : '',
        termRow.finalExWarehouse !== null ? Math.round(termRow.finalExWarehouse) : '',
        termRow.finalDelivered !== null ? Math.round(termRow.finalDelivered) : '',
        item.report.availableStock,
        item.report.warehouseStock,
      ];
      row.height = 20;
      row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
        cell.font = { name: FONT_NAME, size: 9, color: { argb: 'FF0F172A' } };
        if (manualCols.has(colNumber)) {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEF9C3' } };
        }
        cell.border = {
          top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
          bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
          left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
          right: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        };
        cell.alignment = {
          horizontal: colNumber === 2 ? 'right' : 'center',
          vertical: 'middle',
        };
        if ([7, 8, 9, 12, 13, 14, 16, 17, 18, 20, 21, 22].includes(colNumber) && typeof cell.value === 'number') {
          cell.numFmt = '#,##0';
        } else if ((colNumber === 15 || colNumber === 19) && typeof cell.value === 'number') {
          cell.numFmt = '0.0%';
        }
      });
      rIdx++;
    }
  }

  wsPrice.autoFilter = {
    from: { row: 3, column: 1 },
    to: { row: Math.max(rIdx - 1, 3), column: 24 },
  };

  // Sheet 2: ارایه به بخش فروش
  const wsSales = wb.addWorksheet('ارایه به بخش فروش');
  applyPriceListSheet(
    wsSales,
    'sales',
    salesItems,
    'لیست قیمت بخش فروش',
    settings.companyName,
    jalaliDate,
    settings.salesMinAvailable,
    settings.salesMinWarehouse
  );

  // Sheet 3: ارایه به ویزیتورها
  const wsVisitors = wb.addWorksheet('ارایه به ویزیتورها');
  applyPriceListSheet(
    wsVisitors,
    'visitors',
    visitorItems,
    'لیست قیمت ویزیتورها',
    settings.companyName,
    jalaliDate,
    settings.salesMinAvailable,
    settings.salesMinWarehouse
  );

  // Sheet 4: تنظیمات حمل و تاریخچه
  const wsMeta = wb.addWorksheet('تنظیمات و تاریخچه');
  wsMeta.views = [{ rightToLeft: true }];
  const shipping = calculateShippingMetrics(settings);

  wsMeta.getColumn(1).width = 24;
  wsMeta.getColumn(2).width = 20;
  wsMeta.getColumn(3).width = 18;
  wsMeta.getColumn(4).width = 22;

  wsMeta.addRow(['تنظیمات محاسبه کرایه حمل (سایپا)']).font = {
    name: FONT_NAME,
    size: 12,
    bold: true,
  };
  wsMeta.addRow(['شهر مقصد', 'کرایه سایپا (تومان)', 'تعداد سرویس', 'جمع وزنی (تومان)']);
  for (const c of settings.cityFares) {
    wsMeta.addRow([c.city, c.fare, c.trips, c.fare * c.trips]);
  }
  wsMeta.addRow([]);
  wsMeta.addRow(['میانگین موزون کرایه شهرها (تومان)', Math.round(shipping.weightedAvgFare)]);
  wsMeta.addRow(['ضریب پوشش نوسان (%)', settings.fluctuationPercent]);
  wsMeta.addRow(['کرایه مبنا با پوشش نوسان (تومان)', Math.round(shipping.baseFareWithCoverage)]);
  wsMeta.addRow(['ظرفیت بارگیری سایپا (کیلوگرم)', shipping.truckCapacityKg]);
  wsMeta.addRow(['هزینه حمل هر کیلوگرم (تومان)', Number(shipping.costPerKg.toFixed(2))]);
  wsMeta.addRow([]);
  wsMeta.addRow(['سوابق بارگذاری گزارش‌ها', 'فایل قابل فروش', 'فایل انبار', 'تعداد کل فعال']);
  for (const log of uploadLogs.slice(0, 50)) {
    wsMeta.addRow([
      log.jalaliDateTime,
      log.sellableFileName,
      log.warehouseFileName,
      log.totalActiveCount,
    ]);
  }
  wsMeta.addRow([]);
  wsMeta.addRow(['تاریخ تغییرات قیمت', 'کد و نام کالا', 'نوع', 'تغییر']);
  for (const ch of priceChangeLogs.slice(0, 100)) {
    wsMeta.addRow([
      `${ch.jalaliDate} ${ch.jalaliTime}`,
      `${ch.code} - ${ch.productName}`,
      `${ch.term} (${ch.fieldLabel})`,
      `${ch.oldValue} ← ${ch.newValue}`,
    ]);
  }

  const buffer = await wb.xlsx.writeBuffer();
  const safeDate = jalaliDate.replace(/\//g, '-');
  triggerBlobDownload(
    new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    }),
    `فایل-جامع-قیمت-گذاری-${safeDate}.xlsx`
  );
}
