import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  DEFAULT_SETTINGS,
  calculateShippingMetrics,
  computeAllProducts,
  computeTermPricing,
  mergeDailyReports,
  normFa,
  normalizeCode,
  passesStockThreshold,
  roundExcel,
} from './pricingEngine';
import { parseDelimitedText, parseSellableMatrix, parseWarehouseMatrix } from './fileParsers';
import { gregorianToJalali } from './jalali';
import { buildInitialAppState } from '../data/seedData';

test('normalizeCode preserves leading zeros and normalizes Persian digits & Excel float strings', () => {
  assert.equal(normalizeCode('00123'), '00123');
  assert.equal(normalizeCode('  1001.0 '), '1001');
  assert.equal(normalizeCode(1169), '1169');
  assert.equal(normalizeCode('۱۰۲۴'), '1024');
  assert.equal(normalizeCode(''), '');
  assert.equal(normalizeCode(null), '');
});

test('normFa converts Arabic Yeh/Kaf to Persian Yeh/Kaf', () => {
  assert.equal(normFa('  برنج هندي كيسه  '), 'برنج هندی کیسه');
});

test('17-city Saipa shipping calculation matches Excel AB21:AB25 exactly', () => {
  const m = calculateShippingMetrics(DEFAULT_SETTINGS);
  assert.equal(m.totalTrips, 17);
  assert.equal(m.weightedSum, 63500000);
  assert.ok(Math.abs(m.weightedAvgFare - 63500000 / 17) < 1e-6);
  assert.equal(m.fluctuationFactor, 0.15);
  assert.ok(Math.abs(m.baseFareWithCoverage - (63500000 / 17) * 1.15) < 1e-6);
  assert.equal(m.truckCapacityKg, 2500);
  assert.ok(Math.abs(m.costPerKg - ((63500000 / 17) * 1.15) / 2500) < 1e-6);
  // costPerKg is ~1718.2353 Toman/kg -> 1kg rounds to 1700 Toman
  assert.equal(roundExcel(1 * m.costPerKg, -2), 1700);
});

test('pricing formulas match real Excel rows (1169, 1136, 1142, 1012)', () => {
  const shipping = calculateShippingMetrics(DEFAULT_SETTINGS);

  // Sample 1: 1169 برنج هندی 1718 دمکش (weight=1, vat=0, inbound=0, basis=267768.1, Q_cash=275000)
  const r1169 = computeTermPricing(
    'نقدی',
    267768.1,
    { weight: 1, vatRate: 0, inboundShipping: 0, exWarehousePrice: 275000 },
    shipping.costPerKg
  );
  assert.ok(Math.abs((r1169.landedCost ?? 0) - 267768.1) < 1e-6);
  assert.equal(r1169.customerShipping, 1700);
  assert.equal(r1169.deliveredExVat, 276700);
  assert.equal(r1169.afterShippingCheck, 275000);
  assert.ok(Math.abs((r1169.netProfit ?? 0) - 7231.9) < 1e-6);
  assert.ok(Math.abs((r1169.grossMargin ?? 0) - 7231.9 / 275000) < 1e-6);
  assert.ok(Math.abs((r1169.profitPercent ?? 0) - 7231.9 / 267768.1) < 1e-6);
  assert.equal(r1169.vatAmount, 0);
  assert.equal(r1169.finalExWarehouse, 275000);
  assert.equal(r1169.finalDelivered, 276700);

  // Sample 2: 1136 رب شیشه 1500 گرمی اسبق (weight=2.1, vat=10%, inbound=0, basis=356818.18182, Q_cash=450000)
  const r1136 = computeTermPricing(
    'نقدی',
    356818.18182,
    { weight: 2.1, vatRate: 10, inboundShipping: 0, exWarehousePrice: 450000 },
    shipping.costPerKg
  );
  assert.ok(Math.abs((r1136.landedCost ?? 0) - 392500.000002) < 1e-3);
  assert.equal(r1136.customerShipping, 3600); // ROUND(2.1 * 1718.2353, -2) = 3600
  assert.equal(r1136.deliveredExVat, 453600);
  assert.equal(r1136.vatAmount, 45000);
  assert.equal(r1136.finalExWarehouse, 495000);
  assert.equal(r1136.finalDelivered, 499000); // ROUND(453600 * 1.1, -2) = ROUND(498960, -2) = 499000

  // Sample 3: 1142 ماکارونی فرمی بریده 1000 گرمی ابتکار (weight=1, vat=10%, inbound=2500, basis=100363.15789473684, Q_cash=130000)
  const r1142 = computeTermPricing(
    'نقدی',
    100363.15789473684,
    { weight: 1, vatRate: 10, inboundShipping: 2500, exWarehousePrice: 130000 },
    shipping.costPerKg
  );
  const expectedLanded = 100363.15789473684 * 1.1 + 2500;
  assert.ok(Math.abs((r1142.landedCost ?? 0) - expectedLanded) < 1e-4);
  assert.equal(r1142.customerShipping, 1700);
  assert.equal(r1142.deliveredExVat, 131700);
  assert.equal(r1142.vatAmount, 13000);
  assert.equal(r1142.finalExWarehouse, 143000);
  assert.equal(r1142.finalDelivered, 144900); // ROUND(131700 * 1.1, -2) = ROUND(144870, -2) = 144900

  // Sample 4: Unpriced & missing basis (1012) avoids NaN / division by zero
  const r1012 = computeTermPricing(
    'نقدی',
    null,
    { weight: 1, vatRate: 0, inboundShipping: 0, exWarehousePrice: null },
    shipping.costPerKg
  );
  assert.equal(r1012.landedCost, null);
  assert.equal(r1012.grossMargin, null);
  assert.equal(r1012.netProfit, null);
  assert.equal(r1012.profitPercent, null);
  assert.equal(r1012.finalExWarehouse, null);
  assert.equal(r1012.finalDelivered, null);
  assert.equal(r1012.salesExWarehouse, null);
  assert.equal(r1012.salesDelivered, null);
});

test('VAT-taxable items (1175 ماکارونی پیچی سبزیجات, 1142, 1180) do NOT double-count VAT in sales output prices', () => {
  const initial = buildInitialAppState();
  const computed = computeAllProducts(initial.products, initial.manualData, initial.settings);

  // Item 1175: ماکارونی پیچی سبزیجات 1000 گرمی ابتکار
  // H=139,813.63, VAT=10% => O=153,795 (already includes 10% VAT)
  // Q_cash=180,000, S=1,700 => T_cash=181,700
  // Q_check=185,000, S=1,700 => T_check=186,700 (consumer price = 202,720)
  const p1175 = computed.find((c) => c.report.code === '1175');
  assert.ok(p1175);
  assert.ok(Math.abs((p1175.cash.landedCost ?? 0) - 153794.993) < 0.01);
  assert.equal(p1175.cash.customerShipping, 1700);
  assert.equal(p1175.cash.salesExWarehouse, 180000);
  assert.equal(p1175.cash.salesDelivered, 181700);
  assert.equal(p1175.check.salesExWarehouse, 185000);
  assert.equal(p1175.check.salesDelivered, 186700);
  assert.ok((p1175.check.salesDelivered ?? 0) < (p1175.manual.consumerPrice ?? 0));

  // Item 1142: ماکارونی فرمی بریده 1000 گرمی ابتکار (consumer = 150,000)
  const p1142 = computed.find((c) => c.report.code === '1142');
  assert.ok(p1142);
  assert.equal(p1142.cash.salesExWarehouse, 130000);
  assert.equal(p1142.cash.salesDelivered, 131700);
  assert.equal(p1142.check.salesExWarehouse, 135000);
  assert.equal(p1142.check.salesDelivered, 136700);

  // Item 1180: سس کچاب موشکی 510 گرمی دلپذیر (weight=0.51 => S=900, O=125,400, Q_cash=125,400, Q_check=131,670)
  const p1180 = computed.find((c) => c.report.code === '1180');
  assert.ok(p1180);
  assert.equal(p1180.cash.customerShipping, 900);
  assert.equal(p1180.cash.salesExWarehouse, 125400);
  assert.equal(p1180.cash.salesDelivered, 126300);
  assert.equal(p1180.check.salesExWarehouse, 131670);
  assert.equal(p1180.check.salesDelivered, 132570);
});

test('OR threshold filtering works and Sales & Visitors lists always expose identical products', () => {
  // avail=0, wh=60 -> true (60>50)
  assert.equal(passesStockThreshold(0, 60, 0, 50), true);
  // avail=7, wh=7 -> true (7>0)
  assert.equal(passesStockThreshold(7, 7, 0, 50), true);
  // avail=0, wh=50 -> false (0<=0 AND 50<=50)
  assert.equal(passesStockThreshold(0, 50, 0, 50), false);
  // avail=10, wh=0 -> true (10>0)
  assert.equal(passesStockThreshold(10, 0, 0, 50), true);

  // Even if legacy settings had different visitor thresholds, Sales & Visitors products must match 100%
  const initial = buildInitialAppState();
  const computed = computeAllProducts(initial.products, initial.manualData, {
    ...initial.settings,
    visitorsMinAvailable: 10,
    visitorsMinWarehouse: 0,
  });
  const salesCodes = computed.filter((p) => p.isSalesVisible).map((p) => p.report.code);
  const visitorCodes = computed.filter((p) => p.isVisitorsVisible).map((p) => p.report.code);
  assert.deepEqual(visitorCodes, salesCodes);
  assert.equal(salesCodes.length, 68);
});

test('Real attached files 02 and 03 parse cleanly, merge with 04, and preserve manual prices', () => {
  const initial = buildInitialAppState();
  assert.equal(initial.products.length, 186);

  // Edit a manual price before uploading new reports
  initial.manualData['1169'].cash.exWarehousePrice = 289000;
  initial.manualData['1169'].notes = 'تست حفظ اطلاعات دستی';

  const rawSellable = fs.readFileSync(
    'public/assets/aistudio/02__________________fd93035c.txt',
    'utf8'
  );
  const rawWarehouse = fs.readFileSync(
    'public/assets/aistudio/03______________7193e4ee.txt',
    'utf8'
  );

  const parsedSal = parseSellableMatrix(parseDelimitedText(rawSellable), 'موجودی قابل فروش.txt');
  const parsedWh = parseWarehouseMatrix(parseDelimitedText(rawWarehouse), 'موجودی انبار.txt');

  assert.equal(parsedSal.errors.length, 0);
  assert.equal(parsedWh.errors.length, 0);
  assert.ok(parsedSal.validRows.length > 100);
  assert.ok(parsedWh.validRows.length > 100);

  const merged = mergeDailyReports(
    initial.products,
    initial.manualData,
    parsedSal.validRows,
    parsedWh.validRows,
    initial.settings
  );

  // Manual edits on 1169 MUST survive the merge untouched
  assert.equal(merged.nextManualMap['1169'].cash.exWarehousePrice, 289000);
  assert.equal(merged.nextManualMap['1169'].notes, 'تست حفظ اطلاعات دستی');

  // Verify basis price priority & Rial -> Toman conversion on 1169
  const p1169 = merged.nextProducts.find((p) => p.code === '1169');
  assert.ok(p1169);
  assert.equal(p1169.basisPrice, 267768.1);
  assert.equal(p1169.basisSource, 'موجودی قابل فروش');

  // Verify item only in Warehouse report (e.g. 1196) is still included and uses avgCost
  const p1196 = merged.nextProducts.find((p) => p.code === '1196');
  assert.ok(p1196);
  assert.equal(p1196.basisPrice, 139090.8);
  assert.equal(p1196.basisSource, 'موجودی انبار');

  // Verify group ordering puts برنج هندی before برنج پاکستانی before روغن جامد
  const computed = computeAllProducts(merged.nextProducts, merged.nextManualMap, initial.settings);
  const firstHindi = computed.findIndex((c) => c.report.salesGroup === 'برنج هندی');
  const firstPakistani = computed.findIndex((c) => c.report.salesGroup === 'برنج پاکستانی');
  const firstOil = computed.findIndex((c) => c.report.salesGroup === 'روغن جامد');
  assert.ok(firstHindi >= 0 && firstHindi < firstPakistani && firstPakistani < firstOil);
});

test('Disappeared item hides from active list without losing manual data, and restores when it reappears', () => {
  const initial = buildInitialAppState();
  initial.manualData['1169'].cash.exWarehousePrice = 311000;

  // Day 1: report without 1169
  const day1 = mergeDailyReports(
    initial.products,
    initial.manualData,
    [
      {
        code: '1154',
        name: 'برنج 1121 هندی هزار دستان',
        buyGroup: 'برنج',
        salesGroup: 'برنج هندی',
        availableStock: 10,
        lastPurchasePriceRial: 2450000,
        taxRaw: 0,
        rowNumber: 2,
      },
    ],
    [],
    initial.settings
  );

  assert.equal(day1.nextProducts.length, 1);
  assert.equal(day1.nextProducts.find((p) => p.code === '1169'), undefined);
  // Manual data for 1169 MUST still exist in manualMap!
  assert.equal(day1.nextManualMap['1169'].cash.exWarehousePrice, 311000);

  // Day 2: 1169 returns in report -> manual data restored!
  const day2 = mergeDailyReports(
    day1.nextProducts,
    day1.nextManualMap,
    [
      {
        code: '1169',
        name: 'برنج هندی 1718 دمکش',
        buyGroup: 'برنج',
        salesGroup: 'برنج هندی',
        availableStock: 500,
        lastPurchasePriceRial: 2677681,
        taxRaw: 0,
        rowNumber: 2,
      },
    ],
    [],
    initial.settings
  );

  assert.equal(day2.nextProducts.length, 1);
  assert.equal(day2.summary.restoredManualCount, 1);
  assert.equal(day2.nextManualMap['1169'].cash.exWarehousePrice, 311000);
});

test('Duplicate codes are reported without silent aggregation and keep last row on merge', () => {
  const matrix = [
    ['کد', 'عنوان', 'گروه خرید', 'گروه فروش', 'موجودی قابل فروش', 'آخرین قیمت خرید', 'مالیات'],
    ['1001', 'شکر فله', 'شکر', 'شکر فله', 100, 1000000, 0],
    ['1001', 'شکر فله', 'شکر', 'شکر فله', 250, 1200000, 0],
  ];
  const parsed = parseSellableMatrix(matrix, 'test.xlsx');
  assert.equal(parsed.duplicates.length, 1);
  assert.equal(parsed.duplicates[0].code, '1001');
  assert.equal(parsed.duplicates[0].occurrences.length, 2);

  const merged = mergeDailyReports([], {}, parsed.validRows, [], DEFAULT_SETTINGS);
  // Not aggregated to 350; VBS-compatible last row (250) wins
  assert.equal(merged.nextProducts[0].availableStock, 250);
  assert.equal(merged.nextProducts[0].basisPrice, 120000);
});

test('Gregorian to Jalali conversion matches known calendar dates', () => {
  assert.deepEqual(gregorianToJalali(2024, 3, 20), [1403, 1, 1]);
  assert.deepEqual(gregorianToJalali(2025, 3, 21), [1404, 1, 1]);
});
