import {
  AppSettings,
  BasisPriceSource,
  CityFare,
  ComputedProduct,
  ComputedTermPricing,
  MergeSummary,
  ProductManualData,
  ProductReportData,
  SaleTerm,
  SellableReportRow,
  ShippingMetrics,
  TermManualInput,
  WarehouseReportRow,
} from '../types/pricing';
import { toLatinDigits } from './jalali';

export const DEFAULT_GROUP_ORDER: string[] = [
  'برنج هندی',
  'برنج پاکستانی',
  'برنج ایرانی',
  'روغن جامد',
  'روغن مایع',
  'حبوبات',
  'چای',
  'رب',
  'آبلیمو',
  'ماکارونی',
  'شامپو',
  'خرما',
  'قند',
  'شکر فله',
  'خشکبار',
  'ادویه',
];

export const DEFAULT_CITY_FARES: CityFare[] = [
  { id: 'c1', city: 'سقز', fare: 2000000, trips: 1 },
  { id: 'c2', city: 'بانه', fare: 3500000, trips: 1 },
  { id: 'c3', city: 'مریوان', fare: 5000000, trips: 1 },
  { id: 'c4', city: 'سنندج', fare: 5000000, trips: 1 },
  { id: 'c5', city: 'دیواندره', fare: 4000000, trips: 1 },
  { id: 'c6', city: 'تکاب', fare: 4500000, trips: 1 },
  { id: 'c7', city: 'شاهیندژ', fare: 3000000, trips: 1 },
  { id: 'c8', city: 'بوکان', fare: 1000000, trips: 1 },
  { id: 'c9', city: 'میاندوآب', fare: 2000000, trips: 1 },
  { id: 'c10', city: 'ملکان', fare: 3000000, trips: 1 },
  { id: 'c11', city: 'بناب', fare: 3500000, trips: 1 },
  { id: 'c12', city: 'ارومیه', fare: 4500000, trips: 1 },
  { id: 'c13', city: 'اشنویه', fare: 4000000, trips: 1 },
  { id: 'c14', city: 'پیرانشهر', fare: 4500000, trips: 1 },
  { id: 'c15', city: 'سردشت', fare: 6000000, trips: 1 },
  { id: 'c16', city: 'تبریز', fare: 5500000, trips: 1 },
  { id: 'c17', city: 'مهاباد', fare: 2500000, trips: 1 },
];

export const DEFAULT_SETTINGS: AppSettings = {
  companyName: 'بازرگانی و پخش عمده مواد غذایی',
  customListDate: '',
  defaultVatRate: 0,
  salesMinAvailable: 0,
  salesMinWarehouse: 50,
  visitorsMinAvailable: 0,
  visitorsMinWarehouse: 50,
  fluctuationPercent: 15,
  truckCapacityKg: 2500,
  cityFares: DEFAULT_CITY_FARES,
  groupOrder: DEFAULT_GROUP_ORDER,
};

/**
 * Normalize Arabic Yeh/Kaf to Persian Yeh/Kaf and trim whitespace.
 * Matches VBS NormFa().
 */
export function normFa(input: unknown): string {
  if (input === null || input === undefined) return '';
  return String(input)
    .replace(/\u064A/g, '\u06CC') // ي -> ی
    .replace(/\u0643/g, '\u06A9') // ك -> ک
    .trim();
}

/**
 * Normalize product code strictly as String, preserving leading zeros while
 * normalizing numeric Excel values (e.g. 1001.0 -> "1001") and Persian digits.
 */
export function normalizeCode(input: unknown): string {
  if (input === null || input === undefined) return '';
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return '';
    return Number.isInteger(input) ? String(input) : String(input).trim();
  }
  const raw = toLatinDigits(String(input)).trim();
  if (!raw) return '';
  // Preserve strings with leading zeros like "00123"
  if (/^0\d+$/.test(raw)) {
    return raw;
  }
  // Normalize Excel float-string artifacts like "1001.0"
  if (/^\d+\.0+$/.test(raw)) {
    return raw.split('.')[0];
  }
  return raw;
}

/**
 * Parse a cell value into a finite number or null.
 * Treats empty strings, dashes ("—", "-"), and non-numeric strings as null.
 */
export function parseOptionalNumber(input: unknown): number | null {
  if (input === null || input === undefined) return null;
  if (typeof input === 'number') {
    return Number.isFinite(input) ? input : null;
  }
  const str = toLatinDigits(String(input))
    .replace(/,/g, '')
    .replace(/٬/g, '')
    .replace(/،/g, '')
    .trim();
  if (!str || str === '—' || str === '-' || str === '–') return null;
  const num = Number(str);
  return Number.isFinite(num) ? num : null;
}

/**
 * Positive number or null (matches VBS PositiveOrEmpty).
 */
export function positiveOrNull(input: unknown): number | null {
  const num = parseOptionalNumber(input);
  if (num !== null && num > 0) return num;
  return null;
}

/**
 * Excel-compatible ROUND(value, digits), half away from zero.
 * digits = -2 rounds to nearest 100; digits = 0 rounds to nearest integer.
 */
export function roundExcel(value: number, digits: number): number {
  if (!Number.isFinite(value)) return 0;
  const factor = Math.pow(10, digits);
  const scaled = value * factor;
  const sign = scaled < 0 ? -1 : 1;
  const rounded = (sign * Math.floor(Math.abs(scaled) + 0.5 + 1e-12)) / factor;
  return Object.is(rounded, -0) ? 0 : rounded;
}

/**
 * Calculate Saipa shipping cost per kg from 17-city weighted average,
 * fluctuation coverage factor, and truck capacity.
 */
export function calculateShippingMetrics(settings: AppSettings): ShippingMetrics {
  let totalTrips = 0;
  let weightedSum = 0;

  for (const row of settings.cityFares) {
    const fare = Number.isFinite(row.fare) && row.fare > 0 ? row.fare : 0;
    const trips = Number.isFinite(row.trips) && row.trips > 0 ? row.trips : 0;
    totalTrips += trips;
    weightedSum += fare * trips;
  }

  const weightedAvgFare = totalTrips > 0 ? weightedSum / totalTrips : 0;
  const fluctuationFactor =
    Number.isFinite(settings.fluctuationPercent) ? settings.fluctuationPercent / 100 : 0;
  const baseFareWithCoverage = weightedAvgFare * (1 + fluctuationFactor);
  const truckCapacityKg =
    Number.isFinite(settings.truckCapacityKg) && settings.truckCapacityKg > 0
      ? settings.truckCapacityKg
      : 2500;
  const costPerKg = truckCapacityKg > 0 ? baseFareWithCoverage / truckCapacityKg : 0;

  return {
    totalTrips,
    weightedSum,
    weightedAvgFare,
    fluctuationFactor,
    baseFareWithCoverage,
    truckCapacityKg,
    costPerKg,
  };
}

/**
 * Exact implementation of Excel formulas O, R, S, T, U, V, W, X, AD, AE
 * for a single Cash or Check row.
 */
export function computeTermPricing(
  term: SaleTerm,
  basisPrice: number | null,
  manual: TermManualInput,
  costPerKg: number
): ComputedTermPricing {
  const vatRate = manual.vatRate ?? 0;
  const inboundShipping = manual.inboundShipping ?? 0;
  const weight = manual.weight;
  // Treat <= 0 ex-warehouse sale price as unpriced for output calculations
  const validSalePrice =
    manual.exWarehousePrice !== null && manual.exWarehousePrice > 0
      ? manual.exWarehousePrice
      : null;

  // O: هزینه تمام‌شده = H * (1 + I/100) + J
  const landedCost =
    basisPrice !== null ? basisPrice * (1 + vatRate / 100) + inboundShipping : null;

  // S: هزینه حمل به مشتری = ROUND(E * AB25, -2)
  const customerShipping =
    weight !== null && weight >= 0 ? roundExcel(weight * costPerKg, -2) : null;

  // T: قیمت فروش تحویلی مشتری = Q + IF(S="", 0, S)
  // Note: O already includes purchase VAT (H * (1 + I/100) + J), so Q and T are the actual VAT-inclusive wholesale prices
  const deliveredExVat =
    validSalePrice !== null ? validSalePrice + (customerShipping ?? 0) : null;

  // U: قیمت پس از کسر حمل = T - IF(S="", 0, S)
  const afterShippingCheck =
    deliveredExVat !== null ? deliveredExVat - (customerShipping ?? 0) : null;

  // V: سود نهایی = Q - O
  const netProfit =
    validSalePrice !== null && landedCost !== null ? validSalePrice - landedCost : null;

  // R: حاشیه سود فروش = (Q - O) / Q (prevent division by zero)
  const grossMargin =
    validSalePrice !== null && validSalePrice !== 0 && landedCost !== null
      ? (validSalePrice - landedCost) / validSalePrice
      : null;

  // W: درصد سود واقعی = V / O (prevent division by zero)
  const profitPercent =
    netProfit !== null && landedCost !== null && landedCost !== 0
      ? netProfit / landedCost
      : null;

  // X: مبلغ ارزش افزوده (ستون کمکی X اکسل) = ROUND(Q * I/100, 0)
  const vatAmount =
    validSalePrice !== null ? roundExcel(validSalePrice * (vatRate / 100), 0) : null;

  // AD: ستون کمکی AD اکسل = Q + X
  const finalExWarehouse =
    validSalePrice !== null ? validSalePrice + (vatAmount ?? 0) : null;

  // AE: ستون کمکی AE اکسل = ROUND(T * (1 + I/100), -2)
  const finalDelivered =
    deliveredExVat !== null ? roundExcel(deliveredExVat * (1 + vatRate / 100), -2) : null;

  return {
    term,
    manual,
    landedCost,
    grossMargin,
    customerShipping,
    deliveredExVat,
    salesExWarehouse: validSalePrice,
    salesDelivered: deliveredExVat,
    afterShippingCheck,
    netProfit,
    profitPercent,
    vatAmount,
    finalExWarehouse,
    finalDelivered,
  };
}

export function createEmptyManualData(code: string, defaultVatRate = 0): ProductManualData {
  return {
    code,
    cash: {
      weight: null,
      vatRate: defaultVatRate,
      inboundShipping: 0,
      exWarehousePrice: null,
    },
    check: {
      weight: null,
      vatRate: defaultVatRate,
      inboundShipping: 0,
      exWarehousePrice: null,
    },
    checkDays: null,
    consumptionPrice: null,
    consumerPrice: null,
    notes: '',
    lastTaxFlag: 0,
  };
}

/**
 * Sort products by configured sales group order; groups not in groupOrder appear
 * afterward in order of first appearance, matching VBS logic.
 */
export function sortProductsByGroupOrder<T extends { salesGroup: string; orderIndex: number }>(
  items: T[],
  groupOrder: string[]
): T[] {
  const normalizedOrder = groupOrder.map((g) => normFa(g));
  const groupRank = new Map<string, number>();
  normalizedOrder.forEach((g, idx) => {
    if (!groupRank.has(g)) groupRank.set(g, idx);
  });

  // Assign ranks to unseen groups in order of appearance
  let nextRank = normalizedOrder.length;
  const byOriginal = [...items].sort((a, b) => a.orderIndex - b.orderIndex);
  for (const item of byOriginal) {
    const g = normFa(item.salesGroup) || 'سایر';
    if (!groupRank.has(g)) {
      groupRank.set(g, nextRank++);
    }
  }

  return byOriginal.sort((a, b) => {
    const ga = normFa(a.salesGroup) || 'سایر';
    const gb = normFa(b.salesGroup) || 'سایر';
    const ra = groupRank.get(ga) ?? 99999;
    const rb = groupRank.get(gb) ?? 99999;
    if (ra !== rb) return ra - rb;
    return a.orderIndex - b.orderIndex;
  });
}

/**
 * Evaluate OR display rule for Sales or Visitors list.
 * Rule: availableStock > minAvailable || warehouseStock > minWarehouse
 */
export function passesStockThreshold(
  availableStock: number,
  warehouseStock: number,
  minAvailable: number,
  minWarehouse: number
): boolean {
  const minA = Math.max(0, minAvailable);
  const minW = Math.max(0, minWarehouse);
  return availableStock > minA || warehouseStock > minW;
}

/**
 * Compute full pricing view for all active products, sorted by group order.
 */
export function computeAllProducts(
  products: ProductReportData[],
  manualMap: Record<string, ProductManualData>,
  settings: AppSettings
): ComputedProduct[] {
  const shipping = calculateShippingMetrics(settings);
  const sorted = sortProductsByGroupOrder(products, settings.groupOrder);

  return sorted.map((report) => {
    const manual =
      manualMap[report.code] ?? createEmptyManualData(report.code, settings.defaultVatRate);
    const cash = computeTermPricing('نقدی', report.basisPrice, manual.cash, shipping.costPerKg);
    const check = computeTermPricing('چکی', report.basisPrice, manual.check, shipping.costPerKg);

    const isSalesVisible = passesStockThreshold(
      report.availableStock,
      report.warehouseStock,
      settings.salesMinAvailable,
      settings.salesMinWarehouse
    );
    // Visitors list always contains the exact same products as the Sales list
    const isVisitorsVisible = isSalesVisible;

    return {
      report,
      manual,
      cash,
      check,
      isSalesVisible,
      isVisitorsVisible,
    };
  });
}

/**
 * Merge newly uploaded Sellable & Warehouse reports into the active catalog
 * while 100% preserving manualData in IndexedDB (even for items that disappear
 * from today's reports, and restoring them automatically if they return later).
 *
 * Exact VBS compatibility:
 * - Matching strictly by normalized string code.
 * - Duplicate codes keep last seen row (duplicates already warned in preview).
 * - Rial -> Toman by dividing by 10.
 * - Basis price priority: lastPurchasePrice (sellable) > avgCost (warehouse) > null.
 * - Keeps previous relative order of existing items, appends new items, then sorts by groupOrder.
 */
export function mergeDailyReports(
  existingProducts: ProductReportData[],
  existingManualMap: Record<string, ProductManualData>,
  sellableRows: SellableReportRow[],
  warehouseRows: WarehouseReportRow[],
  settings: AppSettings
): {
  nextProducts: ProductReportData[];
  nextManualMap: Record<string, ProductManualData>;
  summary: MergeSummary;
} {
  // Build dictionaries (VBS compatibility: last row wins for duplicate codes)
  const salDict = new Map<string, SellableReportRow>();
  for (const row of sellableRows) {
    if (row.code) {
      salDict.set(row.code, row);
    }
  }

  const whDict = new Map<string, WarehouseReportRow>();
  for (const row of warehouseRows) {
    if (row.code) {
      whDict.set(row.code, row);
    }
  }

  const existingByCode = new Map<string, ProductReportData>();
  for (const p of existingProducts) {
    existingByCode.set(p.code, p);
  }

  // Order keys: existing active items still present in either report, then new from sellable, then new from warehouse
  const orderedCodes: string[] = [];
  const seen = new Set<string>();

  for (const p of existingProducts) {
    if (!seen.has(p.code) && (salDict.has(p.code) || whDict.has(p.code))) {
      orderedCodes.push(p.code);
      seen.add(p.code);
    }
  }

  for (const code of salDict.keys()) {
    if (!seen.has(code)) {
      orderedCodes.push(code);
      seen.add(code);
    }
  }

  for (const code of whDict.keys()) {
    if (!seen.has(code)) {
      orderedCodes.push(code);
      seen.add(code);
    }
  }

  // Identify removed items from active list (their manualData is NEVER deleted!)
  const removedFromActive: Array<{ code: string; name: string }> = [];
  for (const p of existingProducts) {
    if (!seen.has(p.code)) {
      removedFromActive.push({ code: p.code, name: p.name });
    }
  }

  const nextManualMap: Record<string, ProductManualData> = { ...existingManualMap };
  const nextProducts: ProductReportData[] = [];
  const newProducts: Array<{ code: string; name: string }> = [];

  let updatedCount = 0;
  let preservedManualCount = 0;
  let restoredManualCount = 0;
  let basisChangedCount = 0;

  orderedCodes.forEach((code, idx) => {
    const sd = salDict.get(code);
    const wd = whDict.get(code);
    const prevProduct = existingByCode.get(code);
    const prevManual = existingManualMap[code];

    let name = normFa(sd?.name || '');
    if (!name && wd) name = normFa(wd.name);

    let buyGroup = normFa(sd?.buyGroup || '');
    if (!buyGroup && wd) buyGroup = normFa(wd.buyGroup);

    let salesGroup = normFa(sd?.salesGroup || '');
    if (!salesGroup && wd) salesGroup = normFa(wd.salesGroup);
    if (!salesGroup) salesGroup = 'سایر';

    const availableStock = sd ? sd.availableStock : 0;
    const warehouseStock = wd ? wd.warehouseStock : 0;

    // Rial -> Toman (/ 10)
    const lastPurchasePrice =
      sd && sd.lastPurchasePriceRial !== null && sd.lastPurchasePriceRial > 0
        ? sd.lastPurchasePriceRial / 10
        : null;
    const avgCost =
      wd && wd.avgCostRial !== null && wd.avgCostRial > 0 ? wd.avgCostRial / 10 : null;

    let basisPrice: number | null = null;
    let basisSource: BasisPriceSource = 'قیمت ناموجود';
    if (lastPurchasePrice !== null) {
      basisPrice = lastPurchasePrice;
      basisSource = 'موجودی قابل فروش';
    } else if (avgCost !== null) {
      basisPrice = avgCost;
      basisSource = 'موجودی انبار';
    }

    // Tax flag (AF)
    let taxFlag = 0;
    if (sd) {
      taxFlag = sd.taxRaw !== null && sd.taxRaw > 0 ? 1 : 0;
    } else if (wd && wd.taxRaw !== null) {
      taxFlag = wd.taxRaw > 0 ? 1 : 0;
    } else if (prevManual) {
      taxFlag = prevManual.lastTaxFlag;
    }

    const stockStatus = availableStock > 0 ? '' : 'فاقد موجودی قابل فروش';

    nextProducts.push({
      code,
      name,
      buyGroup,
      salesGroup,
      avgCost,
      lastPurchasePrice,
      basisPrice,
      basisSource,
      availableStock,
      warehouseStock,
      stockStatus,
      taxFlag,
      orderIndex: idx,
    });

    // Track stats and preserve/restore manual data
    if (prevProduct) {
      updatedCount++;
      if (prevProduct.basisPrice !== basisPrice) {
        basisChangedCount++;
      }
      if (prevManual) {
        preservedManualCount++;
        nextManualMap[code] = { ...prevManual, lastTaxFlag: taxFlag };
      } else {
        nextManualMap[code] = {
          ...createEmptyManualData(code, settings.defaultVatRate),
          lastTaxFlag: taxFlag,
        };
      }
    } else {
      newProducts.push({ code, name });
      if (prevManual) {
        // Product was previously inactive and returned -> restore saved manual data!
        restoredManualCount++;
        nextManualMap[code] = { ...prevManual, lastTaxFlag: taxFlag };
      } else {
        nextManualMap[code] = {
          ...createEmptyManualData(code, settings.defaultVatRate),
          lastTaxFlag: taxFlag,
        };
      }
    }
  });

  const sortedProducts = sortProductsByGroupOrder(nextProducts, settings.groupOrder).map(
    (item, idx) => ({ ...item, orderIndex: idx })
  );

  return {
    nextProducts: sortedProducts,
    nextManualMap,
    summary: {
      newProducts,
      removedFromActive,
      updatedCount,
      preservedManualCount,
      restoredManualCount,
      totalActiveCount: sortedProducts.length,
      basisChangedCount,
    },
  };
}
