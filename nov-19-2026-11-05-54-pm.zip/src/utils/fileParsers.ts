import * as XLSX from 'xlsx';
import {
  DuplicateCodeEntry,
  ParsedFileReport,
  SellableReportRow,
  WarehouseReportRow,
} from '../types/pricing';
import {
  normFa,
  normalizeCode,
  parseOptionalNumber,
  positiveOrNull,
} from './pricingEngine';

type SheetMatrix = unknown[][];

/**
 * Reads an uploaded Excel (.xlsx, .xls) or delimited text (.txt, .tsv, .csv) file
 * into a 2D array of raw cell values entirely in the browser.
 */
export async function readSpreadsheetMatrix(file: File): Promise<SheetMatrix> {
  const lower = file.name.toLowerCase();
  if (lower.endsWith('.txt') || lower.endsWith('.tsv')) {
    const text = (await file.text()).replace(/^\uFEFF/, '');
    return parseDelimitedText(text);
  }

  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array', raw: true });
  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    throw new Error('فایل بارگذاری‌شده فاقد شیت اطلاعاتی است.');
  }
  const sheet = workbook.Sheets[firstSheetName];
  const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
    header: 1,
    defval: '',
    raw: true,
  });
  return rows;
}

export function parseDelimitedText(text: string): SheetMatrix {
  const lines = text
    .replace(/^\uFEFF/, '')
    .split(/\r?\n/)
    .filter((line) => line.trim().length > 0);
  return lines.map((line) => line.split('\t'));
}

function findColumnIndex(headers: string[], candidates: string[]): number {
  const normalized = headers.map((h) => normFa(h).replace(/\s+/g, ' '));
  // Exact match first
  for (const cand of candidates) {
    const c = normFa(cand);
    const idx = normalized.findIndex((h) => h === c);
    if (idx !== -1) return idx;
  }
  // Partial match fallback
  for (const cand of candidates) {
    const c = normFa(cand);
    const idx = normalized.findIndex((h) => h.includes(c));
    if (idx !== -1) return idx;
  }
  return -1;
}

function findHeaderRowIndex(matrix: SheetMatrix, requiredKeywords: string[]): number {
  const limit = Math.min(matrix.length, 10);
  for (let r = 0; r < limit; r++) {
    const row = matrix[r] ?? [];
    const normalizedCells = row.map((cell) => normFa(cell));
    const matches = requiredKeywords.filter((kw) =>
      normalizedCells.some((cell) => cell.includes(normFa(kw)))
    );
    if (matches.length >= 2) {
      return r;
    }
  }
  return 0;
}

/**
 * Parse and validate "موجودی قابل فروش" report.
 * Main columns: کد، عنوان، گروه خرید، گروه فروش، موجودی قابل فروش، آخرین قیمت خرید، مالیات
 */
export function parseSellableMatrix(
  matrix: SheetMatrix,
  fileName: string
): ParsedFileReport<SellableReportRow> {
  const errors: string[] = [];
  const warnings: string[] = [];
  const validRows: SellableReportRow[] = [];

  if (!matrix || matrix.length < 2) {
    return {
      fileName,
      totalRows: 0,
      validRows: [],
      uniqueCount: 0,
      duplicates: [],
      errors: ['فایل موجودی قابل فروش خالی است یا فقط ردیف سرستون دارد.'],
      warnings: [],
      parsedAt: new Date().toISOString(),
    };
  }

  const headerRowIdx = findHeaderRowIndex(matrix, ['کد', 'عنوان', 'موجودی قابل فروش', 'آخرین قیمت خرید']);
  const headers = (matrix[headerRowIdx] ?? []).map((h) => normFa(h));

  // Verify it wasn't accidentally swapped with Warehouse report
  const hasWarehouseAvgCol = headers.some((h) => h.includes('فی متوسط') || h.includes('موجودی-مقدار'));
  const hasSellableCol = headers.some((h) => h.includes('قابل فروش') || h.includes('آخرین قیمت'));
  if (hasWarehouseAvgCol && !hasSellableCol) {
    errors.push(
      'به نظر می‌رسد فایل «موجودی انبار» به اشتباه در بخش «موجودی قابل فروش» بارگذاری شده است.'
    );
  }

  const colCode = findColumnIndex(headers, ['کد', 'کد کالا']);
  const colName = findColumnIndex(headers, ['عنوان', 'عنوان کالا', 'نام کالا']);
  const colBuyGroup = findColumnIndex(headers, ['گروه خرید']);
  const colSalesGroup = findColumnIndex(headers, ['گروه فروش']);
  const colStock = findColumnIndex(headers, ['موجودی قابل فروش', 'قابل فروش']);
  const colLastPrice = findColumnIndex(headers, ['آخرین قیمت خرید', 'آخرین قیمت']);
  const colTax = findColumnIndex(headers, ['مالیات', 'ارزش افزوده']);

  if (colCode === -1) errors.push('ستون ضروری «کد» در فایل موجودی قابل فروش پیدا نشد.');
  if (colName === -1) errors.push('ستون ضروری «عنوان» در فایل موجودی قابل فروش پیدا نشد.');
  if (colStock === -1) errors.push('ستون ضروری «موجودی قابل فروش» در فایل پیدا نشد.');
  if (colLastPrice === -1) errors.push('ستون ضروری «آخرین قیمت خرید» در فایل پیدا نشد.');
  if (colSalesGroup === -1) warnings.push('ستون «گروه فروش» یافت نشد؛ از گروه فایل انبار یا «سایر» استفاده می‌شود.');
  if (colTax === -1) warnings.push('ستون «مالیات» یافت نشد؛ پرچم مالیات کمکی صفر در نظر گرفته می‌شود.');

  if (errors.length > 0) {
    return {
      fileName,
      totalRows: Math.max(0, matrix.length - headerRowIdx - 1),
      validRows: [],
      uniqueCount: 0,
      duplicates: [],
      errors,
      warnings,
      parsedAt: new Date().toISOString(),
    };
  }

  const occurrenceMap = new Map<string, DuplicateCodeEntry['occurrences']>();
  let skippedEmptyCode = 0;

  for (let r = headerRowIdx + 1; r < matrix.length; r++) {
    const row = matrix[r];
    if (!row || row.every((c) => c === '' || c === null || c === undefined)) continue;

    const code = normalizeCode(row[colCode]);
    if (!code) {
      skippedEmptyCode++;
      continue;
    }

    const name = normFa(row[colName]);
    const buyGroup = colBuyGroup >= 0 ? normFa(row[colBuyGroup]) : '';
    const salesGroup = colSalesGroup >= 0 ? normFa(row[colSalesGroup]) : '';
    const availableStock = parseOptionalNumber(row[colStock]) ?? 0;
    const lastPurchasePriceRial = positiveOrNull(row[colLastPrice]);
    const taxRaw = colTax >= 0 ? parseOptionalNumber(row[colTax]) : null;

    const entry: SellableReportRow = {
      code,
      name,
      buyGroup,
      salesGroup,
      availableStock,
      lastPurchasePriceRial,
      taxRaw,
      rowNumber: r + 1,
    };
    validRows.push(entry);

    const list = occurrenceMap.get(code) ?? [];
    list.push({
      rowNumber: r + 1,
      name,
      stock: availableStock,
      priceRaw: lastPurchasePriceRial,
    });
    occurrenceMap.set(code, list);
  }

  const duplicates: DuplicateCodeEntry[] = [];
  for (const [code, occurrences] of occurrenceMap.entries()) {
    if (occurrences.length > 1) {
      duplicates.push({ code, occurrences });
    }
  }

  if (skippedEmptyCode > 0) {
    warnings.push(`${skippedEmptyCode} ردیف فاقد کد کالا نادیده گرفته شد.`);
  }
  if (duplicates.length > 0) {
    warnings.push(
      `${duplicates.length} کد کالای تکراری در فایل موجودی قابل فروش شناسایی شد. مقادیر تجمیع نمی‌شوند و مطابق سازگاری فایل اصلی، آخرین ردیف هر کد مبنا قرار می‌گیرد.`
    );
  }
  if (validRows.length === 0) {
    errors.push('هیچ ردیف معتبری با کد کالا در فایل موجودی قابل فروش یافت نشد.');
  }

  return {
    fileName,
    totalRows: Math.max(0, matrix.length - headerRowIdx - 1),
    validRows,
    uniqueCount: occurrenceMap.size,
    duplicates,
    errors,
    warnings,
    parsedAt: new Date().toISOString(),
  };
}

/**
 * Parse and validate "موجودی انبار" report.
 * Main columns: کد کالا، عنوان کالا، گروه خرید، گروه فروش، موجودی-مقدار، موجودی-فی متوسط
 */
export function parseWarehouseMatrix(
  matrix: SheetMatrix,
  fileName: string
): ParsedFileReport<WarehouseReportRow> {
  const errors: string[] = [];
  const warnings: string[] = [];
  const validRows: WarehouseReportRow[] = [];

  if (!matrix || matrix.length < 2) {
    return {
      fileName,
      totalRows: 0,
      validRows: [],
      uniqueCount: 0,
      duplicates: [],
      errors: ['فایل موجودی انبار خالی است یا فقط ردیف سرستون دارد.'],
      warnings: [],
      parsedAt: new Date().toISOString(),
    };
  }

  const headerRowIdx = findHeaderRowIndex(matrix, ['کد کالا', 'عنوان کالا', 'موجودی-مقدار', 'فی متوسط']);
  const headers = (matrix[headerRowIdx] ?? []).map((h) => normFa(h));

  // Verify it wasn't accidentally swapped with Sellable report
  const hasSellableCol = headers.some((h) => h.includes('قابل فروش') || h.includes('آخرین قیمت'));
  const hasWarehouseCol = headers.some((h) => h.includes('فی متوسط') || h.includes('موجودی-مقدار'));
  if (hasSellableCol && !hasWarehouseCol) {
    errors.push(
      'به نظر می‌رسد فایل «موجودی قابل فروش» به اشتباه در بخش «موجودی انبار» بارگذاری شده است.'
    );
  }

  const colCode = findColumnIndex(headers, ['کد کالا', 'کد']);
  const colName = findColumnIndex(headers, ['عنوان کالا', 'عنوان', 'نام کالا']);
  const colBuyGroup = findColumnIndex(headers, ['گروه خرید']);
  const colSalesGroup = findColumnIndex(headers, ['گروه فروش']);
  const colStock = findColumnIndex(headers, ['موجودی-مقدار', 'موجودی انبار', 'مقدار']);
  const colAvgCost = findColumnIndex(headers, ['موجودی-فی متوسط', 'فی متوسط']);
  const colTax = findColumnIndex(headers, ['مالیات', 'ارزش افزوده']);

  if (colCode === -1) errors.push('ستون ضروری «کد کالا» در فایل موجودی انبار پیدا نشد.');
  if (colName === -1) errors.push('ستون ضروری «عنوان کالا» در فایل موجودی انبار پیدا نشد.');
  if (colStock === -1) errors.push('ستون ضروری «موجودی-مقدار» در فایل موجودی انبار پیدا نشد.');
  if (colAvgCost === -1) errors.push('ستون ضروری «موجودی-فی متوسط» در فایل موجودی انبار پیدا نشد.');
  if (colSalesGroup === -1) warnings.push('ستون «گروه فروش» در فایل انبار یافت نشد.');

  if (errors.length > 0) {
    return {
      fileName,
      totalRows: Math.max(0, matrix.length - headerRowIdx - 1),
      validRows: [],
      uniqueCount: 0,
      duplicates: [],
      errors,
      warnings,
      parsedAt: new Date().toISOString(),
    };
  }

  const occurrenceMap = new Map<string, DuplicateCodeEntry['occurrences']>();
  let skippedEmptyCode = 0;

  for (let r = headerRowIdx + 1; r < matrix.length; r++) {
    const row = matrix[r];
    if (!row || row.every((c) => c === '' || c === null || c === undefined)) continue;

    const code = normalizeCode(row[colCode]);
    if (!code) {
      skippedEmptyCode++;
      continue;
    }

    const name = normFa(row[colName]);
    const buyGroup = colBuyGroup >= 0 ? normFa(row[colBuyGroup]) : '';
    const salesGroup = colSalesGroup >= 0 ? normFa(row[colSalesGroup]) : '';
    const warehouseStock = parseOptionalNumber(row[colStock]) ?? 0;
    const avgCostRial = positiveOrNull(row[colAvgCost]);
    const taxRaw = colTax >= 0 ? parseOptionalNumber(row[colTax]) : null;

    validRows.push({
      code,
      name,
      buyGroup,
      salesGroup,
      warehouseStock,
      avgCostRial,
      taxRaw,
      rowNumber: r + 1,
    });

    const list = occurrenceMap.get(code) ?? [];
    list.push({
      rowNumber: r + 1,
      name,
      stock: warehouseStock,
      priceRaw: avgCostRial,
    });
    occurrenceMap.set(code, list);
  }

  const duplicates: DuplicateCodeEntry[] = [];
  for (const [code, occurrences] of occurrenceMap.entries()) {
    if (occurrences.length > 1) {
      duplicates.push({ code, occurrences });
    }
  }

  if (skippedEmptyCode > 0) {
    warnings.push(`${skippedEmptyCode} ردیف فاقد کد کالا در فایل انبار نادیده گرفته شد.`);
  }
  if (duplicates.length > 0) {
    warnings.push(
      `${duplicates.length} کد کالای تکراری در فایل موجودی انبار شناسایی شد. مقادیر تجمیع نمی‌شوند و مطابق رفتار فایل اصلی، آخرین ردیف هر کد مبنا قرار می‌گیرد.`
    );
  }
  if (validRows.length === 0) {
    errors.push('هیچ ردیف معتبری با کد کالا در فایل موجودی انبار یافت نشد.');
  }

  return {
    fileName,
    totalRows: Math.max(0, matrix.length - headerRowIdx - 1),
    validRows,
    uniqueCount: occurrenceMap.size,
    duplicates,
    errors,
    warnings,
    parsedAt: new Date().toISOString(),
  };
}
