import { PersistedAppState } from '../types/pricing';

const DB_NAME = 'FoodWholesalePricingDB';
const DB_VERSION = 1;
const STORE_NAME = 'app_state';
const STATE_KEY = 'primary_state';
const FALLBACK_LS_KEY = 'food_wholesale_pricing_state_v1';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'));
  });
}

export async function loadPersistedState(): Promise<PersistedAppState | null> {
  try {
    const db = await openDB();
    return await new Promise<PersistedAppState | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(STATE_KEY);
      req.onsuccess = () => resolve((req.result as PersistedAppState | undefined) ?? null);
      req.onerror = () => reject(req.error);
      tx.oncomplete = () => db.close();
    });
  } catch {
    try {
      const raw = localStorage.getItem(FALLBACK_LS_KEY);
      if (raw) return JSON.parse(raw) as PersistedAppState;
    } catch {
      // Ignore fallback error
    }
    return null;
  }
}

export async function savePersistedState(state: PersistedAppState): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(state, STATE_KEY);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
      tx.oncomplete = () => db.close();
    });
  } catch {
    try {
      localStorage.setItem(FALLBACK_LS_KEY, JSON.stringify(state));
    } catch {
      throw new Error('خطا در ذخیره‌سازی اطلاعات در حافظه مرورگر.');
    }
  }
}

export function validateBackupPayload(data: unknown): {
  valid: boolean;
  error?: string;
  state?: PersistedAppState;
} {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'ساختار فایل پشتیبان نامعتبر است.' };
  }
  const candidate = data as Partial<PersistedAppState>;
  if (!Array.isArray(candidate.products)) {
    return { valid: false, error: 'فهرست کالاها در فایل پشتیبان یافت نشد.' };
  }
  if (!candidate.manualData || typeof candidate.manualData !== 'object') {
    return { valid: false, error: 'اطلاعات دستی کالاها در فایل پشتیبان یافت نشد.' };
  }
  if (!candidate.settings || typeof candidate.settings !== 'object') {
    return { valid: false, error: 'تنظیمات نرم‌افزار در فایل پشتیبان یافت نشد.' };
  }
  if (!Array.isArray(candidate.settings.cityFares) || !Array.isArray(candidate.settings.groupOrder)) {
    return { valid: false, error: 'تنظیمات کرایه حمل یا ترتیب گروه‌ها ناقص است.' };
  }

  return {
    valid: true,
    state: {
      version: candidate.version ?? 1,
      products: candidate.products,
      manualData: candidate.manualData,
      settings: candidate.settings,
      uploadLogs: Array.isArray(candidate.uploadLogs) ? candidate.uploadLogs : [],
      priceChangeLogs: Array.isArray(candidate.priceChangeLogs) ? candidate.priceChangeLogs : [],
      lastUpdatedAt: candidate.lastUpdatedAt ?? null,
      lastUpdatedJalali: candidate.lastUpdatedJalali ?? null,
    },
  };
}
