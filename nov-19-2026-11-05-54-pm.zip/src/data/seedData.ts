import {
  BasisPriceSource,
  PersistedAppState,
  ProductManualData,
  ProductReportData,
} from '../types/pricing';
import { formatJalaliDateTime } from '../utils/jalali';
import {
  DEFAULT_SETTINGS,
  normFa,
  normalizeCode,
  parseOptionalNumber,
  positiveOrNull,
} from '../utils/pricingEngine';
import { INITIAL_PRICING_TSV } from './initialPricingRaw';

/**
 * Parses the user's real initial pricing table (04_اطلاعات_اولیه_قیمت_گذاری.txt)
 * into structured products and preserved manualData.
 */
export function buildInitialAppState(): PersistedAppState {
  const lines = INITIAL_PRICING_TSV.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const products: ProductReportData[] = [];
  const manualData: Record<string, ProductManualData> = {};

  // Skip header row (line 0)
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split('\t');
    const code = normalizeCode(cols[0]);
    if (!code) continue;

    const name = normFa(cols[1]);
    const buyGroup = normFa(cols[2]);
    const salesGroup = normFa(cols[3]) || 'سایر';

    const weightCash = parseOptionalNumber(cols[4]);
    const weightCheck = parseOptionalNumber(cols[5]);
    const vatCash = parseOptionalNumber(cols[6]);
    const vatCheck = parseOptionalNumber(cols[7]);
    const inboundCash = parseOptionalNumber(cols[8]) ?? 0;
    const inboundCheck = parseOptionalNumber(cols[9]) ?? 0;
    const priceCashRaw = parseOptionalNumber(cols[10]);
    const priceCheckRaw = parseOptionalNumber(cols[11]);
    // Keep positive numbers as sale price; treat 0 or "—" as null (unpriced)
    const exCash = priceCashRaw !== null && priceCashRaw > 0 ? priceCashRaw : null;
    const exCheck = priceCheckRaw !== null && priceCheckRaw > 0 ? priceCheckRaw : null;

    const checkDays = positiveOrNull(cols[12]);
    const consumptionPrice = positiveOrNull(cols[13]);
    const consumerPrice = positiveOrNull(cols[14]);
    const notes = normFa(cols[15]);

    const avgCost = positiveOrNull(cols[16]);
    const lastPurchasePrice = positiveOrNull(cols[17]);

    let basisPrice: number | null = null;
    let basisSource: BasisPriceSource = 'قیمت ناموجود';
    if (lastPurchasePrice !== null) {
      basisPrice = lastPurchasePrice;
      basisSource = 'موجودی قابل فروش';
    } else if (avgCost !== null) {
      basisPrice = avgCost;
      basisSource = 'موجودی انبار';
    }

    const availableStock = parseOptionalNumber(cols[19]) ?? 0;
    const warehouseStock = parseOptionalNumber(cols[20]) ?? 0;
    const taxFlag = (parseOptionalNumber(cols[24]) ?? 0) > 0 ? 1 : 0;

    products.push({
      code,
      name,
      buyGroup,
      salesGroup,
      avgCost,
      lastPurchasePrice,
      basisPrice,
      basisSource,
      availableStock,
      warehouseStock,
      stockStatus: availableStock > 0 ? '' : 'فاقد موجودی قابل فروش',
      taxFlag,
      orderIndex: products.length,
    });

    manualData[code] = {
      code,
      cash: {
        weight: weightCash,
        vatRate: vatCash,
        inboundShipping: inboundCash,
        exWarehousePrice: exCash,
      },
      check: {
        weight: weightCheck,
        vatRate: vatCheck,
        inboundShipping: inboundCheck,
        exWarehousePrice: exCheck,
      },
      checkDays,
      consumptionPrice,
      consumerPrice,
      notes,
      lastTaxFlag: taxFlag,
    };
  }

  const now = new Date();
  return {
    version: 1,
    products,
    manualData,
    settings: {
      ...DEFAULT_SETTINGS,
      cityFares: DEFAULT_SETTINGS.cityFares.map((c) => ({ ...c })),
      groupOrder: [...DEFAULT_SETTINGS.groupOrder],
    },
    uploadLogs: [
      {
        id: 'init-seed',
        timestamp: now.toISOString(),
        jalaliDateTime: formatJalaliDateTime(now),
        sellableFileName: 'اطلاعات اولیه فایل قیمت‌گذاری اصلی',
        warehouseFileName: 'اطلاعات اولیه فایل قیمت‌گذاری اصلی',
        newCount: products.length,
        removedCount: 0,
        updatedCount: 0,
        totalActiveCount: products.length,
        preservedManualCount: Object.keys(manualData).length,
        restoredManualCount: 0,
        duplicateWarningsCount: 0,
      },
    ],
    priceChangeLogs: [],
    lastUpdatedAt: now.toISOString(),
    lastUpdatedJalali: formatJalaliDateTime(now),
  };
}
