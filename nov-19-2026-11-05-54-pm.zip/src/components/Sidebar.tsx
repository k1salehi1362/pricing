import React from 'react';
import {
  LayoutDashboard,
  UploadCloud,
  Table2,
  FileSpreadsheet,
  Users,
  Truck,
  History,
  DatabaseBackup,
  X,
} from 'lucide-react';
import { NavSection } from '../types/pricing';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  companyName: string;
  salesCount: number;
  visitorsCount: number;
  missingPriceCount: number;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

interface NavItem {
  id: NavSection;
  label: string;
  icon: React.FC<{ className?: string }>;
  meta?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  companyName,
  salesCount,
  visitorsCount,
  missingPriceCount,
  mobileOpen,
  onCloseMobile,
}) => {
  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'داشبورد مدیریتی', icon: LayoutDashboard },
    { id: 'upload', label: 'بارگذاری گزارش‌های روزانه', icon: UploadCloud },
    {
      id: 'pricing',
      label: 'مدیریت و قیمت‌گذاری کالاها',
      icon: Table2,
      meta: missingPriceCount > 0 ? `${missingPriceCount} ناقص` : undefined,
    },
    {
      id: 'sales-list',
      label: 'لیست قیمت بخش فروش',
      icon: FileSpreadsheet,
      meta: `${salesCount} قلم`,
    },
    {
      id: 'visitors-list',
      label: 'لیست قیمت ویزیتورها',
      icon: Users,
      meta: `${visitorsCount} قلم`,
    },
    { id: 'settings', label: 'تنظیمات و محاسبات حمل', icon: Truck },
    { id: 'history', label: 'تاریخچه تغییرات و گزارش‌ها', icon: History },
    { id: 'backup', label: 'پشتیبان‌گیری و بازیابی', icon: DatabaseBackup },
  ];

  const handleNavClick = (id: NavSection) => {
    onSelectSection(id);
    onCloseMobile();
  };

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside
        className={`no-print fixed inset-y-0 right-0 z-50 flex w-[276px] shrink-0 flex-col border-l border-slate-200 bg-white transition-transform duration-200 lg:static lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        aria-label="منوی اصلی سامانه"
      >
        {/* Brand Header */}
        <div className="flex h-16 items-center justify-between border-b border-slate-200 px-5">
          <div className="min-w-0">
            <div className="truncate text-base font-extrabold tracking-tight text-slate-900">
              سامانه قیمت‌گذاری
            </div>
            <div className="truncate text-xs text-slate-500">{companyName}</div>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="بستن منو"
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-right text-[13px] transition-colors ${
                  active
                    ? 'bg-teal-700 font-semibold text-white'
                    : 'font-medium text-slate-700 hover:bg-slate-100 hover:text-slate-950'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Icon
                    className={`h-4 w-4 shrink-0 ${
                      active ? 'text-teal-100' : 'text-slate-400'
                    }`}
                  />
                  <span className="whitespace-nowrap">{item.label}</span>
                </span>
                {item.meta && (
                  <span
                    className={`text-[11px] tabular-nums shrink-0 ${
                      active ? 'text-teal-100' : 'text-slate-400'
                    }`}
                  >
                    {item.meta}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Quiet Footer */}
        <div className="border-t border-slate-200 px-5 py-3.5 text-xs text-slate-500 leading-relaxed">
          پردازش کاملاً محلی در مرورگر
          <span className="mx-1.5 text-slate-300">·</span>
          ذخیره خودکار
        </div>
      </aside>
    </>
  );
};
