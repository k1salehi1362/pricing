import React, { useMemo, useRef, useState } from 'react';
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Eye,
  Play,
  Trash2,
  FlaskConical,
} from 'lucide-react';
import {
  AppSettings,
  MergeSummary,
  ParsedFileReport,
  ProductManualData,
  ProductReportData,
  SellableReportRow,
  WarehouseReportRow,
} from '../types/pricing';
import {
  parseDelimitedText,
  parseSellableMatrix,
  parseWarehouseMatrix,
  readSpreadsheetMatrix,
} from '../utils/fileParsers';
import { formatStock, formatToman, toPersianDigits } from '../utils/jalali';
import { mergeDailyReports } from '../utils/pricingEngine';

interface DailyUploadViewProps {
  existingProducts: ProductReportData[];
  existingManualMap: Record<string, ProductManualData>;
  settings: AppSettings;
  onApplyImport: (params: {
    nextProducts: ProductReportData[];
    nextManualMap: Record<string, ProductManualData>;
    summary: MergeSummary;
    sellableFileName: string;
    warehouseFileName: string;
    duplicateWarningsCount: number;
  }) => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

export const DailyUploadView: React.FC<DailyUploadViewProps> = ({
  existingProducts,
  existingManualMap,
  settings,
  onApplyImport,
  onNotify,
}) => {
  const [sellableReport, setSellableReport] =
    useState<ParsedFileReport<SellableReportRow> | null>(null);
  const [warehouseReport, setWarehouseReport] =
    useState<ParsedFileReport<WarehouseReportRow> | null>(null);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [previewTab, setPreviewTab] = useState<'sellable' | 'warehouse' | 'diff'>('sellable');
  const [dragTarget, setDragTarget] = useState<'sellable' | 'warehouse' | null>(null);

  const sellableInputRef = useRef<HTMLInputElement | null>(null);
  const warehouseInputRef = useRef<HTMLInputElement | null>(null);

  const handleFile = async (type: 'sellable' | 'warehouse', file: File) => {
    setProcessing(true);
    setProgress(25);
    try {
      const matrix = await readSpreadsheetMatrix(file);
      setProgress(70);
      if (type === 'sellable') {
        const parsed = parseSellableMatrix(matrix, file.name);
        setSellableReport(parsed);
        setPreviewTab('sellable');
        if (parsed.errors.length > 0) {
          onNotify('error', `خطا در بررسی فایل «${file.name}»: ${parsed.errors[0]}`);
        } else {
          onNotify(
            'success',
            `فایل موجودی قابل فروش (${toPersianDigits(parsed.uniqueCount)} کالای یکتا) با موفقیت خوانده شد.`
          );
        }
      } else {
        const parsed = parseWarehouseMatrix(matrix, file.name);
        setWarehouseReport(parsed);
        setPreviewTab('warehouse');
        if (parsed.errors.length > 0) {
          onNotify('error', `خطا در بررسی فایل «${file.name}»: ${parsed.errors[0]}`);
        } else {
          onNotify(
            'success',
            `فایل موجودی انبار (${toPersianDigits(parsed.uniqueCount)} کالای یکتا) با موفقیت خوانده شد.`
          );
        }
      }
      setProgress(100);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'خطا در خواندن فایل اکسل.';
      onNotify('error', msg);
    } finally {
      setTimeout(() => {
        setProcessing(false);
        setProgress(0);
      }, 250);
    }
  };

  const handleLoadAttachedSamples = async () => {
    setProcessing(true);
    setProgress(20);
    try {
      const [resSal, resWh] = await Promise.all([
        fetch('/assets/aistudio/02__________________fd93035c.txt'),
        fetch('/assets/aistudio/03______________7193e4ee.txt'),
      ]);
      if (!resSal.ok || !resWh.ok) {
        throw new Error('فایل‌های نمونه پیوست در دسترس نیستند.');
      }
      setProgress(55);
      const [txtSal, txtWh] = await Promise.all([resSal.text(), resWh.text()]);
      const parsedSal = parseSellableMatrix(parseDelimitedText(txtSal), 'موجودی قابل فروش (نمونه اصلی).xlsx');
      const parsedWh = parseWarehouseMatrix(parseDelimitedText(txtWh), 'موجودی انبار (نمونه اصلی).xlsx');
      setSellableReport(parsedSal);
      setWarehouseReport(parsedWh);
      setPreviewTab('diff');
      setProgress(100);
      onNotify('info', 'هر دو فایل نمونه گزارش روزانه بارگذاری و بررسی شدند. پیش‌نمایش تغییرات آماده تأیید است.');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'خطا در بارگذاری فایل‌های نمونه.');
    } finally {
      setTimeout(() => {
        setProcessing(false);
        setProgress(0);
      }, 250);
    }
  };

  const bothReadyAndValid = Boolean(
    sellableReport &&
      warehouseReport &&
      sellableReport.errors.length === 0 &&
      warehouseReport.errors.length === 0
  );

  const previewMerge = useMemo(() => {
    if (!bothReadyAndValid || !sellableReport || !warehouseReport) return null;
    return mergeDailyReports(
      existingProducts,
      existingManualMap,
      sellableReport.validRows,
      warehouseReport.validRows,
      settings
    );
  }, [bothReadyAndValid, sellableReport, warehouseReport, existingProducts, existingManualMap, settings]);

  const totalDuplicates =
    (sellableReport?.duplicates.length ?? 0) + (warehouseReport?.duplicates.length ?? 0);

  const handleConfirmApply = () => {
    if (!previewMerge || !sellableReport || !warehouseReport) return;
    onApplyImport({
      nextProducts: previewMerge.nextProducts,
      nextManualMap: previewMerge.nextManualMap,
      summary: previewMerge.summary,
      sellableFileName: sellableReport.fileName,
      warehouseFileName: warehouseReport.fileName,
      duplicateWarningsCount: totalDuplicates,
    });
    setSellableReport(null);
    setWarehouseReport(null);
  };

  const renderDropZone = (
    type: 'sellable' | 'warehouse',
    title: string,
    expectedCols: string,
    report: ParsedFileReport<SellableReportRow | WarehouseReportRow> | null,
    inputRef: React.RefObject<HTMLInputElement | null>
  ) => {
    const isDragging = dragTarget === type;
    const hasErrors = report && report.errors.length > 0;
    const isOk = report && report.errors.length === 0;

    return (
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragTarget(type);
        }}
        onDragLeave={() => setDragTarget(null)}
        onDrop={(e) => {
          e.preventDefault();
          setDragTarget(null);
          const f = e.dataTransfer.files?.[0];
          if (f) handleFile(type, f);
        }}
        className={`rounded-xl border-2 border-dashed p-5 transition-colors ${
          isDragging
            ? 'border-teal-600 bg-teal-50/50'
            : hasErrors
            ? 'border-red-300 bg-red-50/30'
            : isOk
            ? 'border-emerald-300 bg-emerald-50/30'
            : 'border-slate-300 bg-white hover:border-slate-400'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".xlsx,.xls,.csv,.txt,.tsv"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(type, f);
            e.target.value = '';
          }}
        />

        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div
              className={`rounded-lg p-2.5 ${
                hasErrors
                  ? 'bg-red-100 text-red-700'
                  : isOk
                  ? 'bg-emerald-100 text-emerald-700'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">{title}</h2>
              <p className="mt-0.5 text-xs text-slate-500">ستون‌های اصلی: {expectedCols}</p>
            </div>
          </div>
          {report && (
            <button
              type="button"
              onClick={() =>
                type === 'sellable' ? setSellableReport(null) : setWarehouseReport(null)
              }
              aria-label={`حذف فایل ${title}`}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-red-600"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>

        {!report ? (
          <div className="mt-5 text-center">
            <p className="text-xs text-slate-500">
              فایل Excel را اینجا بکشید و رها کنید یا از کامپیوتر انتخاب نمایید
            </p>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="mt-3 inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50"
            >
              <UploadCloud className="h-4 w-4 text-teal-700" />
              انتخاب فایل ({type === 'sellable' ? 'موجودی قابل فروش' : 'موجودی انبار'})
            </button>
          </div>
        ) : (
          <div className="mt-4 space-y-2.5 border-t border-slate-200/80 pt-3.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 truncate">{report.fileName}</span>
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="text-teal-700 font-semibold hover:underline shrink-0 mr-2"
              >
                تغییر فایل
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-slate-600 tabular-nums">
              <span>کل ردیف‌ها: {toPersianDigits(report.totalRows)}</span>
              <span>·</span>
              <span>کالاهای یکتا: {toPersianDigits(report.uniqueCount)}</span>
              {report.duplicates.length > 0 && (
                <>
                  <span>·</span>
                  <span className="font-semibold text-amber-700">
                    کد تکراری: {toPersianDigits(report.duplicates.length)}
                  </span>
                </>
              )}
            </div>

            {report.errors.length > 0 && (
              <div className="rounded-lg border border-red-200 bg-red-50 p-2.5 text-red-800 space-y-1">
                {report.errors.map((err, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <XCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                    <span>{err}</span>
                  </div>
                ))}
              </div>
            )}

            {report.warnings.length > 0 && (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-2.5 text-amber-900 space-y-1">
                {report.warnings.map((w, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0 text-amber-700" />
                    <span>{w}</span>
                  </div>
                ))}
              </div>
            )}

            {report.errors.length === 0 && (
              <div className="flex items-center gap-1.5 font-semibold text-emerald-700">
                <CheckCircle2 className="h-4 w-4" />
                ساختار فایل تأیید شد و آماده تطبیق بر اساس کد کالا است.
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">بارگذاری گزارش‌های روزانه</h1>
          <p className="mt-1 text-sm text-slate-500">
            تطبیق صرفاً بر اساس کد کالا (String) انجام می‌شود و کلیه قیمت‌ها و ورودی‌های دستی قبلی حفظ می‌شوند.
          </p>
        </div>
        <button
          type="button"
          onClick={handleLoadAttachedSamples}
          disabled={processing}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <FlaskConical className="h-4 w-4 text-teal-700" />
          آزمایش با فایل‌های نمونه پیوست
        </button>
      </div>

      {/* Progress Bar */}
      {processing && (
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-1.5 flex justify-between text-xs font-medium text-slate-700">
            <span>در حال پردازش و اعتبارسنجی فایل‌ها در مرورگر...</span>
            <span className="tabular-nums">{toPersianDigits(progress)}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full bg-teal-600 transition-all duration-200"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Two File Upload Drop Zones */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {renderDropZone(
          'sellable',
          '۱. فایل موجودی قابل فروش (موجودی قابل فروش.xlsx)',
          'کد، عنوان، گروه خرید، گروه فروش، موجودی قابل فروش، آخرین قیمت خرید، مالیات',
          sellableReport,
          sellableInputRef
        )}
        {renderDropZone(
          'warehouse',
          '۲. فایل موجودی انبار (موجودی انبار.xlsx)',
          'کد کالا، عنوان کالا، گروه خرید، گروه فروش، موجودی-مقدار، موجودی-فی متوسط',
          warehouseReport,
          warehouseInputRef
        )}
      </div>

      {/* Duplicate Codes Alert Table (if any) */}
      {totalDuplicates > 0 && (
        <section className="rounded-xl border border-amber-300 bg-amber-50/40 p-5">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-sm font-bold text-amber-950">
                گزارش کدهای تکراری شناسایی‌شده ({toPersianDigits(totalDuplicates)} مورد)
              </h2>
              <p className="mt-1 text-xs text-amber-900">
                برای جلوگیری از خطای مالی، مقادیر ردیف‌های تکراری به‌صورت خودکار جمع زده نمی‌شوند. مطابق منطق فایل اصلی، آخرین ردیف هر کد مبنا قرار می‌گیرد.
              </p>
            </div>
          </div>

          <div className="mt-3 overflow-x-auto rounded-lg border border-amber-200 bg-white">
            <table className="w-full text-right text-xs">
              <thead className="bg-amber-50 text-amber-950 border-b border-amber-200">
                <tr>
                  <th className="px-3 py-2 font-semibold">فایل منبع</th>
                  <th className="px-3 py-2 font-semibold">کد کالا</th>
                  <th className="px-3 py-2 font-semibold">ردیف‌های تکرار و مقادیر</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sellableReport?.duplicates.map((d) => (
                  <tr key={`s-${d.code}`}>
                    <td className="px-3 py-2 text-slate-600">موجودی قابل فروش</td>
                    <td className="px-3 py-2 font-bold tabular-nums">{d.code}</td>
                    <td className="px-3 py-2 text-slate-700">
                      {d.occurrences
                        .map(
                          (o) =>
                            `ردیف ${toPersianDigits(o.rowNumber)} (${o.name} | موجودی: ${formatStock(o.stock)})`
                        )
                        .join(' — ')}
                    </td>
                  </tr>
                ))}
                {warehouseReport?.duplicates.map((d) => (
                  <tr key={`w-${d.code}`}>
                    <td className="px-3 py-2 text-slate-600">موجودی انبار</td>
                    <td className="px-3 py-2 font-bold tabular-nums">{d.code}</td>
                    <td className="px-3 py-2 text-slate-700">
                      {d.occurrences
                        .map(
                          (o) =>
                            `ردیف ${toPersianDigits(o.rowNumber)} (${o.name} | موجودی: ${formatStock(o.stock)})`
                        )
                        .join(' — ')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Merge Summary & Confirm Action */}
      {previewMerge && (
        <section className="rounded-xl border border-teal-200 bg-white p-5">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                خلاصه پیش‌نمایش به‌روزرسانی روزانه (آماده اعمال)
              </h2>
              <p className="mt-1 text-xs text-slate-500">
                قیمت‌های خرید ریالی به‌صورت خودکار بر ۱۰ تقسیم و به تومان تبدیل می‌شوند. اطلاعات دستی کالاهایی که در گزارش امروز نیستند حذف نمی‌شوند.
              </p>
            </div>
            <button
              type="button"
              onClick={handleConfirmApply}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-teal-700 px-5 py-2.5 text-sm font-bold text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0"
            >
              <Play className="h-4 w-4" />
              تأیید و اعمال در سیستم قیمت‌گذاری
            </button>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-slate-100 pt-4 sm:grid-cols-3 lg:grid-cols-6 text-xs">
            <div>
              <div className="text-slate-500">کل کالاهای فعال جدید</div>
              <div className="mt-1 text-lg font-extrabold text-slate-900 tabular-nums">
                {toPersianDigits(previewMerge.summary.totalActiveCount)}
              </div>
            </div>
            <div>
              <div className="text-slate-500">به‌روزرسانی‌شده</div>
              <div className="mt-1 text-lg font-extrabold text-teal-700 tabular-nums">
                {toPersianDigits(previewMerge.summary.updatedCount)}
              </div>
            </div>
            <div>
              <div className="text-slate-500">کالاهای جدید</div>
              <div className="mt-1 text-lg font-extrabold text-emerald-700 tabular-nums">
                {toPersianDigits(previewMerge.summary.newProducts.length)}
              </div>
            </div>
            <div>
              <div className="text-slate-500">خارج‌شده از لیست فعال</div>
              <div className="mt-1 text-lg font-extrabold text-amber-700 tabular-nums">
                {toPersianDigits(previewMerge.summary.removedFromActive.length)}
              </div>
            </div>
            <div>
              <div className="text-slate-500">اطلاعات دستی حفظ‌شده</div>
              <div className="mt-1 text-lg font-extrabold text-sky-700 tabular-nums">
                {toPersianDigits(
                  previewMerge.summary.preservedManualCount +
                    previewMerge.summary.restoredManualCount
                )}
              </div>
            </div>
            <div>
              <div className="text-slate-500">تغییر قیمت مبنا</div>
              <div className="mt-1 text-lg font-extrabold text-slate-900 tabular-nums">
                {toPersianDigits(previewMerge.summary.basisChangedCount)}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Preview Tables */}
      {(sellableReport || warehouseReport) && (
        <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-5 py-3">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <Eye className="h-4 w-4 text-slate-500" />
              پیش‌نمایش داده‌های خوانده‌شده
            </div>
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 text-xs">
              <button
                type="button"
                onClick={() => setPreviewTab('sellable')}
                className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${
                  previewTab === 'sellable'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                موجودی قابل فروش ({toPersianDigits(sellableReport?.validRows.length ?? 0)})
              </button>
              <button
                type="button"
                onClick={() => setPreviewTab('warehouse')}
                className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${
                  previewTab === 'warehouse'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                موجودی انبار ({toPersianDigits(warehouseReport?.validRows.length ?? 0)})
              </button>
              {previewMerge && (
                <button
                  type="button"
                  onClick={() => setPreviewTab('diff')}
                  className={`rounded-md px-3 py-1.5 font-semibold transition-colors ${
                    previewTab === 'diff'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  تغییرات ترکیب‌شده ({toPersianDigits(previewMerge.nextProducts.length)})
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto max-h-96">
            {previewTab === 'sellable' && sellableReport && (
              <table className="w-full text-right text-xs">
                <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="px-3 py-2.5 font-semibold">کد</th>
                    <th className="px-3 py-2.5 font-semibold">عنوان</th>
                    <th className="px-3 py-2.5 font-semibold">گروه فروش</th>
                    <th className="px-3 py-2.5 font-semibold text-left">موجودی قابل فروش</th>
                    <th className="px-3 py-2.5 font-semibold text-left">آخرین قیمت خرید (تومان)</th>
                    <th className="px-3 py-2.5 font-semibold text-center">مالیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sellableReport.validRows.slice(0, 30).map((r) => (
                    <tr key={`${r.rowNumber}-${r.code}`} className="hover:bg-slate-50">
                      <td className="px-3 py-2 tabular-nums font-semibold text-slate-700">{r.code}</td>
                      <td className="px-3 py-2 text-slate-900">{r.name}</td>
                      <td className="px-3 py-2 text-slate-600">{r.salesGroup || '—'}</td>
                      <td className="px-3 py-2 text-left tabular-nums">{formatStock(r.availableStock)}</td>
                      <td className="px-3 py-2 text-left tabular-nums">
                        {r.lastPurchasePriceRial !== null
                          ? formatToman(r.lastPurchasePriceRial / 10)
                          : '—'}
                      </td>
                      <td className="px-3 py-2 text-center text-slate-500">
                        {r.taxRaw && r.taxRaw > 0 ? 'مشمول' : 'معاف'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {previewTab === 'warehouse' && warehouseReport && (
              <table className="w-full text-right text-xs">
                <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="px-3 py-2.5 font-semibold">کد کالا</th>
                    <th className="px-3 py-2.5 font-semibold">عنوان کالا</th>
                    <th className="px-3 py-2.5 font-semibold">گروه فروش</th>
                    <th className="px-3 py-2.5 font-semibold text-left">موجودی انبار</th>
                    <th className="px-3 py-2.5 font-semibold text-left">فی متوسط (تومان)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {warehouseReport.validRows.slice(0, 30).map((r) => (
                    <tr key={`${r.rowNumber}-${r.code}`} className="hover:bg-slate-50">
                      <td className="px-3 py-2 tabular-nums font-semibold text-slate-700">{r.code}</td>
                      <td className="px-3 py-2 text-slate-900">{r.name}</td>
                      <td className="px-3 py-2 text-slate-600">{r.salesGroup || '—'}</td>
                      <td className="px-3 py-2 text-left tabular-nums">{formatStock(r.warehouseStock)}</td>
                      <td className="px-3 py-2 text-left tabular-nums">
                        {r.avgCostRial !== null ? formatToman(r.avgCostRial / 10) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {previewTab === 'diff' && previewMerge && (
              <table className="w-full text-right text-xs">
                <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="px-3 py-2.5 font-semibold">کد</th>
                    <th className="px-3 py-2.5 font-semibold">نام کالا</th>
                    <th className="px-3 py-2.5 font-semibold">گروه فروش</th>
                    <th className="px-3 py-2.5 font-semibold text-left">قابل فروش</th>
                    <th className="px-3 py-2.5 font-semibold text-left">انبار</th>
                    <th className="px-3 py-2.5 font-semibold text-left">قیمت مبنا (تومان)</th>
                    <th className="px-3 py-2.5 font-semibold">منبع قیمت مبنا</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewMerge.nextProducts.slice(0, 40).map((p) => (
                    <tr key={p.code} className="hover:bg-slate-50">
                      <td className="px-3 py-2 tabular-nums font-semibold text-slate-700">{p.code}</td>
                      <td className="px-3 py-2 text-slate-900">{p.name}</td>
                      <td className="px-3 py-2 text-slate-600">{p.salesGroup}</td>
                      <td className="px-3 py-2 text-left tabular-nums">{formatStock(p.availableStock)}</td>
                      <td className="px-3 py-2 text-left tabular-nums">{formatStock(p.warehouseStock)}</td>
                      <td className="px-3 py-2 text-left tabular-nums font-semibold">
                        {formatToman(p.basisPrice)}
                      </td>
                      <td className="px-3 py-2 text-slate-600">{p.basisSource}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
          <div className="border-t border-slate-100 bg-slate-50 px-5 py-2 text-xs text-slate-500">
            نمایش نمونه ابتدایی ردیف‌ها برای بررسی صحت ستون‌ها و مقادیر (کل ردیف‌ها هنگام تأیید پردازش می‌شوند).
          </div>
        </section>
      )}
    </div>
  );
};
