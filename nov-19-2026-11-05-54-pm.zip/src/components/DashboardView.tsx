import React, { useMemo } from 'react';
import {
  UploadCloud,
  Table2,
  FileSpreadsheet,
  Users,
  ArrowLeft,
} from 'lucide-react';
import {
  AppSettings,
  ComputedProduct,
  NavSection,
  PriceChangeLogEntry,
  ShippingMetrics,
} from '../types/pricing';
import { formatToman, toPersianDigits } from '../utils/jalali';

interface DashboardViewProps {
  products: ComputedProduct[];
  settings: AppSettings;
  shippingMetrics: ShippingMetrics;
  lastUpdatedJalali: string | null;
  priceChangeLogs: PriceChangeLogEntry[];
  onNavigate: (section: NavSection) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  products,
  settings,
  shippingMetrics,
  lastUpdatedJalali,
  priceChangeLogs,
  onNavigate,
}) => {
  const stats = useMemo(() => {
    const total = products.length;
    let hasSellableStock = 0;
    let hasWarehouseStock = 0;
    let onlyWarehouseStock = 0;
    let outOfStock = 0;
    let missingBasis = 0;
    let missingSalePrice = 0;
    let pricedActiveStock = 0;
    let salesVisible = 0;
    let visitorsVisible = 0;

    const groupCounts = new Map<string, { total: number; sales: number; visitors: number }>();

    for (const p of products) {
      const avail = p.report.availableStock > 0;
      const wh = p.report.warehouseStock > 0;
      if (avail) hasSellableStock++;
      if (wh) hasWarehouseStock++;
      if (!avail && wh) onlyWarehouseStock++;
      if (!avail && !wh) outOfStock++;

      if (p.report.basisPrice === null) missingBasis++;

      const hasCashOrCheckPrice =
        (p.manual.cash.exWarehousePrice !== null && p.manual.cash.exWarehousePrice > 0) ||
        (p.manual.check.exWarehousePrice !== null && p.manual.check.exWarehousePrice > 0);
      if (!hasCashOrCheckPrice) {
        missingSalePrice++;
      } else if (avail || wh) {
        pricedActiveStock++;
      }

      if (p.isSalesVisible) salesVisible++;
      if (p.isVisitorsVisible) visitorsVisible++;

      const g = p.report.salesGroup || 'سایر';
      const entry = groupCounts.get(g) ?? { total: 0, sales: 0, visitors: 0 };
      entry.total++;
      if (p.isSalesVisible) entry.sales++;
      if (p.isVisitorsVisible) entry.visitors++;
      groupCounts.set(g, entry);
    }

    const pricedCount = total - missingSalePrice;

    // Sort groups by total descending for bar chart
    const groupsRanked = Array.from(groupCounts.entries())
      .map(([name, c]) => ({ name, ...c }))
      .sort((a, b) => b.total - a.total);

    return {
      total,
      hasSellableStock,
      hasWarehouseStock,
      onlyWarehouseStock,
      outOfStock,
      missingBasis,
      missingSalePrice,
      pricedCount,
      pricedActiveStock,
      salesVisible,
      visitorsVisible,
      changedPricesCount: priceChangeLogs.length,
      groupsRanked,
    };
  }, [products, priceChangeLogs]);

  const maxGroupTotal = Math.max(...stats.groupsRanked.map((g) => g.total), 1);

  return (
    <div className="space-y-6">
      {/* Top Action Strip */}
      <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">داشبورد مدیریتی قیمت‌گذاری</h1>
          <p className="mt-1 text-sm text-slate-500">
            آخرین به‌روزرسانی:{' '}
            <span className="font-medium text-slate-700 tabular-nums">
              {lastUpdatedJalali ? toPersianDigits(lastUpdatedJalali) : 'ثبت نشده'}
            </span>
            <span className="mx-2 text-slate-300">·</span>
            نرخ حمل هر کیلوگرم سایپا:{' '}
            <span className="font-semibold text-teal-700 tabular-nums">
              {formatToman(Math.round(shippingMetrics.costPerKg))} تومان
            </span>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => onNavigate('upload')}
            className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0"
          >
            <UploadCloud className="h-4 w-4" />
            بارگذاری گزارش‌های امروز
          </button>
          <button
            type="button"
            onClick={() => onNavigate('pricing')}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
          >
            <Table2 className="h-4 w-4 text-slate-500" />
            جدول قیمت‌گذاری
          </button>
        </div>
      </div>

      {/* KPI Metrics Grid (Clean Flat Single-Elevation Surface) */}
      <section aria-label="شاخص‌های کلیدی موجودی و قیمت‌گذاری">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="text-xs font-medium text-slate-500">کل کالاهای شناسایی‌شده</div>
            <div className="mt-2 text-2xl font-extrabold text-slate-900 tabular-nums">
              {toPersianDigits(stats.total)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              در {toPersianDigits(stats.groupsRanked.length)} گروه فروش
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="text-xs font-medium text-slate-500">دارای موجودی قابل فروش</div>
            <div className="mt-2 text-2xl font-extrabold text-emerald-700 tabular-nums">
              {toPersianDigits(stats.hasSellableStock)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              دارای موجودی انبار: {toPersianDigits(stats.hasWarehouseStock)}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="text-xs font-medium text-slate-500">قابل نمایش در لیست فروش</div>
            <div className="mt-2 text-2xl font-extrabold text-teal-700 tabular-nums">
              {toPersianDigits(stats.salesVisible)}
            </div>
            <div className="mt-1 text-xs text-slate-500 tabular-nums">
              قابل فروش بیش از {toPersianDigits(settings.salesMinAvailable)} یا انبار بیش از{' '}
              {toPersianDigits(settings.salesMinWarehouse)}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="text-xs font-medium text-slate-500">قابل نمایش برای ویزیتورها</div>
            <div className="mt-2 text-2xl font-extrabold text-sky-700 tabular-nums">
              {toPersianDigits(stats.visitorsVisible)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              یکسان با بخش فروش (بدون ستون‌های درب انبار)
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4 col-span-2 sm:col-span-1">
            <div className="text-xs font-medium text-slate-500">تغییرات دستی ثبت‌شده</div>
            <div className="mt-2 text-2xl font-extrabold text-slate-900 tabular-nums">
              {toPersianDigits(stats.changedPricesCount)}
            </div>
            <div className="mt-1 text-xs text-slate-500">ثبت‌شده در تاریخچه مرورگر</div>
          </div>
        </div>

        {/* Attention Strip: Unpriced & Missing Basis */}
        <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white px-5 py-3.5">
            <div>
              <div className="text-xs font-medium text-slate-500">کالاهای بدون قیمت خرید مبنا</div>
              <div className="mt-0.5 flex items-baseline gap-2">
                <span className="text-xl font-bold text-amber-700 tabular-nums">
                  {toPersianDigits(stats.missingBasis)}
                </span>
                <span className="text-xs text-slate-500">
                  کالا فاقد آخرین قیمت خرید و فی متوسط انبار
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('pricing')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 hover:text-teal-900 whitespace-nowrap shrink-0"
            >
              بررسی کالاها
              <ArrowLeft className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white px-5 py-3.5">
            <div>
              <div className="text-xs font-medium text-slate-500">کالاهای فاقد قیمت فروش</div>
              <div className="mt-0.5 flex items-baseline gap-2">
                <span className="text-xl font-bold text-red-700 tabular-nums">
                  {toPersianDigits(stats.missingSalePrice)}
                </span>
                <span className="text-xs text-slate-500">
                  از {toPersianDigits(stats.total)} کالا (قیمت‌گذاری‌شده: {toPersianDigits(stats.pricedCount)})
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('pricing')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 hover:text-teal-900 whitespace-nowrap shrink-0"
            >
              تکمیل قیمت‌ها
              <ArrowLeft className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Main Analytics Charts Grid (2 columns) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Chart 1: Products by Sales Group */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">تعداد کالاها به تفکیک گروه فروش</h2>
              <p className="text-xs text-slate-500">مقایسه کل اقلام گروه با اقلام قابل عرضه در لیست فروش</p>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-600">
              <span className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-slate-200" />
                کل کالاها
              </span>
              <span className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-teal-600" />
                عرضه در فروش
              </span>
            </div>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pl-1">
            {stats.groupsRanked.map((g) => {
              const totalPct = (g.total / maxGroupTotal) * 100;
              const salesPct = (g.sales / maxGroupTotal) * 100;
              return (
                <div key={g.name} className="grid grid-cols-12 items-center gap-2 text-xs">
                  <div className="col-span-3 truncate font-medium text-slate-700" title={g.name}>
                    {g.name}
                  </div>
                  <div className="col-span-7">
                    <div className="relative h-5 w-full rounded bg-slate-100 overflow-hidden">
                      <div
                        className="absolute inset-y-0 right-0 rounded bg-slate-300 transition-all"
                        style={{ width: `${Math.max(totalPct, 2)}%` }}
                      />
                      {g.sales > 0 && (
                        <div
                          className="absolute inset-y-0 right-0 rounded bg-teal-600 transition-all"
                          style={{ width: `${Math.max(salesPct, 2)}%` }}
                        />
                      )}
                    </div>
                  </div>
                  <div className="col-span-2 text-left tabular-nums text-slate-600">
                    <span className="font-semibold text-teal-700">{toPersianDigits(g.sales)}</span>
                    <span className="text-slate-400"> / {toPersianDigits(g.total)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Right Column: 3 Compact Analytical Panels */}
        <div className="space-y-6 lg:col-span-5">
          {/* Chart 2: Inventory Status Distribution */}
          <section className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-base font-bold text-slate-900">وضعیت موجودی کالاها</h2>
            <p className="mt-0.5 text-xs text-slate-500">تفکیک بر اساس موجودی قابل فروش و موجودی انبار</p>

            <div className="mt-4 h-3.5 w-full overflow-hidden rounded-full bg-slate-100 flex">
              {stats.total > 0 && (
                <>
                  <div
                    className="bg-emerald-600 h-full"
                    style={{ width: `${(stats.hasSellableStock / stats.total) * 100}%` }}
                    title={`دارای موجودی قابل فروش: ${stats.hasSellableStock}`}
                  />
                  <div
                    className="bg-amber-500 h-full"
                    style={{ width: `${(stats.onlyWarehouseStock / stats.total) * 100}%` }}
                    title={`فقط موجودی انبار: ${stats.onlyWarehouseStock}`}
                  />
                  <div
                    className="bg-slate-300 h-full"
                    style={{ width: `${(stats.outOfStock / stats.total) * 100}%` }}
                    title={`ناموجود در هر دو: ${stats.outOfStock}`}
                  />
                </>
              )}
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2 border-t border-slate-100 pt-3.5 text-xs">
              <div>
                <div className="flex items-center gap-1.5 text-slate-500">
                  <span className="h-2.5 w-2.5 rounded-sm bg-emerald-600 shrink-0" />
                  قابل فروش
                </div>
                <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
                  {toPersianDigits(stats.hasSellableStock)}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-slate-500">
                  <span className="h-2.5 w-2.5 rounded-sm bg-amber-500 shrink-0" />
                  فقط انبار
                </div>
                <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
                  {toPersianDigits(stats.onlyWarehouseStock)}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-slate-500">
                  <span className="h-2.5 w-2.5 rounded-sm bg-slate-300 shrink-0" />
                  ناموجود
                </div>
                <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
                  {toPersianDigits(stats.outOfStock)}
                </div>
              </div>
            </div>
          </section>

          {/* Chart 3: Priced vs Unpriced */}
          <section className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-base font-bold text-slate-900">وضعیت قیمت‌گذاری کالاها</h2>
            <div className="mt-3 space-y-3">
              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="font-medium text-slate-700">کالاهای قیمت‌گذاری‌شده</span>
                  <span className="font-semibold text-teal-700 tabular-nums">
                    {toPersianDigits(stats.pricedCount)} قلم (
                    {stats.total > 0 ? Math.round((stats.pricedCount / stats.total) * 100) : 0}%)
                  </span>
                </div>
                <div className="h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-teal-600"
                    style={{
                      width: `${stats.total > 0 ? (stats.pricedCount / stats.total) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="font-medium text-slate-700">فاقد قیمت فروش (نقدی و چکی)</span>
                  <span className="font-semibold text-red-600 tabular-nums">
                    {toPersianDigits(stats.missingSalePrice)} قلم (
                    {stats.total > 0
                      ? Math.round((stats.missingSalePrice / stats.total) * 100)
                      : 0}
                    %)
                  </span>
                </div>
                <div className="h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-red-500"
                    style={{
                      width: `${
                        stats.total > 0 ? (stats.missingSalePrice / stats.total) * 100 : 0
                      }%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </section>

          {/* Chart 4: Sales vs Visitors Supply Comparison */}
          <section className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-base font-bold text-slate-900">مقایسه اقلام خروجی فروش و ویزیتورها</h2>
            <div className="mt-4 space-y-3.5">
              <div>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <button
                    type="button"
                    onClick={() => onNavigate('sales-list')}
                    className="inline-flex items-center gap-1.5 font-semibold text-slate-800 hover:text-teal-700"
                  >
                    <FileSpreadsheet className="h-3.5 w-3.5 text-teal-700" />
                    لیست بخش فروش
                  </button>
                  <span className="font-bold text-teal-700 tabular-nums">
                    {toPersianDigits(stats.salesVisible)} کالا
                  </span>
                </div>
                <div className="h-3 w-full rounded bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded bg-teal-700"
                    style={{
                      width: `${stats.total > 0 ? (stats.salesVisible / stats.total) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <button
                    type="button"
                    onClick={() => onNavigate('visitors-list')}
                    className="inline-flex items-center gap-1.5 font-semibold text-slate-800 hover:text-sky-700"
                  >
                    <Users className="h-3.5 w-3.5 text-sky-700" />
                    لیست ویزیتورها
                  </button>
                  <span className="font-bold text-sky-700 tabular-nums">
                    {toPersianDigits(stats.visitorsVisible)} کالا
                  </span>
                </div>
                <div className="h-3 w-full rounded bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded bg-sky-600"
                    style={{
                      width: `${
                        stats.total > 0 ? (stats.visitorsVisible / stats.total) * 100 : 0
                      }%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
