import React, { useState } from 'react';
import {
  Truck,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  SlidersHorizontal,
  Layers,
} from 'lucide-react';
import { AppSettings, CityFare, ShippingMetrics } from '../types/pricing';
import { formatToman, getTodayJalali, toPersianDigits } from '../utils/jalali';
import { DEFAULT_CITY_FARES, DEFAULT_GROUP_ORDER } from '../utils/pricingEngine';

interface SettingsShippingViewProps {
  settings: AppSettings;
  shippingMetrics: ShippingMetrics;
  onUpdateSettings: (next: AppSettings) => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

export const SettingsShippingView: React.FC<SettingsShippingViewProps> = ({
  settings,
  shippingMetrics,
  onUpdateSettings,
  onNotify,
}) => {
  const [newCityName, setNewCityName] = useState('');
  const [newCityFare, setNewCityFare] = useState('');
  const [newCityTrips, setNewCityTrips] = useState('1');
  const [newGroupName, setNewGroupName] = useState('');

  const updateField = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    onUpdateSettings({ ...settings, [key]: value });
  };

  const updateCityRow = (id: string, patch: Partial<CityFare>) => {
    const nextCities = settings.cityFares.map((c) => (c.id === id ? { ...c, ...patch } : c));
    updateField('cityFares', nextCities);
  };

  const removeCityRow = (id: string) => {
    if (settings.cityFares.length <= 1) {
      onNotify('error', 'حداقل یک شهر باید در جدول کرایه حمل باقی بماند.');
      return;
    }
    updateField(
      'cityFares',
      settings.cityFares.filter((c) => c.id !== id)
    );
  };

  const handleAddCity = (e: React.FormEvent) => {
    e.preventDefault();
    const city = newCityName.trim();
    const fare = Number(newCityFare);
    const trips = Number(newCityTrips);
    if (!city || !Number.isFinite(fare) || fare <= 0 || !Number.isFinite(trips) || trips <= 0) {
      onNotify('error', 'لطفاً نام شهر، مبلغ کرایه و تعداد سرویس معتبر وارد کنید.');
      return;
    }
    const nextCity: CityFare = {
      id: `city-${Date.now()}`,
      city,
      fare,
      trips,
    };
    updateField('cityFares', [...settings.cityFares, nextCity]);
    setNewCityName('');
    setNewCityFare('');
    setNewCityTrips('1');
    onNotify('success', `شهر «${city}» به جدول کرایه حمل اضافه شد.`);
  };

  const moveGroup = (index: number, delta: -1 | 1) => {
    const target = index + delta;
    if (target < 0 || target >= settings.groupOrder.length) return;
    const next = [...settings.groupOrder];
    const [item] = next.splice(index, 1);
    next.splice(target, 0, item);
    updateField('groupOrder', next);
  };

  const removeGroup = (index: number) => {
    const next = settings.groupOrder.filter((_, idx) => idx !== index);
    updateField('groupOrder', next);
  };

  const handleAddGroup = (e: React.FormEvent) => {
    e.preventDefault();
    const g = newGroupName.trim();
    if (!g) return;
    if (settings.groupOrder.includes(g)) {
      onNotify('error', 'این گروه فروش قبلاً در فهرست ترتیب وجود دارد.');
      return;
    }
    updateField('groupOrder', [...settings.groupOrder, g]);
    setNewGroupName('');
    onNotify('success', `گروه «${g}» به ترتیب نمایش اضافه شد.`);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-xl font-extrabold text-slate-900">تنظیمات سیستم و محاسبات حمل</h1>
        <p className="mt-1 text-sm text-slate-500">
          تغییر هر پارامتر حمل، حداقل موجودی یا ترتیب گروه‌ها به‌صورت خودکار و فوری در جدول قیمت‌گذاری و خروجی‌ها اعمال می‌شود.
        </p>
      </div>

      {/* Section 1: Shipping Cost Calculation Engine (Saipa 17 Cities) */}
      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
          <div className="flex items-center gap-2.5">
            <Truck className="h-5 w-5 text-teal-700" />
            <div>
              <h2 className="text-base font-bold text-slate-900">
                مدیریت هزینه حمل سایپا ({toPersianDigits(settings.cityFares.length)} شهر مقصد)
              </h2>
              <p className="text-xs text-slate-500">
                محاسبه میانگین موزون کرایه شهرها، ضریب پوشش نوسان و نرخ حمل به ازای هر کیلوگرم
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              onUpdateSettings({
                ...settings,
                fluctuationPercent: 15,
                truckCapacityKg: 2500,
                cityFares: DEFAULT_CITY_FARES.map((c) => ({ ...c })),
              });
              onNotify('info', 'جدول کرایه ۱۷ شهر و پارامترهای حمل به مقادیر اصلی اکسل بازنشانی شد.');
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            بازنشانی ۱۷ شهر پیش‌فرض
          </button>
        </div>

        {/* Live Shipping KPI Summary */}
        <div className="grid grid-cols-2 gap-4 border-b border-slate-200 bg-slate-50/80 px-5 py-4 sm:grid-cols-4">
          <div>
            <div className="text-xs text-slate-500">میانگین موزون کرایه شهرها</div>
            <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
              {formatToman(Math.round(shippingMetrics.weightedAvgFare))} تومان
            </div>
            <div className="text-[11px] text-slate-500 tabular-nums">
              مجموع سرویس‌ها: {toPersianDigits(shippingMetrics.totalTrips)}
            </div>
          </div>

          <div>
            <div className="text-xs text-slate-500">کرایه مبنا با ضریب پوشش</div>
            <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
              {formatToman(Math.round(shippingMetrics.baseFareWithCoverage))} تومان
            </div>
            <div className="text-[11px] text-slate-500 tabular-nums">
              با {toPersianDigits(settings.fluctuationPercent)}٪ پوشش نوسان
            </div>
          </div>

          <div>
            <div className="text-xs text-slate-500">ظرفیت بارگیری سایپا</div>
            <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
              {formatToman(shippingMetrics.truckCapacityKg)} کیلوگرم
            </div>
          </div>

          <div>
            <div className="text-xs font-medium text-teal-800">هزینه حمل هر کیلوگرم (AB25)</div>
            <div
              data-testid="shipping-cost-per-kg"
              className="mt-1 text-lg font-extrabold text-teal-700 tabular-nums"
            >
              {formatToman(shippingMetrics.costPerKg, { decimals: 1 })} تومان
            </div>
            <div className="text-[11px] text-slate-500">گردشده برای ۱ کیلوگرم: {formatToman(Math.round(shippingMetrics.costPerKg / 100) * 100)} تومان</div>
          </div>
        </div>

        {/* Shipping Parameters Inputs */}
        <div className="grid grid-cols-1 gap-4 border-b border-slate-200 px-5 py-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="fluctuation-percent"
              className="block text-xs font-semibold text-slate-700"
            >
              ضریب پوشش نوسان تاریخ‌های مختلف (درصد)
            </label>
            <input
              id="fluctuation-percent"
              type="number"
              min={0}
              max={200}
              step={1}
              value={settings.fluctuationPercent}
              onChange={(e) => {
                const v = Number(e.target.value);
                if (Number.isFinite(v) && v >= 0) updateField('fluctuationPercent', v);
              }}
              className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums focus:border-teal-600 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="truck-capacity"
              className="block text-xs font-semibold text-slate-700"
            >
              ظرفیت بارگیری ماشین سایپا (کیلوگرم)
            </label>
            <input
              id="truck-capacity"
              type="number"
              min={100}
              step={50}
              value={settings.truckCapacityKg}
              onChange={(e) => {
                const v = Number(e.target.value);
                if (Number.isFinite(v) && v > 0) updateField('truckCapacityKg', v);
              }}
              className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums focus:border-teal-600 focus:outline-none"
            />
          </div>
        </div>

        {/* Editable 17 Cities Table */}
        <div className="p-5">
          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="px-3 py-2.5 font-semibold w-12 text-center">#</th>
                  <th className="px-3 py-2.5 font-semibold">نام شهر مقصد</th>
                  <th className="px-3 py-2.5 font-semibold">کرایه سایپا (تومان)</th>
                  <th className="px-3 py-2.5 font-semibold w-32">تعداد سرویس</th>
                  <th className="px-3 py-2.5 font-semibold text-left">مبلغ کل (تومان)</th>
                  <th className="px-3 py-2.5 font-semibold w-16 text-center">حذف</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {settings.cityFares.map((city, idx) => (
                  <tr key={city.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2 text-center text-slate-400 tabular-nums">
                      {toPersianDigits(idx + 1)}
                    </td>
                    <td className="px-3 py-1.5">
                      <input
                        type="text"
                        aria-label={`نام شهر ردیف ${idx + 1}`}
                        value={city.city}
                        onChange={(e) => updateCityRow(city.id, { city: e.target.value })}
                        className="w-full rounded border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-900 focus:border-teal-600 focus:outline-none"
                      />
                    </td>
                    <td className="px-3 py-1.5">
                      <input
                        type="number"
                        min={0}
                        step={100000}
                        aria-label={`کرایه شهر ${city.city}`}
                        value={city.fare}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (Number.isFinite(v) && v >= 0) updateCityRow(city.id, { fare: v });
                        }}
                        className="w-full max-w-[180px] rounded border border-amber-200 bg-amber-50/70 px-2.5 py-1 text-xs font-semibold tabular-nums text-slate-900 focus:border-teal-600 focus:bg-white focus:outline-none"
                      />
                    </td>
                    <td className="px-3 py-1.5">
                      <input
                        type="number"
                        min={0}
                        step={1}
                        aria-label={`تعداد سرویس ${city.city}`}
                        value={city.trips}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (Number.isFinite(v) && v >= 0) updateCityRow(city.id, { trips: v });
                        }}
                        className="w-24 rounded border border-amber-200 bg-amber-50/70 px-2.5 py-1 text-center text-xs font-semibold tabular-nums text-slate-900 focus:border-teal-600 focus:bg-white focus:outline-none"
                      />
                    </td>
                    <td className="px-3 py-2 text-left tabular-nums font-medium text-slate-700">
                      {formatToman(city.fare * city.trips)}
                    </td>
                    <td className="px-3 py-2 text-center">
                      <button
                        type="button"
                        onClick={() => removeCityRow(city.id)}
                        aria-label={`حذف شهر ${city.city}`}
                        className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Add New City Form */}
          <form onSubmit={handleAddCity} className="mt-3 flex flex-wrap items-end gap-2.5">
            <div className="flex-1 min-w-[160px]">
              <label htmlFor="new-city-name" className="block text-[11px] font-medium text-slate-600">
                افزودن شهر جدید
              </label>
              <input
                id="new-city-name"
                type="text"
                value={newCityName}
                onChange={(e) => setNewCityName(e.target.value)}
                placeholder="مثلاً: همدان"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs focus:border-teal-600 focus:outline-none"
              />
            </div>
            <div className="w-40">
              <label htmlFor="new-city-fare" className="block text-[11px] font-medium text-slate-600">
                کرایه (تومان)
              </label>
              <input
                id="new-city-fare"
                type="number"
                value={newCityFare}
                onChange={(e) => setNewCityFare(e.target.value)}
                placeholder="4000000"
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs tabular-nums focus:border-teal-600 focus:outline-none"
              />
            </div>
            <div className="w-24">
              <label htmlFor="new-city-trips" className="block text-[11px] font-medium text-slate-600">
                تعداد سرویس
              </label>
              <input
                id="new-city-trips"
                type="number"
                min={1}
                value={newCityTrips}
                onChange={(e) => setNewCityTrips(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-1.5 text-center text-xs tabular-nums focus:border-teal-600 focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 rounded-lg bg-teal-700 px-4 py-1.5 text-xs font-semibold text-white hover:bg-teal-800 whitespace-nowrap"
            >
              <Plus className="h-4 w-4" />
              افزودن شهر
            </button>
          </form>
        </div>
      </section>

      {/* Section 2: Stock Thresholds & General Settings */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-5 space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <SlidersHorizontal className="h-5 w-5 text-teal-700" />
            <div>
              <h2 className="text-base font-bold text-slate-900">تنظیمات حداقل موجودی و عمومی</h2>
              <p className="text-xs text-slate-500">
                شرط نمایش از نوع منطقی OR (یا) بوده و به‌صورت یکسان برای هر دو لیست فروش و ویزیتورها اعمال می‌شود.
              </p>
            </div>
          </div>

          {/* Unified Sales & Visitors Thresholds */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-bold text-teal-800">
              حداقل موجودی نمایش کالا در لیست بخش فروش و ویزیتورها
            </h3>
            <p className="text-[11px] text-slate-500">
              اقلام نمایش‌داده‌شده در هر دو لیست دقیقاً یکسان هستند؛ در لیست ویزیتورها فقط دو ستون «درب انبار» نمایش داده نمی‌شود.
            </p>
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label htmlFor="sales-min-avail" className="block text-xs text-slate-600">
                  حداقل موجودی قابل فروش
                </label>
                <input
                  id="sales-min-avail"
                  type="number"
                  min={0}
                  value={settings.salesMinAvailable}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value) || 0);
                    onUpdateSettings({
                      ...settings,
                      salesMinAvailable: val,
                      visitorsMinAvailable: val,
                    });
                  }}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums focus:border-teal-600 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="sales-min-wh" className="block text-xs text-slate-600">
                  حداقل موجودی انبار
                </label>
                <input
                  id="sales-min-wh"
                  type="number"
                  min={0}
                  value={settings.salesMinWarehouse}
                  onChange={(e) => {
                    const val = Math.max(0, Number(e.target.value) || 0);
                    onUpdateSettings({
                      ...settings,
                      salesMinWarehouse: val,
                      visitorsMinWarehouse: val,
                    });
                  }}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums focus:border-teal-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* General Options */}
          <div className="space-y-3 border-t border-slate-100 pt-4">
            <div>
              <label htmlFor="company-name" className="block text-xs font-semibold text-slate-700">
                عنوان سازمانی (درج در سرصفحه Excel و PDF)
              </label>
              <input
                id="company-name"
                type="text"
                value={settings.companyName}
                onChange={(e) => updateField('companyName', e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="default-vat" className="block text-xs font-semibold text-slate-700">
                  نرخ ارزش افزوده پیش‌فرض کالاهای جدید (%)
                </label>
                <input
                  id="default-vat"
                  type="number"
                  min={0}
                  max={100}
                  value={settings.defaultVatRate}
                  onChange={(e) =>
                    updateField('defaultVatRate', Math.max(0, Number(e.target.value) || 0))
                  }
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums focus:border-teal-600 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="custom-date" className="block text-xs font-semibold text-slate-700">
                  تاریخ دستی لیست (خالی = امروز شمسی)
                </label>
                <input
                  id="custom-date"
                  type="text"
                  value={settings.customListDate}
                  placeholder={getTodayJalali()}
                  onChange={(e) => updateField('customListDate', e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums focus:border-teal-600 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Sales Group Order */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Layers className="h-5 w-5 text-teal-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">ترتیب نمایش گروه‌های فروش</h2>
                <p className="text-xs text-slate-500">
                  گروه‌های جدیدی که در این فهرست نباشند، پس از این گروه‌ها نمایش داده می‌شوند.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                updateField('groupOrder', [...DEFAULT_GROUP_ORDER]);
                onNotify('info', 'ترتیب ۱۶ گروه فروش به ترتیب استاندارد فایل اصلی بازنشانی شد.');
              }}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              پیش‌فرض
            </button>
          </div>

          <div className="mt-3 flex-1 overflow-y-auto max-h-[340px] divide-y divide-slate-100 rounded-lg border border-slate-200">
            {settings.groupOrder.map((group, idx) => (
              <div
                key={group}
                className="flex items-center justify-between px-3 py-2 text-xs hover:bg-slate-50"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 text-center font-semibold text-slate-400 tabular-nums">
                    {toPersianDigits(idx + 1)}
                  </span>
                  <span className="font-semibold text-slate-800">{group}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => moveGroup(idx, -1)}
                    aria-label={`انتقال گروه ${group} به بالا`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-200 disabled:opacity-30"
                  >
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === settings.groupOrder.length - 1}
                    onClick={() => moveGroup(idx, 1)}
                    aria-label={`انتقال گروه ${group} به پایین`}
                    className="rounded p-1 text-slate-500 hover:bg-slate-200 disabled:opacity-30"
                  >
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => removeGroup(idx)}
                    aria-label={`حذف گروه ${group}`}
                    className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-600"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddGroup} className="mt-3 flex gap-2">
            <input
              type="text"
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              placeholder="نام گروه فروش جدید (مثلاً: سس)..."
              aria-label="افزودن گروه فروش جدید"
              className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs focus:border-teal-600 focus:outline-none"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1 rounded-lg bg-teal-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-teal-800 whitespace-nowrap"
            >
              <Plus className="h-4 w-4" />
              افزودن
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};
