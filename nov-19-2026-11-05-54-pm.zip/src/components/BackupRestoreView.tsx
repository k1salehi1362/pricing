import React, { useRef, useState } from 'react';
import {
  Download,
  Upload,
  FileSpreadsheet,
  RotateCcw,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import { ComputedProduct, PersistedAppState } from '../types/pricing';
import { getTodayJalali, toPersianDigits } from '../utils/jalali';
import { validateBackupPayload } from '../utils/storage';
import { exportComprehensivePricingExcel } from '../utils/excelExport';
import { ConfirmDialog } from './ConfirmDialog';

interface BackupRestoreViewProps {
  appState: PersistedAppState;
  allComputed: ComputedProduct[];
  salesItems: ComputedProduct[];
  visitorItems: ComputedProduct[];
  onRestoreBackup: (nextState: PersistedAppState) => void;
  onResetToInitial: () => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

export const BackupRestoreView: React.FC<BackupRestoreViewProps> = ({
  appState,
  allComputed,
  salesItems,
  visitorItems,
  onRestoreBackup,
  onResetToInitial,
  onNotify,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [pendingRestore, setPendingRestore] = useState<PersistedAppState | null>(null);
  const [pendingRestoreFile, setPendingRestoreFile] = useState('');
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);
  const [exportingMaster, setExportingMaster] = useState(false);

  const manualCount = Object.keys(appState.manualData).length;
  const effectiveDate = appState.settings.customListDate.trim() || getTodayJalali();

  const handleDownloadJsonBackup = () => {
    const json = JSON.stringify(appState, null, 2);
    const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `پشتیبان-قیمت-گذاری-${effectiveDate.replace(/\//g, '-')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    onNotify('success', 'فایل پشتیبان کامل (JSON) شامل تمام قیمت‌های دستی، تنظیمات و سوابق دانلود شد.');
  };

  const handleSelectBackupFile = async (file: File) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const check = validateBackupPayload(parsed);
      if (!check.valid || !check.state) {
        onNotify('error', check.error ?? 'فایل پشتیبان معتبر نیست.');
        return;
      }
      setPendingRestore(check.state);
      setPendingRestoreFile(file.name);
    } catch {
      onNotify('error', 'فایل انتخاب‌شده قالب JSON معتبر ندارد و قابل بازیابی نیست.');
    }
  };

  const handleDownloadMasterExcel = async () => {
    setExportingMaster(true);
    try {
      await exportComprehensivePricingExcel({
        allProducts: allComputed,
        salesItems,
        visitorItems,
        settings: appState.settings,
        jalaliDate: effectiveDate,
        uploadLogs: appState.uploadLogs,
        priceChangeLogs: appState.priceChangeLogs,
      });
      onNotify('success', 'فایل جامع Excel قیمت‌گذاری (شامل ۴ شیت کامل) با موفقیت دانلود شد.');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'خطا در تولید فایل جامع اکسل.');
    } finally {
      setExportingMaster(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-xl font-extrabold text-slate-900">پشتیبان‌گیری، بازیابی و فایل جامع</h1>
        <p className="mt-1 text-sm text-slate-500">
          تمامی اطلاعات شما به‌صورت محلی در حافظه مرورگر (IndexedDB) ذخیره می‌شوند و هرگز به سرور خارجی ارسال نمی‌گردند.
        </p>
      </div>

      {/* Storage Overview Strip */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">کالاهای فعال فعلی</div>
          <div className="mt-1 text-2xl font-extrabold text-slate-900 tabular-nums">
            {toPersianDigits(appState.products.length)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">رکوردهای دستی ذخیره‌شده</div>
          <div className="mt-1 text-2xl font-extrabold text-teal-700 tabular-nums">
            {toPersianDigits(manualCount)}
          </div>
          <div className="mt-0.5 text-[11px] text-slate-500">شامل کالاهای غیرفعال جهت بازیابی آتی</div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">سوابق بارگذاری گزارش</div>
          <div className="mt-1 text-2xl font-extrabold text-slate-900 tabular-nums">
            {toPersianDigits(appState.uploadLogs.length)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">سوابق تغییرات قیمت</div>
          <div className="mt-1 text-2xl font-extrabold text-slate-900 tabular-nums">
            {toPersianDigits(appState.priceChangeLogs.length)}
          </div>
        </div>
      </div>

      {/* Main Actions Grid */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {/* 1. Export JSON Backup */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="h-5 w-5 text-teal-700" />
              <h2 className="text-base font-bold text-slate-900">تهیه نسخه پشتیبان (JSON)</h2>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              خروجی کامل از کلیه قیمت‌های دستی، وزن‌ها، نرخ ارزش افزوده، جدول کرایه ۱۷ شهر، ترتیب گروه‌ها و تاریخچه تغییرات جهت نگهداری یا انتقال به مرورگر و رایانه دیگر.
            </p>
          </div>
          <button
            type="button"
            onClick={handleDownloadJsonBackup}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800"
          >
            <Download className="h-4 w-4" />
            دانلود فایل پشتیبان JSON
          </button>
        </section>

        {/* 2. Restore JSON Backup */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5">
              <Upload className="h-5 w-5 text-sky-700" />
              <h2 className="text-base font-bold text-slate-900">بازیابی نسخه پشتیبان</h2>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              فایل پشتیبان JSON قبلی را انتخاب کنید. پیش از جایگزینی داده‌ها، ساختار فایل بررسی شده و تأیید نهایی از شما گرفته می‌شود.
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleSelectBackupFile(f);
              e.target.value = '';
            }}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 transition-colors hover:bg-slate-50"
          >
            <Upload className="h-4 w-4 text-sky-700" />
            انتخاب و بازیابی فایل JSON
          </button>
        </section>

        {/* 3. Master Comprehensive Excel */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5">
              <FileSpreadsheet className="h-5 w-5 text-emerald-700" />
              <h2 className="text-base font-bold text-slate-900">دانلود فایل جامع قیمت‌گذاری</h2>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              تولید یک فایل Excel کامل و راست‌چین شامل ۴ شیت: «قیمت گذاری» (ردیف‌های نقدی و چکی)، «ارایه به بخش فروش»، «ارایه به ویزیتورها» و «تنظیمات و تاریخچه».
            </p>
          </div>
          <button
            type="button"
            disabled={exportingMaster}
            onClick={handleDownloadMasterExcel}
            className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-emerald-800 disabled:opacity-50"
          >
            <FileSpreadsheet className="h-4 w-4" />
            {exportingMaster ? 'در حال تولید فایل جامع...' : 'دانلود Excel جامع قیمت‌گذاری'}
          </button>
        </section>
      </div>

      {/* Safe Reset Section */}
      <section className="rounded-xl border border-red-200 bg-white p-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h2 className="text-sm font-bold text-slate-900">بازنشانی کامل به اطلاعات اولیه فایل اصلی</h2>
            <p className="mt-0.5 text-xs text-slate-600">
              این عملیات اطلاعات ذخیره شده در مرورگر را پاک کرده و برنامه را به وضعیت اولیه فایل قیمت‌گذاری پیوست برمی‌گرداند. پیش از انجام این کار حتماً پشتیبان JSON تهیه کنید.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setConfirmResetOpen(true)}
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-red-300 bg-red-50 px-4 py-2 text-xs font-bold text-red-700 hover:bg-red-100 whitespace-nowrap shrink-0"
        >
          <RotateCcw className="h-4 w-4" />
          بازنشانی به حالت اولیه
        </button>
      </section>

      {/* Restore Confirmation Dialog */}
      <ConfirmDialog
        open={pendingRestore !== null}
        title="تأیید بازیابی نسخه پشتیبان"
        message={
          pendingRestore
            ? `فایل «${pendingRestoreFile}» معتبر است و شامل ${toPersianDigits(
                pendingRestore.products.length
              )} کالای فعال و ${toPersianDigits(
                Object.keys(pendingRestore.manualData).length
              )} رکورد دستی می‌باشد.\n\nبا تأیید این عملیات، اطلاعات فعلی مرورگر با این نسخه جایگزین می‌شود.`
            : ''
        }
        confirmLabel="تأیید و بازیابی اطلاعات"
        onCancel={() => {
          setPendingRestore(null);
          setPendingRestoreFile('');
        }}
        onConfirm={() => {
          if (pendingRestore) {
            onRestoreBackup(pendingRestore);
          }
          setPendingRestore(null);
          setPendingRestoreFile('');
        }}
      />

      {/* Reset Confirmation Dialog */}
      <ConfirmDialog
        open={confirmResetOpen}
        variant="danger"
        title="تأیید بازنشانی کامل اطلاعات"
        message="آیا مطمئن هستید؟ تمامی تغییرات دستی، تنظیمات ویرایش‌شده و سوابق ذخیره شده در مرورگر حذف شده و داده‌های اولیه فایل اصلی بارگذاری خواهند شد."
        confirmLabel="بله، بازنشانی کامل شود"
        onCancel={() => setConfirmResetOpen(false)}
        onConfirm={() => {
          setConfirmResetOpen(false);
          onResetToInitial();
        }}
      />
    </div>
  );
};
