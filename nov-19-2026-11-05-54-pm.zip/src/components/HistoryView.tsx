import React, { useMemo, useState } from 'react';
import { History, UploadCloud, Edit3, Search } from 'lucide-react';
import { PriceChangeLogEntry, UploadLogEntry } from '../types/pricing';
import { toPersianDigits } from '../utils/jalali';

interface HistoryViewProps {
  uploadLogs: UploadLogEntry[];
  priceChangeLogs: PriceChangeLogEntry[];
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  uploadLogs,
  priceChangeLogs,
}) => {
  const [activeTab, setActiveTab] = useState<'prices' | 'uploads'>('prices');
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('ALL');

  const uniqueDates = useMemo(() => {
    const set = new Set<string>();
    for (const entry of priceChangeLogs) {
      if (entry.jalaliDate) set.add(entry.jalaliDate);
    }
    return Array.from(set);
  }, [priceChangeLogs]);

  const filteredPriceLogs = useMemo(() => {
    const q = search.trim().toLowerCase();
    return priceChangeLogs.filter((entry) => {
      if (dateFilter !== 'ALL' && entry.jalaliDate !== dateFilter) return false;
      if (q) {
        return (
          entry.code.toLowerCase().includes(q) ||
          entry.productName.toLowerCase().includes(q) ||
          entry.fieldLabel.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [priceChangeLogs, search, dateFilter]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">تاریخچه تغییرات و گزارش عملیات</h1>
          <p className="mt-1 text-sm text-slate-500">
            تمامی سوابق بارگذاری فایل‌های روزانه و ویرایش‌های دستی قیمت در حافظه محلی مرورگر (IndexedDB) نگهداری می‌شوند.
          </p>
        </div>

        <div className="inline-flex rounded-lg bg-slate-100 p-1 text-xs self-start">
          <button
            type="button"
            onClick={() => setActiveTab('prices')}
            className={`inline-flex items-center gap-1.5 rounded-md px-3.5 py-2 font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'prices'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Edit3 className="h-3.5 w-3.5" />
            تغییرات دستی قیمت ({toPersianDigits(priceChangeLogs.length)})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('uploads')}
            className={`inline-flex items-center gap-1.5 rounded-md px-3.5 py-2 font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'uploads'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UploadCloud className="h-3.5 w-3.5" />
            سوابق بارگذاری فایل‌ها ({toPersianDigits(uploadLogs.length)})
          </button>
        </div>
      </div>

      {activeTab === 'prices' ? (
        <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="flex flex-wrap items-center gap-3 border-b border-slate-200 p-4">
            <div className="relative flex-1 min-w-[220px] max-w-sm">
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جست‌وجو بر اساس کد یا نام کالا..."
                aria-label="جست‌وجو در تاریخچه تغییرات قیمت"
                className="w-full rounded-lg border border-slate-300 bg-white py-1.5 pr-9 pl-3 text-xs focus:border-teal-600 focus:outline-none"
              />
            </div>

            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              aria-label="فیلتر تاریخ تغییر"
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-800 focus:border-teal-600 focus:outline-none"
            >
              <option value="ALL">همه تاریخ‌ها</option>
              {uniqueDates.map((d) => (
                <option key={d} value={d}>
                  {toPersianDigits(d)}
                </option>
              ))}
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="px-4 py-3 font-semibold">تاریخ و ساعت</th>
                  <th className="px-4 py-3 font-semibold">کد کالا</th>
                  <th className="px-4 py-3 font-semibold">نام کالا</th>
                  <th className="px-4 py-3 font-semibold text-center">نوع فروش</th>
                  <th className="px-4 py-3 font-semibold">فیلد ویرایش‌شده</th>
                  <th className="px-4 py-3 font-semibold text-left">مقدار قبلی</th>
                  <th className="px-4 py-3 font-semibold text-left">مقدار جدید</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPriceLogs.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-sm text-slate-500">
                      <History className="mx-auto mb-2 h-6 w-6 text-slate-300" />
                      هنوز تغییر دستی قیمتی ثبت نشده است. با ویرایش هر خانه زرد در جدول قیمت‌گذاری، سابقه آن اینجا ثبت می‌شود.
                    </td>
                  </tr>
                ) : (
                  filteredPriceLogs.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 tabular-nums text-slate-600 whitespace-nowrap">
                        {toPersianDigits(entry.jalaliDate)}{' '}
                        <span className="text-slate-400">· {toPersianDigits(entry.jalaliTime)}</span>
                      </td>
                      <td className="px-4 py-2.5 tabular-nums font-semibold text-slate-700">
                        {entry.code}
                      </td>
                      <td className="px-4 py-2.5 font-medium text-slate-900">
                        {entry.productName}
                      </td>
                      <td className="px-4 py-2.5 text-center font-semibold">
                        <span
                          className={
                            entry.term === 'نقدی'
                              ? 'text-teal-700'
                              : entry.term === 'چکی'
                              ? 'text-sky-700'
                              : 'text-slate-600'
                          }
                        >
                          {entry.term}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-slate-700">{entry.fieldLabel}</td>
                      <td className="px-4 py-2.5 text-left tabular-nums text-slate-500 line-through">
                        {entry.oldValue}
                      </td>
                      <td className="px-4 py-2.5 text-left tabular-nums font-bold text-teal-800">
                        {entry.newValue}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      ) : (
        <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="px-4 py-3 font-semibold">تاریخ و ساعت بارگذاری</th>
                  <th className="px-4 py-3 font-semibold">فایل موجودی قابل فروش</th>
                  <th className="px-4 py-3 font-semibold">فایل موجودی انبار</th>
                  <th className="px-4 py-3 font-semibold text-center">کل فعال</th>
                  <th className="px-4 py-3 font-semibold text-center">جدید</th>
                  <th className="px-4 py-3 font-semibold text-center">به‌روزشده</th>
                  <th className="px-4 py-3 font-semibold text-center">حذف از فعال</th>
                  <th className="px-4 py-3 font-semibold text-center">دستی حفظ‌شده</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {uploadLogs.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-sm text-slate-500">
                      سابقه‌ای از بارگذاری فایل ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  uploadLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 tabular-nums font-medium text-slate-800 whitespace-nowrap">
                        {toPersianDigits(log.jalaliDateTime)}
                      </td>
                      <td className="px-4 py-3 text-slate-700">{log.sellableFileName}</td>
                      <td className="px-4 py-3 text-slate-700">{log.warehouseFileName}</td>
                      <td className="px-4 py-3 text-center tabular-nums font-bold text-slate-900">
                        {toPersianDigits(log.totalActiveCount)}
                      </td>
                      <td className="px-4 py-3 text-center tabular-nums font-semibold text-emerald-700">
                        +{toPersianDigits(log.newCount)}
                      </td>
                      <td className="px-4 py-3 text-center tabular-nums text-teal-700">
                        {toPersianDigits(log.updatedCount)}
                      </td>
                      <td className="px-4 py-3 text-center tabular-nums text-amber-700">
                        {toPersianDigits(log.removedCount)}
                      </td>
                      <td className="px-4 py-3 text-center tabular-nums text-sky-700 font-semibold">
                        {toPersianDigits(log.preservedManualCount + log.restoredManualCount)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
