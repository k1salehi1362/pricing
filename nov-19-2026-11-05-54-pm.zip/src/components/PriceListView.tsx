import React, { useMemo, useState } from 'react';
import {
  FileSpreadsheet,
  FileDown,
  Printer,
  Search,
  Eye,
  X,
  SlidersHorizontal,
} from 'lucide-react';
import { AppSettings, ComputedProduct, NavSection } from '../types/pricing';
import { formatStock, formatToman, getTodayJalali, toPersianDigits } from '../utils/jalali';
import { exportPriceListExcel } from '../utils/excelExport';
import { exportPriceListPdf, renderPriceListPdfPages } from '../utils/pdfExport';

interface PriceListViewProps {
  mode: 'sales' | 'visitors';
  items: ComputedProduct[];
  settings: AppSettings;
  onUpdateCustomDate: (date: string) => void;
  onNavigateSettings: (section: NavSection) => void;
  onNotify: (type: 'success' | 'error' | 'info', text: string) => void;
}

export const PriceListView: React.FC<PriceListViewProps> = ({
  mode,
  items,
  settings,
  onUpdateCustomDate,
  onNavigateSettings,
  onNotify,
}) => {
  const [search, setSearch] = useState('');
  const [groupFilter, setGroupFilter] = useState('ALL');
  const [exportingExcel, setExportingExcel] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);
  const [pdfPreviewPages, setPdfPreviewPages] = useState<string[] | null>(null);

  const isSales = mode === 'sales';
  const title = isSales ? 'لیست قیمت بخش فروش' : 'لیست قیمت ویزیتورها';
  const minAvail = settings.salesMinAvailable;
  const minWarehouse = settings.salesMinWarehouse;
  const effectiveDate = settings.customListDate.trim() || getTodayJalali();

  const groups = useMemo(() => {
    const set = new Set<string>();
    for (const item of items) {
      set.add(item.report.salesGroup || 'سایر');
    }
    return Array.from(set);
  }, [items]);

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((item) => {
      if (groupFilter !== 'ALL' && (item.report.salesGroup || 'سایر') !== groupFilter) {
        return false;
      }
      if (q) {
        return (
          item.report.name.toLowerCase().includes(q) ||
          item.report.code.toLowerCase().includes(q) ||
          (item.report.salesGroup || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [items, search, groupFilter]);

  const handleDownloadExcel = async () => {
    setExportingExcel(true);
    try {
      await exportPriceListExcel({
        mode,
        items: filteredItems,
        settings,
        jalaliDate: effectiveDate,
      });
      onNotify('success', `فایل Excel «${title}» با موفقیت دانلود شد.`);
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'خطا در تولید فایل Excel.');
    } finally {
      setExportingExcel(false);
    }
  };

  const handleDownloadPdf = async () => {
    setExportingPdf(true);
    try {
      const pageCount = await exportPriceListPdf({
        mode,
        items: filteredItems,
        settings,
        jalaliDate: effectiveDate,
      });
      onNotify(
        'success',
        `فایل PDF «${title}» (${toPersianDigits(pageCount)} صفحه افقی A4) با موفقیت دانلود شد.`
      );
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'خطا در تولید فایل PDF.');
    } finally {
      setExportingPdf(false);
    }
  };

  const handlePreviewPdf = async () => {
    setExportingPdf(true);
    try {
      const pages = await renderPriceListPdfPages({
        mode,
        items: filteredItems,
        settings,
        jalaliDate: effectiveDate,
      });
      setPdfPreviewPages(pages);
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'خطا در ساخت پیش‌نمایش PDF.');
    } finally {
      setExportingPdf(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Export Toolbar */}
      <div className="flex flex-col gap-3 border-b border-slate-200 pb-4 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">{title}</h1>
          <p className="mt-1 text-xs text-slate-500">
            اقلام نمایش‌داده‌شده:{' '}
            <strong className="text-slate-800 tabular-nums">
              {toPersianDigits(filteredItems.length)}
            </strong>{' '}
            کالا
            <span className="mx-2 text-slate-300">·</span>
            شرط نمایش (OR): قابل فروش بیش از{' '}
            <strong className="tabular-nums text-slate-700">{toPersianDigits(minAvail)}</strong> یا
            انبار بیش از{' '}
            <strong className="tabular-nums text-slate-700">{toPersianDigits(minWarehouse)}</strong>
            <button
              type="button"
              onClick={() => onNavigateSettings('settings')}
              className="mr-2 inline-flex items-center gap-1 font-semibold text-teal-700 hover:underline"
            >
              <SlidersHorizontal className="h-3 w-3" />
              تغییر حد موجودی
            </button>
          </p>
        </div>

        <div className="no-print flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={exportingExcel || filteredItems.length === 0}
            onClick={handleDownloadExcel}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-emerald-800 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="h-4 w-4" />
            {exportingExcel
              ? 'در حال تولید...'
              : isSales
              ? 'دانلود Excel بخش فروش'
              : 'دانلود Excel ویزیتورها'}
          </button>

          <button
            type="button"
            disabled={exportingPdf || filteredItems.length === 0}
            onClick={handleDownloadPdf}
            className="inline-flex items-center gap-1.5 rounded-lg bg-teal-700 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <FileDown className="h-4 w-4" />
            {exportingPdf
              ? 'در حال تولید...'
              : isSales
              ? 'دانلود PDF بخش فروش'
              : 'دانلود PDF ویزیتورها'}
          </button>

          <button
            type="button"
            disabled={exportingPdf || filteredItems.length === 0}
            onClick={handlePreviewPdf}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Eye className="h-4 w-4 text-slate-500" />
            پیش‌نمایش PDF
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
          >
            <Printer className="h-4 w-4 text-slate-500" />
            چاپ
          </button>
        </div>
      </div>

      {/* Filters & List Date Control */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3.5">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[260px]">
          <div className="relative flex-1 max-w-xs">
            <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جست‌وجوی نام محصول یا کد..."
              aria-label="جست‌وجو در لیست قیمت"
              className="w-full rounded-lg border border-slate-300 bg-white py-1.5 pr-9 pl-3 text-xs text-slate-900 focus:border-teal-600 focus:outline-none"
            />
          </div>
          <select
            value={groupFilter}
            onChange={(e) => setGroupFilter(e.target.value)}
            aria-label="فیلتر گروه کالا"
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-800 focus:border-teal-600 focus:outline-none"
          >
            <option value="ALL">همه گروه‌ها ({toPersianDigits(groups.length)})</option>
            {groups.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <label htmlFor={`list-date-${mode}`} className="font-medium text-slate-600 whitespace-nowrap">
            تاریخ درج در خروجی:
          </label>
          <input
            id={`list-date-${mode}`}
            type="text"
            value={settings.customListDate}
            placeholder={getTodayJalali()}
            onChange={(e) => onUpdateCustomDate(e.target.value)}
            className="w-32 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-center text-xs font-semibold text-slate-800 tabular-nums focus:border-teal-600 focus:outline-none"
          />
          {settings.customListDate && (
            <button
              type="button"
              onClick={() => onUpdateCustomDate('')}
              className="text-teal-700 hover:underline whitespace-nowrap"
            >
              تاریخ امروز
            </button>
          )}
        </div>
      </div>

      {/* Official 12-Column Output Table */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="border-b border-slate-200 bg-slate-50 px-5 py-3 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="font-bold text-slate-900">
            {settings.companyName} — {title}
          </div>
          <div className="text-slate-600 tabular-nums">
            تاریخ: <strong>{toPersianDigits(effectiveDate)}</strong>
            <span className="mx-2 text-slate-300">·</span>
            کلیه قیمت‌ها به تومان می‌باشد
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-right text-[11.5px]">
            <thead className="bg-slate-800 text-white">
              <tr>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  گروه کالا
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-right border-l border-slate-700 min-w-[165px]">
                  نام محصول
                </th>
                {isSales && (
                  <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                    <div>فروش نقدی</div>
                    <div className="text-[10px] font-normal text-slate-300">درب انبار</div>
                  </th>
                )}
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  <div>فروش نقدی</div>
                  <div className="text-[10px] font-normal text-slate-300">تحویلی مشتری</div>
                </th>
                {isSales && (
                  <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                    <div>فروش چکی</div>
                    <div className="text-[10px] font-normal text-slate-300">درب انبار</div>
                  </th>
                )}
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  <div>فروش چکی</div>
                  <div className="text-[10px] font-normal text-slate-300">تحویلی مشتری</div>
                </th>
                <th className="px-1.5 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  مدت چک
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  قیمت مصرف
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  مصرف‌کننده
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  قابل فروش
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 whitespace-nowrap">
                  انبار
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-right min-w-[85px]">توضیحات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={isSales ? 12 : 10} className="py-12 text-center text-sm text-slate-500">
                    کالایی با شرایط حداقل موجودی تعیین‌شده برای این لیست وجود ندارد.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item, idx) => {
                  const g = item.report.salesGroup || 'سایر';
                  const prevG =
                    idx > 0 ? filteredItems[idx - 1].report.salesGroup || 'سایر' : '';
                  const isGroupStart = g !== prevG;

                  return (
                    <tr
                      key={item.report.code}
                      className={`${
                        isGroupStart && idx > 0 ? 'border-t-2 border-slate-300' : ''
                      } ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'} hover:bg-teal-50/30`}
                    >
                      <td className="px-2 py-2 text-center border-l border-slate-200 font-semibold text-teal-800 whitespace-nowrap">
                        {isGroupStart ? g : <span className="text-slate-400 font-normal">{g}</span>}
                      </td>
                      <td className="px-2.5 py-2 font-medium text-slate-900 border-l border-slate-200 leading-snug">
                        {item.report.name}
                      </td>
                      {isSales && (
                        <td className="px-2 py-2 text-center tabular-nums font-bold text-slate-900 border-l border-slate-200">
                          {formatToman(item.cash.salesExWarehouse, { dashOnZero: true })}
                        </td>
                      )}
                      <td className="px-2 py-2 text-center tabular-nums font-bold text-teal-900 border-l border-slate-200">
                        {formatToman(item.cash.salesDelivered, { dashOnZero: true })}
                      </td>
                      {isSales && (
                        <td className="px-2 py-2 text-center tabular-nums font-bold text-slate-900 border-l border-slate-200">
                          {formatToman(item.check.salesExWarehouse, { dashOnZero: true })}
                        </td>
                      )}
                      <td className="px-2 py-2 text-center tabular-nums font-bold text-sky-900 border-l border-slate-200">
                        {formatToman(item.check.salesDelivered, { dashOnZero: true })}
                      </td>
                      <td className="px-1.5 py-2 text-center tabular-nums text-slate-700 border-l border-slate-200">
                        {item.manual.checkDays !== null && item.manual.checkDays > 0
                          ? toPersianDigits(item.manual.checkDays)
                          : '—'}
                      </td>
                      <td className="px-2 py-2 text-center tabular-nums text-slate-700 border-l border-slate-200">
                        {formatToman(item.manual.consumptionPrice, { dashOnZero: true })}
                      </td>
                      <td className="px-2 py-2 text-center tabular-nums text-slate-700 border-l border-slate-200">
                        {formatToman(item.manual.consumerPrice, { dashOnZero: true })}
                      </td>
                      <td className="px-2 py-2 text-center tabular-nums font-semibold text-emerald-700 border-l border-slate-200">
                        {formatStock(item.report.availableStock)}
                      </td>
                      <td className="px-2 py-2 text-center tabular-nums text-slate-700 border-l border-slate-200">
                        {formatStock(item.report.warehouseStock)}
                      </td>
                      <td className="px-2.5 py-2 text-slate-600">{item.manual.notes || '—'}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PDF Visual Preview Modal */}
      {pdfPreviewPages && (
        <div
          className="no-print fixed inset-0 z-50 flex flex-col bg-slate-900/75 p-4 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
          aria-label="پیش‌نمایش صفحات PDF فارسی"
        >
          <div className="mx-auto flex w-full max-w-6xl items-center justify-between rounded-t-xl border-b border-slate-200 bg-white px-5 py-3.5">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                پیش‌نمایش خروجی PDF فارسی ({title} — {toPersianDigits(pdfPreviewPages.length)} صفحه A4 افقی)
              </h2>
              <p className="text-xs text-slate-500">
                کیفیت دقیق صفحات آماده چاپ و ارسال در واتساپ
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadPdf}
                className="inline-flex items-center gap-1.5 rounded-lg bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-800"
              >
                <FileDown className="h-4 w-4" />
                دانلود فایل PDF
              </button>
              <button
                type="button"
                onClick={() => setPdfPreviewPages(null)}
                aria-label="بستن پیش‌نمایش PDF"
                className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="mx-auto w-full max-w-6xl flex-1 overflow-y-auto rounded-b-xl bg-slate-200 p-5 space-y-5">
            {pdfPreviewPages.map((src, i) => (
              <div key={i} className="overflow-hidden rounded-lg border border-slate-300 bg-white shadow-md">
                <img
                  src={src}
                  alt={`صفحه ${i + 1} ${title}`}
                  className="w-full h-auto block"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
