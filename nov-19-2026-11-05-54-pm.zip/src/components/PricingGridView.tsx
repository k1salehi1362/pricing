import React, { useMemo, useState } from 'react';
import {
  Search,
  ArrowUpDown,
  Copy,
  RotateCcw,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';
import {
  ComputedProduct,
  ProductManualData,
  SaleTerm,
  ShippingMetrics,
  TermManualInput,
} from '../types/pricing';
import {
  formatPercent,
  formatStock,
  formatToman,
  toLatinDigits,
  toPersianDigits,
} from '../utils/jalali';

interface PricingGridViewProps {
  products: ComputedProduct[];
  shippingMetrics: ShippingMetrics;
  onUpdateTermField: (
    code: string,
    productName: string,
    term: SaleTerm,
    field: keyof TermManualInput,
    value: number | null,
    applyToBoth?: boolean
  ) => void;
  onUpdateSharedField: (
    code: string,
    productName: string,
    field: 'checkDays' | 'consumptionPrice' | 'consumerPrice' | 'notes',
    value: number | string | null
  ) => void;
  onCopyCashToCheck: (code: string, productName: string) => void;
}

type SortKey = 'default' | 'code' | 'name' | 'basis' | 'avail' | 'warehouse' | 'cashPrice' | 'margin';

const NumericManualInput: React.FC<{
  value: number | null;
  ariaLabel: string;
  placeholder?: string;
  step?: string;
  align?: 'center' | 'left';
  onCommit: (val: number | null) => void;
}> = ({ value, ariaLabel, placeholder = '—', align = 'left', onCommit }) => {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');

  const displayVal =
    value !== null && Number.isFinite(value)
      ? Number.isInteger(value)
        ? value.toLocaleString('en-US')
        : String(value)
      : '';

  const handleFocus = () => {
    setEditing(true);
    setDraft(value !== null && Number.isFinite(value) ? String(value) : '');
  };

  const commit = () => {
    setEditing(false);
    const cleaned = toLatinDigits(draft).replace(/,/g, '').replace(/٬/g, '').trim();
    if (!cleaned) {
      if (value !== null) onCommit(null);
      return;
    }
    const parsed = Number(cleaned);
    if (Number.isFinite(parsed) && parsed >= 0) {
      if (parsed !== value) onCommit(parsed);
    }
  };

  return (
    <input
      type="text"
      inputMode="decimal"
      aria-label={ariaLabel}
      value={editing ? draft : displayVal}
      placeholder={placeholder}
      onFocus={handleFocus}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          (e.currentTarget as HTMLInputElement).blur();
        } else if (e.key === 'Escape') {
          setEditing(false);
        }
      }}
      className={`w-full rounded border border-amber-200/90 bg-amber-50/90 px-2 py-1 text-xs font-medium text-slate-900 tabular-nums transition-colors placeholder:text-slate-400 focus:border-teal-600 focus:bg-white focus:outline-none focus:ring-1 focus:ring-teal-600 ${
        align === 'center' ? 'text-center' : 'text-left'
      }`}
    />
  );
};

const TextManualInput: React.FC<{
  value: string;
  ariaLabel: string;
  placeholder?: string;
  onCommit: (val: string) => void;
}> = ({ value, ariaLabel, placeholder = 'توضیحات...', onCommit }) => {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);

  const handleFocus = () => {
    setEditing(true);
    setDraft(value);
  };

  const commit = () => {
    setEditing(false);
    const trimmed = draft.trim();
    if (trimmed !== value) {
      onCommit(trimmed);
    }
  };

  return (
    <input
      type="text"
      aria-label={ariaLabel}
      value={editing ? draft : value}
      placeholder={placeholder}
      onFocus={handleFocus}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.currentTarget as HTMLInputElement).blur();
        if (e.key === 'Escape') setEditing(false);
      }}
      className="w-full rounded border border-amber-200/90 bg-amber-50/90 px-2 py-1 text-xs text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:bg-white focus:outline-none focus:ring-1 focus:ring-teal-600"
    />
  );
};

export const PricingGridView: React.FC<PricingGridViewProps> = ({
  products,
  shippingMetrics,
  onUpdateTermField,
  onUpdateSharedField,
  onCopyCashToCheck,
}) => {
  const [search, setSearch] = useState('');
  const [salesGroupFilter, setSalesGroupFilter] = useState('ALL');
  const [buyGroupFilter, setBuyGroupFilter] = useState('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'SELLABLE' | 'WAREHOUSE' | 'OUT'>('ALL');
  const [pricingFilter, setPricingFilter] = useState<
    'ALL' | 'PRICED' | 'UNPRICED' | 'MISSING_BASIS' | 'NEGATIVE_PROFIT'
  >('ALL');
  const [sortBy, setSortBy] = useState<SortKey>('default');
  const [sortAsc, setSortAsc] = useState(true);
  const [syncSharedTermFields, setSyncSharedTermFields] = useState(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const { salesGroups, buyGroups } = useMemo(() => {
    const sg = new Set<string>();
    const bg = new Set<string>();
    for (const p of products) {
      if (p.report.salesGroup) sg.add(p.report.salesGroup);
      if (p.report.buyGroup) bg.add(p.report.buyGroup);
    }
    return {
      salesGroups: Array.from(sg),
      buyGroups: Array.from(bg),
    };
  }, [products]);

  const filtered = useMemo(() => {
    const q = toLatinDigits(search).trim().toLowerCase();
    const list = products.filter((p) => {
      if (q) {
        const matchCode = p.report.code.toLowerCase().includes(q);
        const matchName = p.report.name.toLowerCase().includes(q);
        if (!matchCode && !matchName) return false;
      }
      if (salesGroupFilter !== 'ALL' && p.report.salesGroup !== salesGroupFilter) return false;
      if (buyGroupFilter !== 'ALL' && p.report.buyGroup !== buyGroupFilter) return false;

      if (stockFilter === 'SELLABLE' && p.report.availableStock <= 0) return false;
      if (stockFilter === 'WAREHOUSE' && p.report.warehouseStock <= 0) return false;
      if (stockFilter === 'OUT' && (p.report.availableStock > 0 || p.report.warehouseStock > 0))
        return false;

      const hasPrice =
        (p.manual.cash.exWarehousePrice !== null && p.manual.cash.exWarehousePrice > 0) ||
        (p.manual.check.exWarehousePrice !== null && p.manual.check.exWarehousePrice > 0);
      if (pricingFilter === 'PRICED' && !hasPrice) return false;
      if (pricingFilter === 'UNPRICED' && hasPrice) return false;
      if (pricingFilter === 'MISSING_BASIS' && p.report.basisPrice !== null) return false;
      if (
        pricingFilter === 'NEGATIVE_PROFIT' &&
        !((p.cash.netProfit !== null && p.cash.netProfit < 0) ||
          (p.check.netProfit !== null && p.check.netProfit < 0))
      ) {
        return false;
      }

      return true;
    });

    if (sortBy === 'default') return list;

    return [...list].sort((a, b) => {
      let cmp = 0;
      switch (sortBy) {
        case 'code':
          cmp = a.report.code.localeCompare(b.report.code, 'en', { numeric: true });
          break;
        case 'name':
          cmp = a.report.name.localeCompare(b.report.name, 'fa');
          break;
        case 'basis':
          cmp = (a.report.basisPrice ?? -1) - (b.report.basisPrice ?? -1);
          break;
        case 'avail':
          cmp = a.report.availableStock - b.report.availableStock;
          break;
        case 'warehouse':
          cmp = a.report.warehouseStock - b.report.warehouseStock;
          break;
        case 'cashPrice':
          cmp = (a.manual.cash.exWarehousePrice ?? -1) - (b.manual.cash.exWarehousePrice ?? -1);
          break;
        case 'margin':
          cmp = (a.cash.grossMargin ?? -999) - (b.cash.grossMargin ?? -999);
          break;
      }
      return sortAsc ? cmp : -cmp;
    });
  }, [
    products,
    search,
    salesGroupFilter,
    buyGroupFilter,
    stockFilter,
    pricingFilter,
    sortBy,
    sortAsc,
  ]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pageItems = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, safePage, pageSize]);

  const toggleSort = (key: SortKey) => {
    if (sortBy === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortBy(key);
      setSortAsc(true);
    }
    setPage(1);
  };

  const resetFilters = () => {
    setSearch('');
    setSalesGroupFilter('ALL');
    setBuyGroupFilter('ALL');
    setStockFilter('ALL');
    setPricingFilter('ALL');
    setSortBy('default');
    setSortAsc(true);
    setPage(1);
  };

  const hasActiveFilter =
    search !== '' ||
    salesGroupFilter !== 'ALL' ||
    buyGroupFilter !== 'ALL' ||
    stockFilter !== 'ALL' ||
    pricingFilter !== 'ALL' ||
    sortBy !== 'default';

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col gap-3 border-b border-slate-200 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900">مدیریت و قیمت‌گذاری کالاها</h1>
          <p className="mt-1 text-xs text-slate-500">
            هر کالا شامل دو ردیف مستقل <span className="font-semibold text-slate-700">نقدی</span> و{' '}
            <span className="font-semibold text-slate-700">چکی</span> است. خانه‌های زردرنگ قابل ویرایش هستند و تغییرات بلافاصله ذخیره و محاسبه می‌شوند.
            <span className="mx-1.5 text-slate-300">·</span>
            کرایه هر کیلوگرم: <span className="font-semibold text-teal-700 tabular-nums">{formatToman(Math.round(shippingMetrics.costPerKg))} تومان</span>
          </p>
        </div>

        <label className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 cursor-pointer shrink-0">
          <input
            type="checkbox"
            checked={syncSharedTermFields}
            onChange={(e) => setSyncSharedTermFields(e.target.checked)}
            className="h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-600"
          />
          اعمال هم‌زمان وزن، ارزش افزوده و حمل انبار برای نقدی و چکی
        </label>
      </div>

      {/* Filter & Search Bar */}
      <div className="rounded-xl border border-slate-200 bg-white p-3.5">
        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-6">
          <div className="relative lg:col-span-2">
            <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="جست‌وجو بر اساس کد کالا یا نام محصول..."
              aria-label="جست‌وجوی کالا"
              className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-9 pl-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:outline-none focus:ring-1 focus:ring-teal-600"
            />
          </div>

          <select
            value={salesGroupFilter}
            onChange={(e) => {
              setSalesGroupFilter(e.target.value);
              setPage(1);
            }}
            aria-label="فیلتر گروه فروش"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-none"
          >
            <option value="ALL">همه گروه‌های فروش</option>
            {salesGroups.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>

          <select
            value={buyGroupFilter}
            onChange={(e) => {
              setBuyGroupFilter(e.target.value);
              setPage(1);
            }}
            aria-label="فیلتر گروه خرید"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-none"
          >
            <option value="ALL">همه گروه‌های خرید</option>
            {buyGroups.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>

          <select
            value={stockFilter}
            onChange={(e) => {
              setStockFilter(e.target.value as typeof stockFilter);
              setPage(1);
            }}
            aria-label="فیلتر وضعیت موجودی"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-none"
          >
            <option value="ALL">همه وضعیت‌های موجودی</option>
            <option value="SELLABLE">دارای موجودی قابل فروش</option>
            <option value="WAREHOUSE">دارای موجودی انبار</option>
            <option value="OUT">فاقد موجودی</option>
          </select>

          <select
            value={pricingFilter}
            onChange={(e) => {
              setPricingFilter(e.target.value as typeof pricingFilter);
              setPage(1);
            }}
            aria-label="فیلتر وضعیت قیمت‌گذاری"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-600 focus:outline-none"
          >
            <option value="ALL">همه وضعیت‌های قیمت</option>
            <option value="PRICED">قیمت‌گذاری‌شده</option>
            <option value="UNPRICED">فاقد قیمت فروش</option>
            <option value="MISSING_BASIS">دارای قیمت مبنای ناموجود</option>
            <option value="NEGATIVE_PROFIT">سود منفی (زیان‌ده)</option>
          </select>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2.5 text-xs text-slate-500">
          <div className="flex flex-wrap items-center gap-3">
            <span>
              نمایش <strong className="text-slate-800 tabular-nums">{toPersianDigits(filtered.length)}</strong> کالا ({toPersianDigits(filtered.length * 2)} ردیف نقدی/چکی) از{' '}
              <span className="tabular-nums">{toPersianDigits(products.length)}</span> کالا
            </span>
            {hasActiveFilter && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1 font-semibold text-teal-700 hover:underline"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                حذف فیلترها
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5">
              <span className="h-3 w-3 rounded border border-amber-300 bg-amber-50 inline-block" />
              ورودی دستی
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="h-3 w-3 rounded border border-slate-200 bg-slate-50 inline-block" />
              محاسباتی (فقط خواندنی)
            </span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              aria-label="تعداد کالا در هر صفحه"
              className="rounded border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700"
            >
              <option value={25}>۲۵ کالا در صفحه</option>
              <option value={50}>۵۰ کالا در صفحه</option>
              <option value={100}>۱۰۰ کالا در صفحه</option>
              <option value={500}>همه کالاها</option>
            </select>
          </div>
        </div>
      </div>

      {/* High-Density Editable Pricing Spreadsheet */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto max-h-[68vh]">
          <table className="w-max min-w-full border-collapse text-right text-xs">
            <thead className="sticky top-0 z-20 bg-slate-800 text-white">
              <tr>
                <th className="sticky right-0 z-30 bg-slate-800 px-2.5 py-2.5 font-semibold border-l border-slate-700 w-20">
                  <button
                    type="button"
                    onClick={() => toggleSort('code')}
                    className="inline-flex items-center gap-1 hover:text-teal-200 whitespace-nowrap"
                  >
                    کد کالا
                    <ArrowUpDown className="h-3 w-3 opacity-70" />
                  </button>
                </th>
                <th className="sticky right-20 z-30 bg-slate-800 px-3 py-2.5 font-semibold border-l border-slate-700 min-w-[230px]">
                  <button
                    type="button"
                    onClick={() => toggleSort('name')}
                    className="inline-flex items-center gap-1 hover:text-teal-200 whitespace-nowrap"
                  >
                    نام کالا و گروه
                    <ArrowUpDown className="h-3 w-3 opacity-70" />
                  </button>
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-center border-l border-slate-700 w-16">
                  شرایط
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-left border-l border-slate-700 w-28">
                  <button
                    type="button"
                    onClick={() => toggleSort('basis')}
                    className="inline-flex items-center gap-1 hover:text-teal-200 whitespace-nowrap"
                  >
                    قیمت مبنا
                    <ArrowUpDown className="h-3 w-3 opacity-70" />
                  </button>
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-20">
                  وزن (kg)
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-20">
                  مالیات %
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-24">
                  حمل انبار
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-left border-l border-slate-700 w-28">
                  هزینه تمام‌شده
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-32">
                  <button
                    type="button"
                    onClick={() => toggleSort('cashPrice')}
                    className="inline-flex items-center gap-1 hover:text-amber-200 whitespace-nowrap"
                  >
                    فروش درب انبار
                    <ArrowUpDown className="h-3 w-3 opacity-70" />
                  </button>
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-left border-l border-slate-700 w-28">
                  سود نهایی
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-center border-l border-slate-700 w-20">
                  <button
                    type="button"
                    onClick={() => toggleSort('margin')}
                    className="inline-flex items-center gap-1 hover:text-teal-200 whitespace-nowrap"
                  >
                    حاشیه
                    <ArrowUpDown className="h-3 w-3 opacity-70" />
                  </button>
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-center border-l border-slate-700 w-20">
                  سود %
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-left border-l border-slate-700 w-24">
                  حمل مشتری
                </th>
                <th
                  className="px-2.5 py-2.5 font-semibold text-left border-l border-slate-700 bg-teal-900/60 w-32"
                  title="قیمت فروش درب انبار + حمل به مشتری (مبلغ درج‌شده در لیست فروش و ویزیتورها)"
                >
                  تحویلی مشتری
                </th>
                <th className="px-2.5 py-2.5 font-semibold text-center border-l border-slate-700 w-24">
                  <button
                    type="button"
                    onClick={() => toggleSort('avail')}
                    className="inline-flex items-center gap-1 hover:text-teal-200 whitespace-nowrap"
                  >
                    موجودی
                    <ArrowUpDown className="h-3 w-3 opacity-70" />
                  </button>
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-20">
                  مدت چک
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-28">
                  قیمت مصرف
                </th>
                <th className="px-2 py-2.5 font-semibold text-center border-l border-slate-700 bg-amber-900/40 w-28">
                  مصرف‌کننده
                </th>
                <th className="px-2 py-2.5 font-semibold text-right bg-amber-900/40 min-w-[150px]">
                  توضیحات
                </th>
              </tr>
            </thead>

            <tbody>
              {pageItems.length === 0 ? (
                <tr>
                  <td colSpan={19} className="py-12 text-center text-sm text-slate-500">
                    کالایی مطابق با فیلترهای انتخابی یافت نشد.
                  </td>
                </tr>
              ) : (
                pageItems.map((item, idx) => {
                  const isEvenProduct = idx % 2 === 0;
                  const productBg = isEvenProduct ? 'bg-white' : 'bg-slate-50/70';

                  return (
                    <React.Fragment key={item.report.code}>
                      {([item.cash, item.check] as const).map((termRow, tIdx) => {
                        const isCash = tIdx === 0;
                        const profitColor =
                          termRow.netProfit === null
                            ? 'text-slate-400'
                            : termRow.netProfit < 0
                            ? 'text-red-600 font-bold'
                            : 'text-emerald-700 font-semibold';

                        return (
                          <tr
                            key={`${item.report.code}-${termRow.term}`}
                            data-testid={`pricing-row-${item.report.code}-${isCash ? 'cash' : 'check'}`}
                            className={`${productBg} ${
                              isCash ? 'border-t-2 border-slate-200' : 'border-t border-slate-100'
                            } hover:bg-teal-50/30`}
                          >
                            {/* Code (rowSpan 2) */}
                            {isCash && (
                              <td
                                rowSpan={2}
                                className={`sticky right-0 z-10 ${productBg} px-2.5 py-2 border-l border-slate-200 align-middle font-bold text-slate-800 tabular-nums`}
                              >
                                <div>{item.report.code}</div>
                                <button
                                  type="button"
                                  title="کپی تنظیمات ردیف نقدی به چکی"
                                  aria-label={`کپی نقدی به چکی برای ${item.report.name}`}
                                  onClick={() =>
                                    onCopyCashToCheck(item.report.code, item.report.name)
                                  }
                                  className="mt-1 inline-flex items-center gap-1 text-[10px] font-medium text-teal-700 hover:underline"
                                >
                                  <Copy className="h-3 w-3" />
                                  کپی چکی
                                </button>
                              </td>
                            )}

                            {/* Name & Group (rowSpan 2) */}
                            {isCash && (
                              <td
                                rowSpan={2}
                                className={`sticky right-20 z-10 ${productBg} px-3 py-2 border-l border-slate-200 align-middle`}
                              >
                                <div className="font-semibold text-slate-900 leading-snug">
                                  {item.report.name}
                                </div>
                                <div className="mt-1 text-[11px] text-slate-500">
                                  <span>{item.report.salesGroup}</span>
                                  {item.report.buyGroup && (
                                    <>
                                      <span className="mx-1.5 text-slate-300">·</span>
                                      <span>خرید: {item.report.buyGroup}</span>
                                    </>
                                  )}
                                  {item.report.basisSource === 'قیمت ناموجود' && (
                                    <>
                                      <span className="mx-1.5 text-slate-300">·</span>
                                      <span className="font-semibold text-amber-700">قیمت ناموجود</span>
                                    </>
                                  )}
                                </div>
                              </td>
                            )}

                            {/* Sale Term */}
                            <td className="px-2 py-1.5 text-center border-l border-slate-200 font-semibold">
                              <span className={isCash ? 'text-teal-800' : 'text-sky-800'}>
                                {termRow.term}
                              </span>
                            </td>

                            {/* Basis Price & Source (rowSpan 2) */}
                            {isCash && (
                              <td
                                rowSpan={2}
                                className="px-2.5 py-2 text-left border-l border-slate-200 align-middle tabular-nums"
                              >
                                <div
                                  className={`font-semibold ${
                                    item.report.basisPrice === null
                                      ? 'text-amber-700'
                                      : 'text-slate-900'
                                  }`}
                                >
                                  {formatToman(item.report.basisPrice)}
                                </div>
                                <div className="mt-0.5 text-[10px] text-slate-500 text-right">
                                  {item.report.basisSource}
                                </div>
                              </td>
                            )}

                            {/* Weight (Manual) */}
                            <td className="px-1.5 py-1 border-l border-slate-200">
                              <NumericManualInput
                                value={termRow.manual.weight}
                                align="center"
                                ariaLabel={`وزن ${termRow.term} ${item.report.name}`}
                                onCommit={(val) =>
                                  onUpdateTermField(
                                    item.report.code,
                                    item.report.name,
                                    termRow.term,
                                    'weight',
                                    val,
                                    syncSharedTermFields
                                  )
                                }
                              />
                            </td>

                            {/* VAT % (Manual) */}
                            <td className="px-1.5 py-1 border-l border-slate-200">
                              <NumericManualInput
                                value={termRow.manual.vatRate}
                                align="center"
                                placeholder="0"
                                ariaLabel={`ارزش افزوده ${termRow.term} ${item.report.name}`}
                                onCommit={(val) =>
                                  onUpdateTermField(
                                    item.report.code,
                                    item.report.name,
                                    termRow.term,
                                    'vatRate',
                                    val ?? 0,
                                    syncSharedTermFields
                                  )
                                }
                              />
                            </td>

                            {/* Inbound Shipping (Manual) */}
                            <td className="px-1.5 py-1 border-l border-slate-200">
                              <NumericManualInput
                                value={termRow.manual.inboundShipping}
                                placeholder="0"
                                ariaLabel={`حمل تا انبار ${termRow.term} ${item.report.name}`}
                                onCommit={(val) =>
                                  onUpdateTermField(
                                    item.report.code,
                                    item.report.name,
                                    termRow.term,
                                    'inboundShipping',
                                    val ?? 0,
                                    syncSharedTermFields
                                  )
                                }
                              />
                            </td>

                            {/* Landed Cost (Calculated O) */}
                            <td className="px-2.5 py-1.5 text-left border-l border-slate-200 tabular-nums text-slate-700 bg-slate-50/40">
                              {formatToman(termRow.landedCost)}
                            </td>

                            {/* Ex-Warehouse Sale Price (Manual Q) */}
                            <td className="px-1.5 py-1 border-l border-slate-200">
                              <NumericManualInput
                                value={termRow.manual.exWarehousePrice}
                                ariaLabel={`قیمت فروش درب انبار ${termRow.term} ${item.report.name}`}
                                onCommit={(val) =>
                                  onUpdateTermField(
                                    item.report.code,
                                    item.report.name,
                                    termRow.term,
                                    'exWarehousePrice',
                                    val,
                                    false
                                  )
                                }
                              />
                            </td>

                            {/* Net Profit (Calculated V) */}
                            <td
                              className={`px-2.5 py-1.5 text-left border-l border-slate-200 tabular-nums bg-slate-50/40 ${profitColor}`}
                            >
                              {formatToman(termRow.netProfit)}
                            </td>

                            {/* Gross Margin (Calculated R) */}
                            <td
                              className={`px-2 py-1.5 text-center border-l border-slate-200 tabular-nums bg-slate-50/40 ${profitColor}`}
                            >
                              {formatPercent(termRow.grossMargin)}
                            </td>

                            {/* Profit % on Cost (Calculated W) */}
                            <td className="px-2 py-1.5 text-center border-l border-slate-200 tabular-nums text-slate-700 bg-slate-50/40">
                              {formatPercent(termRow.profitPercent)}
                            </td>

                            {/* Customer Shipping (Calculated S) */}
                            <td className="px-2.5 py-1.5 text-left border-l border-slate-200 tabular-nums text-slate-700 bg-slate-50/40">
                              {formatToman(termRow.customerShipping)}
                            </td>

                            {/* Delivered Price to Customer (Calculated T = Q + S) */}
                            <td
                              className="px-2.5 py-1.5 text-left border-l border-slate-200 tabular-nums font-bold text-teal-900 bg-teal-50/30"
                              title="قیمت فروش درب انبار + حمل مشتری"
                            >
                              {formatToman(termRow.salesDelivered, { dashOnZero: true })}
                            </td>

                            {/* Stock (rowSpan 2) */}
                            {isCash && (
                              <td
                                rowSpan={2}
                                className="px-2.5 py-2 text-center border-l border-slate-200 align-middle tabular-nums"
                              >
                                <div className="font-semibold text-emerald-700" title="موجودی قابل فروش">
                                  {formatStock(item.report.availableStock)}
                                </div>
                                <div className="mt-0.5 text-[11px] text-slate-500" title="موجودی انبار">
                                  انبار: {formatStock(item.report.warehouseStock)}
                                </div>
                              </td>
                            )}

                            {/* Shared Fields (rowSpan 2): Check Days, Consumption, Consumer, Notes */}
                            {isCash && (
                              <>
                                <td rowSpan={2} className="px-1.5 py-1 border-l border-slate-200 align-middle">
                                  <NumericManualInput
                                    value={item.manual.checkDays}
                                    align="center"
                                    ariaLabel={`مدت چک ${item.report.name}`}
                                    onCommit={(val) =>
                                      onUpdateSharedField(
                                        item.report.code,
                                        item.report.name,
                                        'checkDays',
                                        val
                                      )
                                    }
                                  />
                                </td>
                                <td rowSpan={2} className="px-1.5 py-1 border-l border-slate-200 align-middle">
                                  <NumericManualInput
                                    value={item.manual.consumptionPrice}
                                    ariaLabel={`قیمت مصرف ${item.report.name}`}
                                    onCommit={(val) =>
                                      onUpdateSharedField(
                                        item.report.code,
                                        item.report.name,
                                        'consumptionPrice',
                                        val
                                      )
                                    }
                                  />
                                </td>
                                <td rowSpan={2} className="px-1.5 py-1 border-l border-slate-200 align-middle">
                                  <NumericManualInput
                                    value={item.manual.consumerPrice}
                                    ariaLabel={`قیمت مصرف‌کننده ${item.report.name}`}
                                    onCommit={(val) =>
                                      onUpdateSharedField(
                                        item.report.code,
                                        item.report.name,
                                        'consumerPrice',
                                        val
                                      )
                                    }
                                  />
                                </td>
                                <td rowSpan={2} className="px-1.5 py-1 align-middle">
                                  <TextManualInput
                                    value={item.manual.notes}
                                    ariaLabel={`توضیحات ${item.report.name}`}
                                    onCommit={(val) =>
                                      onUpdateSharedField(
                                        item.report.code,
                                        item.report.name,
                                        'notes',
                                        val
                                      )
                                    }
                                  />
                                </td>
                              </>
                            )}
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-4 py-2.5 text-xs">
            <span className="text-slate-600 tabular-nums">
              صفحه {toPersianDigits(safePage)} از {toPersianDigits(totalPages)}
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40"
              >
                <ChevronRight className="h-3.5 w-3.5" />
                قبلی
              </button>
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40"
              >
                بعدی
                <ChevronLeft className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
