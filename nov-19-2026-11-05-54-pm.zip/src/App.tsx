import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Menu, Calendar, Download } from 'lucide-react';
import {
  AppSettings,
  MergeSummary,
  NavSection,
  PersistedAppState,
  PriceChangeLogEntry,
  ProductManualData,
  ProductReportData,
  SaleTerm,
  TermManualInput,
  UploadLogEntry,
} from './types/pricing';
import { buildInitialAppState } from './data/seedData';
import { loadPersistedState, savePersistedState } from './utils/storage';
import {
  calculateShippingMetrics,
  computeAllProducts,
  createEmptyManualData,
} from './utils/pricingEngine';
import {
  formatJalaliDateTime,
  formatToman,
  getJalaliTime,
  getTodayJalali,
  toPersianDigits,
} from './utils/jalali';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { DailyUploadView } from './components/DailyUploadView';
import { PricingGridView } from './components/PricingGridView';
import { PriceListView } from './components/PriceListView';
import { SettingsShippingView } from './components/SettingsShippingView';
import { HistoryView } from './components/HistoryView';
import { BackupRestoreView } from './components/BackupRestoreView';
import { ToastContainer, ToastMessage } from './components/Toast';

const SECTION_TITLES: Record<NavSection, string> = {
  dashboard: 'داشبورد مدیریتی',
  upload: 'بارگذاری گزارش‌های روزانه',
  pricing: 'مدیریت و قیمت‌گذاری کالاها',
  'sales-list': 'لیست قیمت بخش فروش',
  'visitors-list': 'لیست قیمت ویزیتورها',
  settings: 'تنظیمات و محاسبات حمل',
  history: 'تاریخچه تغییرات و گزارش‌ها',
  backup: 'پشتیبان‌گیری و بازیابی',
};

const TERM_FIELD_LABELS: Record<keyof TermManualInput, string> = {
  weight: 'وزن هر واحد (کیلوگرم)',
  vatRate: 'نرخ ارزش افزوده (%)',
  inboundShipping: 'هزینه حمل تا انبار (تومان)',
  exWarehousePrice: 'قیمت فروش درب انبار (تومان)',
};

const SHARED_FIELD_LABELS: Record<
  'checkDays' | 'consumptionPrice' | 'consumerPrice' | 'notes',
  string
> = {
  checkDays: 'مدت چک (روز)',
  consumptionPrice: 'قیمت مصرف (تومان)',
  consumerPrice: 'قیمت مصرف‌کننده (تومان)',
  notes: 'توضیحات',
};

export default function App() {
  const [appState, setAppState] = useState<PersistedAppState>(() => buildInitialAppState());
  const [hydrated, setHydrated] = useState(false);
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const saveTimerRef = useRef<number | null>(null);

  const notify = useCallback((type: 'success' | 'error' | 'info', text: string) => {
    const id = `t-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, text }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 5000);
  }, []);

  // Load persisted IndexedDB state on boot
  useEffect(() => {
    let active = true;
    loadPersistedState()
      .then((saved) => {
        if (!active) return;
        if (saved && Array.isArray(saved.products) && saved.products.length > 0) {
          setAppState(saved);
        }
        setHydrated(true);
      })
      .catch(() => {
        if (active) setHydrated(true);
      });
    return () => {
      active = false;
    };
  }, []);

  // Auto-save to IndexedDB whenever appState changes after hydration
  useEffect(() => {
    if (!hydrated) return;
    if (saveTimerRef.current !== null) {
      window.clearTimeout(saveTimerRef.current);
    }
    saveTimerRef.current = window.setTimeout(() => {
      savePersistedState(appState).catch(() => {
        notify('error', 'خطا در ذخیره خودکار اطلاعات در حافظه مرورگر.');
      });
    }, 150);
    return () => {
      if (saveTimerRef.current !== null) {
        window.clearTimeout(saveTimerRef.current);
      }
    };
  }, [appState, hydrated, notify]);

  const shippingMetrics = useMemo(
    () => calculateShippingMetrics(appState.settings),
    [appState.settings]
  );

  const computedProducts = useMemo(
    () => computeAllProducts(appState.products, appState.manualData, appState.settings),
    [appState.products, appState.manualData, appState.settings]
  );

  const salesItems = useMemo(
    () => computedProducts.filter((p) => p.isSalesVisible),
    [computedProducts]
  );

  const visitorItems = useMemo(
    () => computedProducts.filter((p) => p.isVisitorsVisible),
    [computedProducts]
  );

  const missingPriceCount = useMemo(
    () =>
      computedProducts.filter(
        (p) =>
          !(p.manual.cash.exWarehousePrice && p.manual.cash.exWarehousePrice > 0) &&
          !(p.manual.check.exWarehousePrice && p.manual.check.exWarehousePrice > 0)
      ).length,
    [computedProducts]
  );

  const effectiveJalaliDate = appState.settings.customListDate.trim() || getTodayJalali();

  const handleUpdateTermField = useCallback(
    (
      code: string,
      productName: string,
      term: SaleTerm,
      field: keyof TermManualInput,
      value: number | null,
      applyToBoth = false
    ) => {
      const now = new Date();
      setAppState((prev) => {
        const existing =
          prev.manualData[code] ?? createEmptyManualData(code, prev.settings.defaultVatRate);
        const termKey = term === 'نقدی' ? 'cash' : 'check';
        const oldVal = existing[termKey][field];

        if (oldVal === value && !applyToBoth) return prev;

        const nextCash =
          termKey === 'cash' || applyToBoth
            ? { ...existing.cash, [field]: value }
            : existing.cash;
        const nextCheck =
          termKey === 'check' || applyToBoth
            ? { ...existing.check, [field]: value }
            : existing.check;

        const nextManual: ProductManualData = {
          ...existing,
          cash: nextCash,
          check: nextCheck,
          updatedAt: now.toISOString(),
        };

        const formatLogVal = (v: number | null) =>
          v === null ? 'خالی' : field === 'weight' || field === 'vatRate' ? String(v) : formatToman(v);

        const logEntry: PriceChangeLogEntry = {
          id: `ch-${now.getTime()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: now.toISOString(),
          jalaliDate: getTodayJalali(now),
          jalaliTime: getJalaliTime(now),
          code,
          productName,
          term: applyToBoth ? 'مشترک' : term,
          fieldLabel: TERM_FIELD_LABELS[field],
          oldValue: formatLogVal(oldVal),
          newValue: formatLogVal(value),
        };

        return {
          ...prev,
          manualData: {
            ...prev.manualData,
            [code]: nextManual,
          },
          priceChangeLogs: [logEntry, ...prev.priceChangeLogs].slice(0, 1000),
        };
      });
    },
    []
  );

  const handleUpdateSharedField = useCallback(
    (
      code: string,
      productName: string,
      field: 'checkDays' | 'consumptionPrice' | 'consumerPrice' | 'notes',
      value: number | string | null
    ) => {
      const now = new Date();
      setAppState((prev) => {
        const existing =
          prev.manualData[code] ?? createEmptyManualData(code, prev.settings.defaultVatRate);
        const oldVal = existing[field];
        if (oldVal === value) return prev;

        const nextManual: ProductManualData = {
          ...existing,
          [field]: value,
          updatedAt: now.toISOString(),
        };

        const formatLogVal = (v: number | string | null) => {
          if (v === null || v === '') return 'خالی';
          if (typeof v === 'number') {
            return field === 'checkDays' ? `${v} روز` : formatToman(v);
          }
          return String(v);
        };

        const logEntry: PriceChangeLogEntry = {
          id: `ch-${now.getTime()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: now.toISOString(),
          jalaliDate: getTodayJalali(now),
          jalaliTime: getJalaliTime(now),
          code,
          productName,
          term: 'مشترک',
          fieldLabel: SHARED_FIELD_LABELS[field],
          oldValue: formatLogVal(oldVal),
          newValue: formatLogVal(value),
        };

        return {
          ...prev,
          manualData: {
            ...prev.manualData,
            [code]: nextManual,
          },
          priceChangeLogs: [logEntry, ...prev.priceChangeLogs].slice(0, 1000),
        };
      });
    },
    []
  );

  const handleCopyCashToCheck = useCallback(
    (code: string, productName: string) => {
      const now = new Date();
      setAppState((prev) => {
        const existing =
          prev.manualData[code] ?? createEmptyManualData(code, prev.settings.defaultVatRate);
        const nextManual: ProductManualData = {
          ...existing,
          check: { ...existing.cash },
          updatedAt: now.toISOString(),
        };
        const logEntry: PriceChangeLogEntry = {
          id: `ch-${now.getTime()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: now.toISOString(),
          jalaliDate: getTodayJalali(now),
          jalaliTime: getJalaliTime(now),
          code,
          productName,
          term: 'چکی',
          fieldLabel: 'کپی کامل مقادیر نقدی به چکی',
          oldValue: formatToman(existing.check.exWarehousePrice),
          newValue: formatToman(existing.cash.exWarehousePrice),
        };
        return {
          ...prev,
          manualData: { ...prev.manualData, [code]: nextManual },
          priceChangeLogs: [logEntry, ...prev.priceChangeLogs].slice(0, 1000),
        };
      });
      notify('info', `مقادیر ردیف نقدی برای «${productName}» روی ردیف چکی اعمال شد.`);
    },
    [notify]
  );

  const handleApplyImport = useCallback(
    (params: {
      nextProducts: ProductReportData[];
      nextManualMap: Record<string, ProductManualData>;
      summary: MergeSummary;
      sellableFileName: string;
      warehouseFileName: string;
      duplicateWarningsCount: number;
    }) => {
      const now = new Date();
      const jalaliDT = formatJalaliDateTime(now);
      const log: UploadLogEntry = {
        id: `up-${now.getTime()}`,
        timestamp: now.toISOString(),
        jalaliDateTime: jalaliDT,
        sellableFileName: params.sellableFileName,
        warehouseFileName: params.warehouseFileName,
        newCount: params.summary.newProducts.length,
        removedCount: params.summary.removedFromActive.length,
        updatedCount: params.summary.updatedCount,
        totalActiveCount: params.summary.totalActiveCount,
        preservedManualCount: params.summary.preservedManualCount,
        restoredManualCount: params.summary.restoredManualCount,
        duplicateWarningsCount: params.duplicateWarningsCount,
      };

      setAppState((prev) => ({
        ...prev,
        products: params.nextProducts,
        manualData: params.nextManualMap,
        uploadLogs: [log, ...prev.uploadLogs].slice(0, 200),
        lastUpdatedAt: now.toISOString(),
        lastUpdatedJalali: jalaliDT,
      }));

      notify(
        'success',
        `به‌روزرسانی روزانه با موفقیت انجام شد: ${toPersianDigits(
          params.summary.totalActiveCount
        )} کالای فعال و حفظ ${toPersianDigits(
          params.summary.preservedManualCount + params.summary.restoredManualCount
        )} رکورد دستی.`
      );
      setActiveSection('pricing');
    },
    [notify]
  );

  const handleUpdateSettings = useCallback((nextSettings: AppSettings) => {
    setAppState((prev) => ({
      ...prev,
      settings: nextSettings,
    }));
  }, []);

  const handleUpdateCustomDate = useCallback((dateStr: string) => {
    setAppState((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        customListDate: dateStr,
      },
    }));
  }, []);

  const handleRestoreBackup = useCallback(
    (restored: PersistedAppState) => {
      setAppState(restored);
      notify('success', 'اطلاعات نسخه پشتیبان با موفقیت بازیابی و در مرورگر ذخیره شد.');
      setActiveSection('dashboard');
    },
    [notify]
  );

  const handleResetToInitial = useCallback(() => {
    const fresh = buildInitialAppState();
    setAppState(fresh);
    notify('info', 'اطلاعات برنامه به فایل قیمت‌گذاری اولیه بازنشانی شد.');
    setActiveSection('dashboard');
  }, [notify]);

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      {/* Right-side RTL Navigation Sidebar */}
      <Sidebar
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        companyName={appState.settings.companyName}
        salesCount={salesItems.length}
        visitorsCount={visitorItems.length}
        missingPriceCount={missingPriceCount}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Clean Contextual Top Bar */}
        <header className="no-print sticky top-0 z-30 flex h-16 items-center justify-between gap-4 border-b border-slate-200 bg-white px-4 sm:px-6">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="باز کردن منو"
              className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="hidden sm:inline text-slate-400">سامانه قیمت‌گذاری</span>
              <span className="hidden sm:inline text-slate-300">/</span>
              <span className="truncate font-bold text-slate-900">
                {SECTION_TITLES[activeSection]}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-600 tabular-nums whitespace-nowrap">
              <Calendar className="h-3.5 w-3.5 text-slate-400" />
              <span>تاریخ لیست:</span>
              <strong className="text-slate-800">{toPersianDigits(effectiveJalaliDate)}</strong>
            </div>

            <button
              type="button"
              onClick={() => setActiveSection('sales-list')}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5 text-teal-700" />
              خروجی فروش
            </button>
          </div>
        </header>

        {/* Active Section Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-7 max-w-[1600px] w-full mx-auto">
          {activeSection === 'dashboard' && (
            <DashboardView
              products={computedProducts}
              settings={appState.settings}
              shippingMetrics={shippingMetrics}
              lastUpdatedJalali={appState.lastUpdatedJalali}
              priceChangeLogs={appState.priceChangeLogs}
              onNavigate={setActiveSection}
            />
          )}

          {activeSection === 'upload' && (
            <DailyUploadView
              existingProducts={appState.products}
              existingManualMap={appState.manualData}
              settings={appState.settings}
              onApplyImport={handleApplyImport}
              onNotify={notify}
            />
          )}

          {activeSection === 'pricing' && (
            <PricingGridView
              products={computedProducts}
              shippingMetrics={shippingMetrics}
              onUpdateTermField={handleUpdateTermField}
              onUpdateSharedField={handleUpdateSharedField}
              onCopyCashToCheck={handleCopyCashToCheck}
            />
          )}

          {activeSection === 'sales-list' && (
            <PriceListView
              mode="sales"
              items={salesItems}
              settings={appState.settings}
              onUpdateCustomDate={handleUpdateCustomDate}
              onNavigateSettings={setActiveSection}
              onNotify={notify}
            />
          )}

          {activeSection === 'visitors-list' && (
            <PriceListView
              mode="visitors"
              items={visitorItems}
              settings={appState.settings}
              onUpdateCustomDate={handleUpdateCustomDate}
              onNavigateSettings={setActiveSection}
              onNotify={notify}
            />
          )}

          {activeSection === 'settings' && (
            <SettingsShippingView
              settings={appState.settings}
              shippingMetrics={shippingMetrics}
              onUpdateSettings={handleUpdateSettings}
              onNotify={notify}
            />
          )}

          {activeSection === 'history' && (
            <HistoryView
              uploadLogs={appState.uploadLogs}
              priceChangeLogs={appState.priceChangeLogs}
            />
          )}

          {activeSection === 'backup' && (
            <BackupRestoreView
              appState={appState}
              allComputed={computedProducts}
              salesItems={salesItems}
              visitorItems={visitorItems}
              onRestoreBackup={handleRestoreBackup}
              onResetToInitial={handleResetToInitial}
              onNotify={notify}
            />
          )}
        </main>
      </div>

      <ToastContainer
        toasts={toasts}
        onDismiss={(id) => setToasts((prev) => prev.filter((item) => item.id !== id))}
      />
    </div>
  );
}
